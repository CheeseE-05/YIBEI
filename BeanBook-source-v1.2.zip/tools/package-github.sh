#!/usr/bin/env bash
# 生成「忆杯手记 v1.2」GitHub 发布工程文件夹（不压缩，直接目录）
# 用法：bash tools/package-github.sh [--out dist/忆杯手记-v1.2-github]
set -euo pipefail
cd "$(dirname "$0")/.."
ROOT="$PWD"
OUT="${2:-dist/忆杯手记-v1.2-github}"
if [[ "${1:-}" != "--out" && -n "${1:-}" ]]; then OUT="$1"; fi
rm -rf "$OUT"
mkdir -p "$OUT"

# —— Android 源码 ——
cp -R app "$OUT/app"
rm -rf "$OUT/app/build" "$OUT/app/artifacts" "$OUT/app/src/main/.DS_Store"
cp build.gradle.kts settings.gradle.kts gradle.properties "$OUT/"
cp -R gradle "$OUT/gradle"
cp gradlew gradlew.bat "$OUT/"
cp README.md THIRD_PARTY_NOTICES.txt .gitignore "$OUT/" 2>/dev/null || true

# —— iOS 源码 ——
mkdir -p "$OUT/ios"
cp -R ios/BeanBook ios/BeanBook.xcodeproj ios/scripts "$OUT/ios/"
cp ios/README-IOS.md ios/.gitignore "$OUT/ios/" 2>/dev/null || true
rm -rf "$OUT/ios/BeanBook/.DS_Store"

# —— 文档（发行说明 + 设计/构建说明） ——
mkdir -p "$OUT/docs"
cp docs/RELEASE-1.2.md docs/design/promo-card-v2.md docs/design/card-editor-ui-spec.md "$OUT/docs/" 2>/dev/null || true

# —— 关键截图预览（压缩为 jpg，避免仓库体积过大） ——
mkdir -p "$OUT/screenshots/preview"
if command -v sips >/dev/null 2>&1; then
  pick() { # src name
    [ -f "$1" ] || return 0
    sips -Z 1000 -s format jpeg -s formatOptions 82 "$1" --out "$OUT/screenshots/preview/$2" >/dev/null 2>&1 || true
  }
  pick screenshots/features-1.2/cards-v2-ios/03-card-portrait-a6.png ios-card-portrait-a6.jpg
  pick screenshots/features-1.2/cards-v2-ios/04-card-landscape-a6.png ios-card-landscape-a6.jpg
  pick screenshots/features-1.2/cards-v2-ios/14-import-cutout-result.png ios-card-cutout.jpg
  pick screenshots/features-1.2/cards-v2-ios/11-font-size-panel.png ios-editor-font-size.jpg
  pick screenshots/features-1.2/brand-ios/02-settings-about.png ios-about.jpg
  pick screenshots/features-1.2/brand-ios/03-dark-about.png ios-dark-about.jpg
  pick screenshots/features-1.2/brand-ios/04-app-icon.png ios-app-icon.jpg
  pick screenshots/features-1.2/cards-v2-android/06-card-portrait-ai.png android-card-portrait.jpg
  pick screenshots/features-1.2/cards-v2-android/05-card-landscape-ai.png android-card-landscape.jpg
  pick screenshots/features-1.2/cards-v2-android/13-cutout-card-portrait.png android-card-cutout.jpg
  pick screenshots/features-1.2/cards-v2-android/16-menu-price.png android-menu-price.jpg
  pick screenshots/features-1.2/cards-v2-android/22-settings-glm-image.png android-settings-glm.jpg
  pick screenshots/features-1.2/brand-android/04-dark-home.png android-dark-home.jpg
  pick screenshots/features-1.2/brand-android/09-about-developer-bilibili.png android-about.jpg
  pick ios/artifacts/verify-1.2-ai-cutout/03-card-transparent-ai.png ios-ai-transparent-card.jpg
  pick ios/artifacts/verify-1.2-ai-cutout/04-save-to-album-success.png ios-save-ai-illustration.jpg
  pick app/artifacts/verify-1.2-ai-cutout/05-card-transparent-illustration.png android-ai-transparent-card.jpg
  pick app/artifacts/verify-1.2-transparent-import/01-transparent-import.png android-transparent-import.jpg
  pick ios/artifacts/verify-1.2-ai-photo2illu/01-ai-prompt-transparent.png ios-ai-prompt-transparent.jpg
  pick ios/artifacts/verify-1.2-ai-photo2illu/02-photo-prompt-vision.png ios-photo-prompt.jpg
  pick ios/artifacts/verify-1.2-ai-photo2illu/03-card-from-photo-transparent.png ios-photo-to-illustration.jpg
  pick app/artifacts/verify-1.2-ai-photo2illu/03-prompt-transparent.png android-ai-prompt-transparent.jpg
  pick app/artifacts/verify-1.2-ai-photo2illu/06-card-from-photo.png android-photo-to-illustration.jpg
  pick ios/artifacts/verify-1.2-photo-prompt-fix/01-photo-prompt-full.png ios-photo-prompt-full.jpg
  pick app/artifacts/verify-1.2-photo-prompt-fix/02-photo-prompt-full-with-counter.png android-photo-prompt-full.jpg
fi

# —— 发行说明 md（若已生成） ——
[ -f "docs/忆杯手记-v1.2-发行说明.md" ] && cp "docs/忆杯手记-v1.2-发行说明.md" "$OUT/"

# —— GitHub 发布版 README（仅引用文件夹内 preview 截图，避免裂图） ——
cat > "$OUT/README.md" <<'GITHUB_README'
# 忆杯手记 · YIBEI（v1.2）

离线咖啡豆与配方记录 App：豆仓、调一杯、菜单/配方目录、统计；数据只保存在本机，不联网、不上传。
本仓库为 **v1.2 双端工程**（Android Kotlin + Jetpack Compose / iOS SwiftUI），包含源码、构建脚本与发行说明。

- 版本：**1.2**（Android versionCode 3 / iOS build 3）
- 开发者：**芝士鸡cheeseE** · B 站：<https://space.bilibili.com/397554088>
- 发行说明（使用/更新/安装/AI 配置）：[`忆杯手记-v1.2-发行说明.md`](忆杯手记-v1.2-发行说明.md)

## 预览

| 随杯卡·竖版 | 随杯卡·横版 | 导入图片自动抠图 |
| --- | --- | --- |
| ![随杯卡竖版](screenshots/preview/ios-card-portrait-a6.jpg) | ![随杯卡横版](screenshots/preview/ios-card-landscape-a6.jpg) | ![抠图](screenshots/preview/ios-card-cutout.jpg) |

| 编辑器·字号面板 | 关于（开发者/B站） | Android 深色导航 |
| --- | --- | --- |
| ![编辑器](screenshots/preview/ios-editor-font-size.jpg) | ![关于](screenshots/preview/ios-about.jpg) | ![深色导航](screenshots/preview/android-dark-home.jpg) |

## 目录结构

```
app/                  Android 源码（Kotlin + Compose）
gradle/ gradlew ...   Android Gradle 工程
ios/                  iOS 工程（BeanBook.xcodeproj / SwiftUI 源码 / scripts）
docs/                 1.2 发行说明、随杯卡设计规范、编辑器 UI 规范
screenshots/preview/  压缩预览图
忆杯手记-v1.2-发行说明.md
```

## 构建

- Android：`./gradlew :app:assembleRelease`（JDK 17 + Android SDK 35）
- iOS：`bash ios/scripts/build-all.sh`；或用 Xcode 打开 `ios/BeanBook.xcodeproj`（iOS 17+）

## 说明

- 内部包名/Bundle ID 仍沿用 `com.brewkin.beanbook` 以兼容旧版本数据与升级。
- App 内 AI 插画需在「设置 → AI 与插画 API」自行填写智谱 GLM-Image Key；不填也可手动设计/导入图片。
- 仓库不含签名密钥、构建产物与第三方参考素材。

**开发者**：芝士鸡cheeseE · **B 站**：<https://space.bilibili.com/397554088>
GITHUB_README

# —— 清理构建产物/敏感文件/大体积目录 ——
find "$OUT" -name '.DS_Store' -delete 2>/dev/null || true
rm -rf "$OUT/app/build" "$OUT/ios/build" "$OUT/ios/artifacts" "$OUT/app/artifacts" \
       "$OUT/dist" "$OUT/node_modules" "$OUT/.gradle" "$OUT/keystore.properties" \
       "$OUT/local.properties" "$OUT/docs/reference" "$OUT/signing" 2>/dev/null || true

echo "GitHub 发布文件夹已生成：$OUT"
du -sh "$OUT"
find "$OUT" -maxdepth 2 -type d | sort | head -30
