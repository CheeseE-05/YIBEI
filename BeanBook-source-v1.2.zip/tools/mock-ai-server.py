#!/usr/bin/env python3
"""本地 mock OpenAI 兼容 API：用于开发/验收 AI 宣传卡片生成（无需真实 Key）。
用法: python3 tools/mock-ai-server.py [port]
iOS 模拟器: http://127.0.0.1:8765/v1   Android 模拟器: http://10.0.2.2:8765/v1
模型名任意；API Key 任意。返回卡片 JSON（中文标题/副标题/标签/主题/模板）。
"""
import base64, io, json, sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 8765

def card_json(user_text: str) -> str:
    prompt = (user_text or "").strip()
    title = "今天这杯，喝点不一样的"
    subtitle = "荔枝气泡冷萃 · 一口夏天"
    tags = ["夏日限定", "气泡感", "冷萃"]
    if any(k in prompt for k in ["抹茶", "绿"]):
        title, subtitle = "一抹清绿，刚刚好", "抹茶与奶香的温柔相遇"
        tags = ["抹茶控", "春日限定", "回甘"]
    if any(k in prompt for k in ["豆", "手冲", "单品"]):
        title, subtitle = "这支豆子，值得慢慢喝", "手冲的仪式感"
        tags = ["单品豆", "手冲", "风味笔记"]
    payload = {
        "title": title,
        "subtitle": subtitle,
        "tags": tags,
        "theme": "lime",
        "template": "magazine",
        "copy": f"{title}｜{subtitle}",
    }
    return json.dumps(payload, ensure_ascii=False)

class Handler(BaseHTTPRequestHandler):
    def _send(self, code, body):
        data = json.dumps(body, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        if self.path.rstrip("/").endswith("/models"):
            self._send(200, {"object": "list", "data": [{"id": "mock-card", "object": "model"}]})
        else:
            self._send(200, {"status": "ok", "hint": "POST /v1/chat/completions"})

    def _image_png(self) -> bytes:
        try:
            from PIL import Image, ImageDraw
        except Exception:
            # 无 PIL 时回退 1x1 PNG
            return base64.b64decode("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==")
        img = Image.new("RGB", (1024, 1024), (247, 242, 230))
        d = ImageDraw.Draw(img)
        # 奶油纸底 + 咖啡杯插画（简化占位）
        d.rounded_rectangle([96, 520, 928, 900], radius=120, fill=(222, 206, 176))
        d.ellipse([250, 300, 774, 640], fill=(250, 248, 242), outline=(38, 35, 31), width=10)
        d.ellipse([250, 300, 774, 470], fill=(107, 74, 51), outline=(38, 35, 31), width=8)
        d.ellipse([340, 560, 684, 660], fill=(163, 205, 57))
        for i, x in enumerate((420, 512, 604)):
            d.arc([x-40, 160, x+40, 320], 220, 320, fill=(38, 35, 31), width=8)
        # 模拟 AI 平台角标水印（右下角，纯色背景上的浅灰文字+小圆标）
        d.text((760, 966), "AI生成", fill=(168, 164, 156))
        d.ellipse([700, 962, 728, 990], outline=(168, 164, 156), width=5)
        d.text((360, 940), "BREWKIN", fill=(38, 35, 31))
        buf = io.BytesIO(); img.save(buf, "PNG"); return buf.getvalue()

    def do_POST(self):
        n = int(self.headers.get("Content-Length") or 0)
        raw = self.rfile.read(n).decode("utf-8", "ignore") if n else "{}"
        try:
            req = json.loads(raw or "{}")
        except Exception:
            req = {}
        user_text = ""
        has_image = False
        for m in req.get("messages", []):
            if m.get("role") == "user":
                c = m.get("content", "")
                if isinstance(c, list):
                    user_text = " ".join(str(x.get("text", "")) for x in c if isinstance(x, dict))
                    if any(isinstance(x, dict) and x.get("type") == "image_url" for x in c):
                        has_image = True
                else:
                    user_text = c if isinstance(c, str) else json.dumps(c, ensure_ascii=False)
        if self.path.rstrip("/").endswith("/images/generations"):
            png = self._image_png()
            self._send(200, {"created": 0, "data": [{"b64_json": base64.b64encode(png).decode(), "revised_prompt": "mock coffee illustration"}]})
            return
        if has_image:
            desc = ("实拍照片：一杯装在透明直身杯里的冰咖啡，杯底有浅棕奶层，冰块与气泡清晰，杯口有细密泡沫，"
                    "旁边点缀荔枝与少量薄荷叶，背景是浅色木桌；光线柔和，主体居中，色调暖米色与浅棕。")
            self._send(200, {
                "id": "chatcmpl-vision-mock",
                "object": "chat.completion",
                "created": 0,
                "model": req.get("model") or "glm-4v-flash",
                "choices": [{"index": 0, "message": {"role": "assistant", "content": desc}, "finish_reason": "stop"}],
                "usage": {"prompt_tokens": 1, "completion_tokens": 1, "total_tokens": 2},
            })
            return
        content = card_json(user_text)
        self._send(200, {
            "id": "chatcmpl-mock",
            "object": "chat.completion",
            "created": 0,
            "model": req.get("model") or "mock-card",
            "choices": [{"index": 0, "message": {"role": "assistant", "content": content}, "finish_reason": "stop"}],
            "usage": {"prompt_tokens": 1, "completion_tokens": 1, "total_tokens": 2},
        })
    def log_message(self, fmt, *args):
        pass

if __name__ == "__main__":
    print(f"mock AI server on http://127.0.0.1:{PORT}/v1 (model: mock-card, key: any)")
    ThreadingHTTPServer(("127.0.0.1", PORT), Handler).serve_forever()
