#!/usr/bin/env bash
# 忆杯手记（BeanBook）双端发行打包脚本 —— 1.2
#
# 把已经构建好的 iOS 未签名 IPA + Android 已签名 APK 统一复制/重命名到 dist/，
# 生成源码包 BeanBook-source-v<ver>.zip 与 dist/SHA256.txt 校验清单。
#
# 用法：
#   bash tools/package-release.sh               # 使用默认版本号 1.2
#   bash tools/package-release.sh --version 1.2
#
# 前置条件（脚本只接收已构建产物，不负责编译）：
#   iOS:     bash ios/scripts/build-device-unsigned.sh && bash ios/scripts/package-ipa.sh
#            → dist/BeanBook-<ver>-unsigned.ipa
#   Android: ./gradlew :app:assembleRelease
#            → app/build/outputs/apk/release/app-release.apk
#
set -euo pipefail

cd "$(dirname "$0")/.."
ROOT="$PWD"
VER="1.2"
if [[ "${1:-}" == "--version" && -n "${2:-}" ]]; then
  VER="$2"
fi

SDK="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-$HOME/Library/Android/sdk}}"
BUILD_TOOLS="$SDK/build-tools/35.0.0"
APK_SRC="app/build/outputs/apk/release/app-release.apk"
IPA_SRC="dist/BeanBook-${VER}-unsigned.ipa"
DIST="$ROOT/dist"

fail() { echo "❌ $*" >&2; exit 1; }
ok()   { echo "✅ $*"; }

echo "==> 忆杯手记发行打包 v${VER}"
echo "    仓库: $ROOT"
[ -f "$IPA_SRC" ] || fail "缺少 iOS IPA: $IPA_SRC（先跑 ios/scripts/build-device-unsigned.sh 与 package-ipa.sh）"
[ -f "$APK_SRC" ] || fail "缺少 Android APK: $APK_SRC（先跑 ./gradlew :app:assembleRelease）"

# ---------- 1. Android APK：版本/签名校验 + 复制 ----------
if [ -x "$BUILD_TOOLS/aapt2" ]; then
  BADGING="$("$BUILD_TOOLS/aapt2" dump badging "$APK_SRC" 2>/dev/null | head -1 || true)"
  echo "    APK badging: $BADGING"
  [[ "$BADGING" == *"versionName='${VER}'"* ]] || fail "APK versionName 不是 ${VER}: $BADGING"
else
  echo "⚠️  未找到 aapt2（$BUILD_TOOLS），跳过 versionName 校验"
fi
if [ -x "$BUILD_TOOLS/apksigner" ]; then
  "$BUILD_TOOLS/apksigner" verify --print-certs "$APK_SRC" >/dev/null 2>&1 \
    || fail "APK 签名校验失败（apksigner verify）"
  ok "APK 签名校验通过"
fi

cp -f "$APK_SRC" "$DIST/BeanBook-v${VER}-arm64.apk"
cp -f "$APK_SRC" "$DIST/忆杯手记-v${VER}-arm64.apk"
ok "Android APK → dist/BeanBook-v${VER}-arm64.apk / 忆杯手记-v${VER}-arm64.apk"

# ---------- 2. iOS IPA：版本校验 + SHA 文件 ----------
IPA_INFO="$(mktemp)"
unzip -p "$IPA_SRC" Payload/BeanBook.app/Info.plist > "$IPA_INFO" 2>/dev/null \
  || fail "IPA 结构异常：缺少 Payload/BeanBook.app/Info.plist"
IPA_VER="$(plutil -extract CFBundleShortVersionString raw "$IPA_INFO" 2>/dev/null || true)"
IPA_BUILD="$(plutil -extract CFBundleVersion raw "$IPA_INFO" 2>/dev/null || true)"
[ "$IPA_VER" = "$VER" ] || fail "IPA 版本号是 ${IPA_VER:-?}，期望 ${VER}"
sha256sum -b "$IPA_SRC" | awk '{print $1}' > /dev/null 2>&1 || true
if command -v shasum >/dev/null 2>&1; then
  (cd "$DIST" && shasum -a 256 "$(basename "$IPA_SRC")" > "$(basename "$IPA_SRC").sha256")
else
  (cd "$DIST" && sha256sum "$(basename "$IPA_SRC")" > "$(basename "$IPA_SRC").sha256")
fi
rm -f "$IPA_INFO"
ok "iOS IPA v${IPA_VER} (build ${IPA_BUILD}) → ${IPA_SRC}"

# ---------- 3. 源码包 ----------
ZIP_OUT="$DIST/BeanBook-source-v${VER}.zip"
echo "==> 生成源码包 $ZIP_OUT"
python3 - "$ROOT" "$ZIP_OUT" <<'PY'
import os, sys, zipfile

root, out = sys.argv[1], sys.argv[2]
# 注意：源码包绝不能包含发布签名密钥（signing/、keystore.properties、*.jks），
# 否则任何拿到源码包的人都能用官方私钥签名伪装 App。
include_dirs = ["app/src", "gradle", "ios/BeanBook", "ios/BeanBook.xcodeproj", "ios/scripts",
                "docs", "tools", ".github"]
include_files = ["README.md", "THIRD_PARTY_NOTICES.txt", "build.gradle.kts", "settings.gradle.kts",
                 "gradle.properties", "gradlew", "gradlew.bat", ".gitignore",
                 "app/build.gradle.kts", "app/proguard-rules.pro",
                 "ios/README-IOS.md", "ios/.gitignore"]
exclude_prefixes = ("app/build", "ios/build", "ios/artifacts", "app/artifacts", ".gradle", "node_modules",
                    "dist", "local.properties", ".git", "signing", "screenshots", "docs/reference")
exclude_suffixes = (".iml", ".class", ".apk", ".ipa", ".zip", ".log", ".jks", ".keystore", ".p12", ".mobileprovision")
exclude_names = {".DS_Store"}
text_ext = {".kt", ".kts", ".swift", ".md", ".xml", ".json", ".plist", ".sh", ".yml", ".yaml",
            ".properties", ".txt", ".gradle", ".pbxproj", ".xcscheme", ".xcworkspacedata", ".gitignore"}

def wanted(path):
    rel = os.path.relpath(path, root)
    if any(rel == p or rel.startswith(p + "/") for p in exclude_prefixes):
        return False
    if os.path.basename(path) in exclude_names:
        return False
    if os.path.basename(path) == "keystore.properties":
        return False
    if rel.endswith(exclude_suffixes) and not rel.endswith((".binary",)):
        # 源码包不包含构建产物与签名材料；zip/log/apk/ipa/jks 全部排除
        return False
    return True

files = []
for p in include_files:
    if os.path.isfile(os.path.join(root, p)):
        files.append(p)
for d in include_dirs:
    base = os.path.join(root, d)
    if not os.path.isdir(base):
        continue
    for dirpath, dirnames, filenames in os.walk(base):
        dirnames[:] = [x for x in dirnames if x not in {"build", ".gradle", "node_modules", "__pycache__"}]
        for f in filenames:
            full = os.path.join(dirpath, f)
            if wanted(full):
                files.append(os.path.relpath(full, root))
files = sorted(set(files))

os.makedirs(os.path.dirname(out), exist_ok=True)
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
    for rel in files:
        z.write(os.path.join(root, rel), rel)
print(f"    zip 文件数: {len(files)}")
PY
ok "源码包 → $ZIP_OUT"

# ---------- 4. SHA256 清单 ----------
SHA_TXT="$DIST/SHA256.txt"
: > "$SHA_TXT"
add_line() { # $1=file  $2=display name
  local f="$1" name="$2"
  [ -f "$f" ] || return 0
  local sha size
  if command -v shasum >/dev/null 2>&1; then sha="$(shasum -a 256 "$f" | awk '{print $1}')"; else sha="$(sha256sum "$f" | awk '{print $1}')"; fi
  size="$(wc -c < "$f" | tr -d ' ')"
  printf '%s  %s  (%s bytes)\n' "$sha" "$name" "$size" >> "$SHA_TXT"
}
add_line "$DIST/BeanBook-v${VER}-arm64.apk" "BeanBook-v${VER}-arm64.apk"
add_line "$DIST/忆杯手记-v${VER}-arm64.apk" "忆杯手记-v${VER}-arm64.apk"
add_line "$IPA_SRC" "BeanBook-${VER}-unsigned.ipa"
add_line "$ZIP_OUT" "BeanBook-source-v${VER}.zip"

# IPA 中文名别名（同一文件）
cp -f "$IPA_SRC" "$DIST/忆杯手记-${VER}-unsigned.ipa"
cp -f "$IPA_SRC.sha256" "$DIST/忆杯手记-${VER}-unsigned.ipa.sha256" 2>/dev/null || true
if command -v shasum >/dev/null 2>&1; then
  (cd "$DIST" && shasum -a 256 "忆杯手记-${VER}-unsigned.ipa" > "忆杯手记-${VER}-unsigned.ipa.sha256")
fi
add_line "$DIST/忆杯手记-${VER}-unsigned.ipa" "忆杯手记-${VER}-unsigned.ipa"

echo
echo "===== 发行产物列表 ====="
ls -lh "$DIST"/BeanBook-v"${VER}"-arm64.apk "$DIST"/忆杯手记-v"${VER}"-arm64.apk "$IPA_SRC" "$DIST"/忆杯手记-"${VER}"-unsigned.ipa "$ZIP_OUT" "$SHA_TXT"
echo
cat "$SHA_TXT"
ok "打包完成：1.2 双端发行产物已就绪"
