#!/usr/bin/env bash
# BeanBook 数据层 macOS 可运行测试：用 Command Line Tools 的 swiftc 真实编译并运行。
#
# 设计说明：
#   - ios/BeanBook/Models.swift 只 import Foundation，可直接在 macOS 编译；
#   - DemoData 在 ios/BeanBook/Store.swift 尾部，但 Store.swift 依赖 UIKit/Combine，
#     无法整体在 macOS 编译，所以这里在构建时把 DemoData 枚举「原样抽取」出来一起编译，
#     不复制、不修改 App 源码（App 源码改动会自动反映到测试里）；
#   - Swift 要求多文件编译时顶层代码只能写在 main.swift，因此把 ModelTests.swift
#     原样复制为 build/main.swift 再编译。ModelTests.swift 本身仍是顶层 main 代码。
#
# 用法：cd beans-app && ./tools/model-tests/run-tests.sh
# 退出码：0 = 全部 PASS；1 = 有 FAIL；2 = 工程/环境前置条件不满足。

set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
MODELS="$ROOT/ios/BeanBook/Models.swift"
STORE="$ROOT/ios/BeanBook/Store.swift"
TESTS="$SCRIPT_DIR/ModelTests.swift"
BUILD_DIR="${TMPDIR:-/tmp}/beanbook-model-tests-build"
BIN="${TMPDIR:-/tmp}/beanbook-model-tests"

echo "== BeanBook model tests (macOS / CLT swiftc) =="
echo "project: $ROOT"
echo "models:  $MODELS"

for required in "$MODELS" "$STORE" "$TESTS"; do
    if [ ! -f "$required" ]; then
        echo "FATAL: 缺少文件 $required" >&2
        exit 2
    fi
done

if ! command -v swiftc >/dev/null 2>&1; then
    echo "FATAL: 找不到 swiftc（需要 Xcode Command Line Tools）" >&2
    exit 2
fi

# 前置断言 1：Models.swift 只依赖 Foundation（决定了它能在 macOS 直接编译）
MODEL_IMPORTS="$(grep -E '^import ' "$MODELS" | sed 's/\r$//; s/^import //' | tr '\n' ' ')"
echo "models imports: $MODEL_IMPORTS"
if [ "$MODEL_IMPORTS" != "Foundation " ]; then
    echo "FATAL: Models.swift 依赖了 Foundation 之外的模块：$MODEL_IMPORTS" >&2
    exit 2
fi

rm -rf "$BUILD_DIR"
mkdir -p "$BUILD_DIR"

# 前置断言 2：从 Store.swift 抽取 DemoData（原样，从 enum 定义到文件末尾）。
# 注意 Swift 的 import 是文件级作用域，抽取出来的片段需要自己补一行 import Foundation。
{
    echo 'import Foundation'
    awk '/^enum DemoData \{/,0' "$STORE"
} > "$BUILD_DIR/DemoDataExtract.swift"
if ! grep -q 'static func make() -> AppData' "$BUILD_DIR/DemoDataExtract.swift"; then
    echo "FATAL: 无法从 Store.swift 抽取 DemoData（枚举结构可能已改动）" >&2
    exit 2
fi

OPEN_BRACES=$(tr -cd '{' < "$BUILD_DIR/DemoDataExtract.swift" | wc -c | tr -d ' ')
CLOSE_BRACES=$(tr -cd '}' < "$BUILD_DIR/DemoDataExtract.swift" | wc -c | tr -d ' ')
if [ "$OPEN_BRACES" != "$CLOSE_BRACES" ]; then
    echo "FATAL: DemoData 抽取片段大括号不平衡（{=$OPEN_BRACES }=$CLOSE_BRACES），Store.swift 可能不再以 DemoData 结尾" >&2
    exit 2
fi

cp "$TESTS" "$BUILD_DIR/main.swift"

echo
echo "== compile =="
echo "swiftc -O -swift-version 5 <Models.swift> <DemoDataExtract.swift> <main.swift> -o $BIN"
if ! swiftc -O -swift-version 5 \
    "$MODELS" \
    "$BUILD_DIR/DemoDataExtract.swift" \
    "$BUILD_DIR/main.swift" \
    -o "$BIN"; then
    echo "FATAL: 模型测试编译失败" >&2
    exit 2
fi

echo
echo "== run =="
TZ=Asia/Shanghai "$BIN"
RC=$?
echo
echo "harness exit code: $RC"
exit "$RC"
