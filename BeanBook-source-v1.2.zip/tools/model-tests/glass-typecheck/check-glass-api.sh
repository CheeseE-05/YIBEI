#!/usr/bin/env bash
# Liquid Glass（iOS 26）API 独立核验：本机只有 CLT（无 Xcode / 无 iOS SDK），
# 因此用 macOS 26 SDK 对「从 App 源码原样抽取」的代码做 swiftc 类型检查。
#
# 核验原理：
#   - SwiftUI 的 Glass / GlassEffectContainer / glassEffect / glassEffectID API
#     在 iOS 26 与 macOS 26 上是同一套（同一个 SwiftUI 模块）；
#   - iOS SDK 缺失，不能直接 -target arm64-apple-ios26.0，所以这里只能验证
#     「API 名称 / 签名 / @available 标注 / ViewBuilder 分支」是否正确，
#     iOS 目标下的可用性门禁则由 check 3 的静态审计覆盖。
#
# 检查项：
#   1) Theme.swift 的 Liquid Glass 段落（原样抽取）在 macos26 下 typecheck 通过；
#   1b) 共享 BottomActionBar 的声明 + 详情页典型用法（@ViewBuilder 存储属性尾随闭包）typecheck 通过；
#   2) RootView.swift 使用系统原生 TabView（无自绘底部导航），底部 Tab Bar 由系统提供 Liquid Glass；
#   3) 把 `#if compiler(>=6.2)` 之外（即 Xcode <=16 / Swift <6.2 可见）的源码剥离出来，
#      确认没有残留任何 iOS 26 专属符号（旧 Xcode 可以正常编译回退分支）；
#   4) iOS 26 专属符号的每处使用都必须有「#if compiler(>=6.2) 真分支 + 可用性作用域」双重门禁。
#      判定按花括号作用域（不是行距窗口）：`if #available(iOS 26.0, *)` 真分支 / `@available(iOS 26.0, *)`
#      标注的声明体；并内置 5 个人造样例自测检查器（防漏报/误报）。
#
# 用法：cd beans-app && ./tools/model-tests/glass-typecheck/check-glass-api.sh
# 退出码：0 = 全部 PASS；1 = 有 FAIL；2 = 环境不满足。

set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$SCRIPT_DIR/../../.." && pwd)"
THEME="$ROOT/ios/BeanBook/Theme.swift"
ROOTVIEW="$ROOT/ios/BeanBook/RootView.swift"
WORK="${TMPDIR:-/tmp}/beanbook-glass-typecheck"
PASS=0
FAIL=0

pass() { PASS=$((PASS + 1)); echo "PASS  $*"; }
fail() { FAIL=$((FAIL + 1)); echo "FAIL  $*"; }

for required in "$THEME" "$ROOTVIEW"; do
    [ -f "$required" ] || { echo "FATAL: 缺少 $required" >&2; exit 2; }
done
command -v swiftc >/dev/null 2>&1 || { echo "FATAL: 找不到 swiftc" >&2; exit 2; }

rm -rf "$WORK"
mkdir -p "$WORK"

echo "== Liquid Glass iOS 26 API 核验（CLT / macOS 26 SDK）=="
echo "macOS SDK: $(xcrun --show-sdk-path 2>/dev/null) $(xcrun --show-sdk-version 2>/dev/null)"
if xcrun --sdk iphoneos --show-sdk-path >/dev/null 2>&1; then
    echo "iOS SDK:   $(xcrun --sdk iphoneos --show-sdk-path)"
else
    echo "iOS SDK:   不存在（本机无 Xcode，无法真正 -target ios）"
fi

# ---------- 1. 抽取 Theme.swift 的 Liquid Glass 段落并 typecheck ----------
python3 - "$THEME" "$WORK/ThemeGlassCheck.swift" <<'PY'
import sys
src = open(sys.argv[1], encoding='utf-8').read()
marker = '// MARK: - Liquid Glass'
idx = src.index(marker)
open(sys.argv[2], 'w', encoding='utf-8').write('import SwiftUI\n\n' + src[idx:])
PY
if swiftc -typecheck -target arm64-apple-macos26.0 "$WORK/ThemeGlassCheck.swift" 2>"$WORK/theme.err"; then
    pass "Theme.swift Liquid Glass 段落 typecheck（macos26）"
else
    fail "Theme.swift Liquid Glass 段落 typecheck（macos26）"
    sed -n '1,20p' "$WORK/theme.err"
fi

# ---------- 1b. 共享 BottomActionBar 声明 + 详情页用法 typecheck ----------
python3 - "$THEME" "$WORK/BottomActionBarCheck.swift" <<'PY'
import sys
src = open(sys.argv[1], encoding='utf-8').read()
marker = '// MARK: - Liquid Glass'
idx = src.index(marker)
usage = """

// 详情页里的典型用法（与 BeanDetailView / RecipeDetailView / BeanEditorView 一致）
private struct _BottomActionBarUsageCheck: View {
    var body: some View {
        VStack {
            BottomActionBar {
                HStack(spacing: 10) {
                    Text("编辑")
                    Text("调一杯")
                }
            }
        }
    }
}
"""
open(sys.argv[2], 'w', encoding='utf-8').write('import SwiftUI\n\n' + src[idx:] + usage)
PY
if swiftc -typecheck -target arm64-apple-macos26.0 "$WORK/BottomActionBarCheck.swift" 2>"$WORK/bottomactionbar.err"; then
    pass "Theme.swift BottomActionBar 声明 + 详情页用法 typecheck（macos26）"
else
    fail "Theme.swift BottomActionBar 声明 + 详情页用法 typecheck（macos26）"
    sed -n '1,25p' "$WORK/bottomactionbar.err"
fi

# ---------- 2. 底部导航使用系统原生 TabView（系统 Liquid Glass Tab Bar，无自绘玻璃滑块） ----------
if grep -q 'TabView(selection:' "$ROOTVIEW" \
   && grep -q '\.tabItem' "$ROOTVIEW" \
   && ! grep -q 'private struct BottomBar: View' "$ROOTVIEW"; then
    pass "RootView 使用系统原生 TabView（iOS 26/27 自动获得 Liquid Glass Tab Bar 与选中大玻璃滑块）"
else
    fail "RootView 未使用系统原生 TabView / 仍残留自绘底部导航"
fi

# ---------- 3. 剥离 #if compiler(>=6.2) 后不得残留 iOS 26 专属符号 ----------
python3 - "$THEME" "$ROOTVIEW" "$WORK" <<'PY'
import re, sys

def strip_compiler_blocks(text):
    """模拟 Swift < 6.2 编译器：丢弃 #if compiler(>=6.2) 分支，保留 #else 分支。"""
    out, stack = [], []
    for line in text.splitlines(keepends=True):
        s = line.strip()
        if re.match(r'#if\s+compiler\(>=6\.2\)', s):
            stack.append('if')
            continue
        if stack:
            if s.startswith('#else') and len(stack) == 1 and stack[-1] == 'if':
                stack[-1] = 'else'
                continue
            if s.startswith('#else'):
                stack.append('else')
                continue
            if s.startswith('#endif'):
                stack.pop()
                continue
            if stack[-1] == 'if':
                continue
            out.append(line)
            continue
        out.append(line)
    return ''.join(out)

theme_src = open(sys.argv[1], encoding='utf-8').read()
root_src = open(sys.argv[2], encoding='utf-8').read()
work = sys.argv[3]

theme_stripped = strip_compiler_blocks(theme_src)
root_stripped = strip_compiler_blocks(root_src)

# Theme 只保留 Liquid Glass 段落做 typecheck（前段 Color/haptic 依赖 UIKit，无法在 macOS 编译）
idx = theme_stripped.index('// MARK: - Liquid Glass')
theme_glass_stripped = 'import SwiftUI\n\n' + theme_stripped[idx:]
open(work + '/ThemeGlassNoCompiler26.swift', 'w', encoding='utf-8').write(theme_glass_stripped)

# 泄漏检测：旧编译器可见的代码里不允许出现 iOS 26 专属符号（排除注释行）
leak_re = re.compile(r'glassEffect\b|glassEffectID\b|glassEffectTransition\b|GlassEffectContainer\b|\bGlass\b|liquidGlassStyle')
leaks = []
for label, text in (('Theme.swift', theme_stripped), ('RootView.swift', root_stripped)):
    for no, line in enumerate(text.splitlines(), 1):
        s = line.strip()
        if s.startswith('//') or s.startswith('///') or s.startswith('*'):
            continue
        if leak_re.search(line):
            leaks.append((label, no, s))
if leaks:
    print('LEAK ' + str(leaks))
    sys.exit(1)
print('NO_LEAK')
sys.exit(0)
PY
STRIP_RC=$?
if [ "$STRIP_RC" -eq 0 ]; then
    pass "Xcode<=16 / Swift<6.2 可见源码无 iOS 26 专属符号残留"
    if swiftc -typecheck -target arm64-apple-macos26.0 "$WORK/ThemeGlassNoCompiler26.swift" 2>"$WORK/fallback.err"; then
        pass "回退分支（legacySurface）typecheck（macos26）"
    else
        fail "回退分支（legacySurface）typecheck（macos26）"
        sed -n '1,20p' "$WORK/fallback.err"
    fi
else
    fail "Xcode<=16 可见源码残留 iOS 26 专属符号"
fi

# ---------- 4. iOS 26 符号的双重门禁（作用域判定 + 检查器自测） ----------
# 判定规则（按花括号作用域，而不是「N 行窗口」）：
#   - 符号行必须处于 `#if compiler(>=6.2)` 的真分支内（#else 分支不算）；
#   - 且必须落在以下任一「可用性作用域」内：
#       a) `if #available(iOS 26.0, *) { ... }` 的真分支（其 else 分支不算）；
#       b) `@available(iOS 26.0, *)` 标注的声明体，且标注行本身在 #if 真分支内。
# 并内置 5 个自测样例：2 类违规必须被抓到、3 类合规写法不得误报。
python3 - "$THEME" "$ROOTVIEW" <<'PY'
import re
import sys

SYMBOL_RE = re.compile(r'glassEffect\b|glassEffectID\b|glassEffectTransition\b|GlassEffectContainer\b|\bGlass\b|liquidGlassStyle')
GUARD_RE = re.compile(r'#if\s+compiler\(>=6\.2\)')
AVAIL_IF_RE = re.compile(r'if\s+#available\(iOS 26\.0, \*\)')
AVAIL_AT_RE = re.compile(r'@available\(iOS 26\.0, \*\)')
ELSE_END_RE = re.compile(r'^\}\s*else\b')


def sanitize(line):
    """粗略去掉行注释与字符串字面量，仅用于数大括号（本工程代码足够安全）。"""
    s = re.sub(r'//.*$', '', line)
    s = re.sub(r'"(?:\\.|[^"\\])*"', '""', s)
    return s


def analyze(lines):
    san = [sanitize(l) for l in lines]
    depth_before, depth = [], 0
    for s in san:
        depth_before.append(depth)
        depth += s.count('{') - s.count('}')

    # `#if compiler(>=6.2)` 真分支区间（开区间：open < line < else/endif）
    guard_regions, stack = [], []
    for i, line in enumerate(lines, 1):
        st = line.strip()
        if GUARD_RE.match(st):
            stack.append({'open': i, 'else': None})
        elif stack and st.startswith('#else'):
            if stack[-1]['else'] is None:
                stack[-1]['else'] = i
        elif stack and st.startswith('#endif'):
            fr = stack.pop()
            guard_regions.append((fr['open'], fr['else'] if fr['else'] else i))

    def in_guard(n):
        return any(a < n < b for a, b in guard_regions)

    # a) if #available(...) 真分支作用域
    avail_if_scopes = []
    for i, line in enumerate(lines, 1):
        if AVAIL_IF_RE.search(line):
            base = depth_before[i - 1]
            scope, k = set(), i + 1
            while k <= len(lines) and depth_before[k - 1] > base:
                scope.add(k)
                if ELSE_END_RE.match(san[k - 1].strip()) and depth_before[k - 1] == base + 1:
                    break
                k += 1
            avail_if_scopes.append(scope)

    # b) @available(...) 标注声明体的作用域
    avail_decl_scopes = []
    for i, line in enumerate(lines, 1):
        if AVAIL_AT_RE.search(line) and in_guard(i):
            j = i - 1
            while j < len(lines) and '{' not in san[j]:
                j += 1
            if j >= len(lines):
                continue
            base = depth_before[j]
            end, d = len(lines), base
            for k in range(j, len(lines)):
                d += san[k].count('{') - san[k].count('}')
                if d <= base and k > j:
                    end = k + 1
                    break
            avail_decl_scopes.append(set(range(i, end + 1)))

    def availability_ok(n):
        return any(n in sc for sc in avail_if_scopes) or any(n in sc for sc in avail_decl_scopes)

    problems, checked = [], 0
    for i, line in enumerate(lines, 1):
        st = line.strip()
        if st.startswith('//') or st.startswith('///'):
            continue
        if not SYMBOL_RE.search(line):
            continue
        checked += 1
        if not in_guard(i):
            problems.append((i, st[:110], '不在 #if compiler(>=6.2) 真分支'))
        elif not availability_ok(i):
            problems.append((i, st[:110], '不在 #available/@available 可用性作用域'))
    return checked, problems


def self_test():
    cases = [
        ('无门禁直接使用',
         ['let a = GlassEffectContainer()'], {1}),
        ('只有 #if compiler、没有可用性门禁',
         ['#if compiler(>=6.2)', 'let a = GlassEffectContainer()', '#endif'], {2}),
        ('#if compiler + if #available 真分支（合规）',
         ['#if compiler(>=6.2)', 'if #available(iOS 26.0, *) {',
          '    let a = GlassEffectContainer()', '}', '#endif'], set()),
        ('#if compiler + @available 声明体（合规）',
         ['#if compiler(>=6.2)', '@available(iOS 26.0, *)',
          'func f() -> Glass {', '    return .regular', '}', '#endif'], set()),
        ('if #available 的 else 分支使用符号（必须抓到）',
         ['#if compiler(>=6.2)', 'if #available(iOS 26.0, *) {',
          '    let a = GlassEffectContainer()', '} else {',
          '    let b = GlassEffectContainer()', '}', '#endif'], {5}),
    ]
    failures = []
    for name, lines, expect in cases:
        _, problems = analyze(lines)
        got = {p[0] for p in problems}
        if got != expect:
            failures.append((name, sorted(expect), sorted(got)))
    return failures


failures = self_test()
if failures:
    print('SELFTEST_FAIL ' + str(failures))
    sys.exit(1)
print('SELFTEST_OK (5/5)')

total, all_problems = 0, []
for path in sys.argv[1:]:
    lines = open(path, encoding='utf-8').read().splitlines()
    checked, problems = analyze(lines)
    total += checked
    for ln, text, why in problems:
        all_problems.append((path.split('/')[-1], ln, text, why))
if all_problems:
    print('GATING_PROBLEM ' + str(all_problems))
    sys.exit(1)
print('GATING_OK occurrences=%d' % total)
sys.exit(0)
PY
GATING_RC=$?
if [ "$GATING_RC" -eq 0 ]; then
    pass "iOS 26 符号全部有「#if compiler(>=6.2) + #available/@available 作用域」双重门禁（检查器自测 5/5）"
else
    fail "存在未被双重门禁保护的 iOS 26 符号（或检查器自测失败）"
fi

echo
echo "== SUMMARY: PASS=$PASS FAIL=$FAIL =="
[ "$FAIL" -eq 0 ] || exit 1
exit 0
