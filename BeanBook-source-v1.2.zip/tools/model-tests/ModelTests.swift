// BeanBook 数据层 macOS 可运行测试（真实编译 + 真实运行，不依赖 Xcode/iOS）
//
// 用法（不要直接用 swiftc 传本文件，Swift 要求多文件编译时顶层代码必须在 main.swift）：
//     ./tools/model-tests/run-tests.sh
//
// run-tests.sh 会把本文件复制成 build/main.swift，并自动从
// ios/BeanBook/Store.swift 尾部抽取 DemoData（纯 Foundation，不 import UIKit），
// 再与 ios/BeanBook/Models.swift 一起用 CLT 的 swiftc 编译成 macOS 可执行文件。
//
// 断言失败时输出 FAIL 并以退出码 1 结束；全部通过退出码 0。
// #line 行号与本文件一致（run-tests.sh 原样复制，不插入行）。

import Foundation
#if canImport(Darwin)
import Darwin
#endif

// MARK: - 固定时区，保证日期断言确定（ci 机器器时区无关）
NSTimeZone.default = TimeZone(identifier: "Asia/Shanghai")!

// MARK: - 极简测试框架

var gPassed = 0
var gFailed = 0
var gWarnings: [String] = []
var gSection = ""

func section(_ title: String) {
    gSection = title
    print("\n== \(title) ==")
}

func pass(_ name: String) {
    gPassed += 1
    print("PASS  \(name)")
}

func fail(_ name: String, _ detail: String, line: Int = #line) {
    gFailed += 1
    print("FAIL  \(name) :: \(detail)  [ModelTests.swift:\(line)]")
}

func check(_ name: String, _ condition: Bool, _ detail: @autoclosure () -> String = "condition == false", line: Int = #line) {
    if condition { pass(name) } else { fail(name, detail(), line: line) }
}

func checkEqual<T: Equatable>(_ name: String, _ actual: T, _ expected: T, line: Int = #line) {
    if actual == expected {
        pass(name)
    } else {
        fail(name, "actual = \(actual), expected = \(expected)", line: line)
    }
}

func checkThrows(_ name: String, _ block: () throws -> Void, line: Int = #line) {
    do {
        try block()
        fail(name, "预期抛错/解码失败，实际却成功了", line: line)
    } catch {
        pass(name)
    }
}

func warn(_ name: String, _ detail: String) {
    gWarnings.append("\(gSection) / \(name): \(detail)")
    print("WARN  \(name) :: \(detail)")
}

func note(_ message: String) {
    print("NOTE  \(message)")
}

// MARK: - 测试辅助

let DAY_MS: Int64 = 86_400_000

/// 构造一个「本地日历上恰好 daysAgo 天前 01:00」的毫秒时间戳，避免测试在午夜前后抖动。
func localDaysAgoMillis(_ daysAgo: Int) -> Int64 {
    let cal = Calendar.current
    let start = cal.startOfDay(for: Date())
    return start.addingTimeInterval(TimeInterval(-daysAgo * 86_400 + 3_600)).millis
}

func localDate(year: Int, month: Int, day: Int, hour: Int = 0, minute: Int = 0, second: Int = 0) -> Date {
    var cal = Calendar.current
    cal.timeZone = TimeZone(identifier: "Asia/Shanghai")!
    var comps = DateComponents()
    comps.year = year
    comps.month = month
    comps.day = day
    comps.hour = hour
    comps.minute = minute
    comps.second = second
    return cal.date(from: comps)!
}

func fullBean(imagePath: String? = "bean_images/bean_demo.png") -> Bean {
    Bean(
        id: "bean-1",
        name: "Ethiopia Guji",
        roaster: "Coffee Buff",
        origin: "埃塞俄比亚",
        region: "Guji",
        process: "水洗",
        roast: .light,
        flavors: ["茉莉", "柠檬"],
        totalGrams: 150,
        remainingGrams: 86,
        roastDate: localDaysAgoMillis(9),
        openedAt: localDaysAgoMillis(7),
        storage: .room,
        imagePath: imagePath,
        note: "测试用豆",
        createdAt: localDaysAgoMillis(9),
        lastUsedAt: localDaysAgoMillis(1)
    )
}

func fullLayer(grams: Int = 36) -> RecipeLayer {
    RecipeLayer(ingredientId: "espresso", name: "浓缩", colorHex: "2A1708", kind: .liquid, grams: grams, alpha: 1)
}

func fullRecipe(beanId: String? = "bean-1") -> Recipe {
    Recipe(
        id: "recipe-1",
        name: "测试配方",
        beanId: beanId,
        beanName: "Ethiopia Guji",
        layers: [fullLayer(grams: 36), fullLayer(grams: 150)],
        rating: 4,
        notes: "测试备注",
        mouthfeel: "均衡",
        sweetness: "微甜",
        beanGrams: 18,
        stirred: true,
        createdAt: localDaysAgoMillis(2)
    )
}

func beanWithAge(_ days: Int, storage: Storage = .room) -> Bean {
    var bean = fullBean()
    bean.roastDate = localDaysAgoMillis(days)
    bean.openedAt = localDaysAgoMillis(days)
    bean.storage = storage
    return bean
}

func jsonObject(_ value: some Encodable) throws -> [String: Any] {
    let data = try JSONEncoder().encode(value)
    let object = try JSONSerialization.jsonObject(with: data)
    guard let dict = object as? [String: Any] else { throw NSError(domain: "ModelTests", code: 1) }
    return dict
}

func isHex6(_ value: String) -> Bool {
    guard value.count == 6 else { return false }
    let hexDigits = CharacterSet(charactersIn: "0123456789ABCDEFabcdef")
    return value.unicodeScalars.allSatisfy { hexDigits.contains($0) }
}

func isUppercaseHex6(_ value: String) -> Bool {
    guard value.count == 6 else { return false }
    let hexDigits = CharacterSet(charactersIn: "0123456789ABCDEF")
    return value.unicodeScalars.allSatisfy { hexDigits.contains($0) }
}

func approximatelyEqual(_ a: Double, _ b: Double, tolerance: Double = 0.000_001) -> Bool {
    abs(a - b) <= tolerance
}

// MARK: - 启动
print("=== BeanBook ModelTests (macOS 可执行测试) ===")
print("Swift toolchain: \(ProcessInfo.processInfo.operatingSystemVersionString.prefix(40)), TimeZone: \(TimeZone.current.identifier)")
print("Models.swift: 真实 App 源码；DemoData: 从 Store.swift 尾部原样抽取")

// MARK: - 1. 常量与调色板
section("1. 常量与调色板")

checkEqual("CUP_CAPACITY == 420", CUP_CAPACITY, 420)
checkEqual("IMAGE_DIRECTORY == bean_images", IMAGE_DIRECTORY, "bean_images")
checkEqual("palette.count == 16", palette.count, 16)
check("palette 全部为 6 位大写 hex", palette.allSatisfy(isUppercaseHex6), "非法值: \(palette.filter { !isUppercaseHex6($0) })")
checkEqual("palette 无重复", Set(palette).count, palette.count)

// MARK: - 2. 枚举映射
section("2. 枚举 rawValue / label / 颜色映射")

checkEqual("Roast 数量", Roast.allCases.count, 5)
checkEqual("Roast rawValue 顺序", Roast.allCases.map(\.rawValue), ["LIGHT", "MEDIUM_LIGHT", "MEDIUM", "MEDIUM_DARK", "DARK"])
checkEqual("Roast label", Roast.allCases.map(\.label), ["浅烘", "中浅烘", "中烘", "中深烘", "深烘"])
checkEqual("Roast short", Roast.allCases.map(\.short), ["浅", "中浅", "中", "中深", "深"])
checkEqual("Roast toneHex", Roast.allCases.map(\.toneHex), ["DCC99A", "C9A875", "AE8253", "805535", "50301C"])
check("Roast toneHex 合法", Roast.allCases.allSatisfy { isUppercaseHex6($0.toneHex) })
checkEqual("Roast toneHex 唯一", Set(Roast.allCases.map(\.toneHex)).count, Roast.allCases.count)
checkEqual("Roast id == rawValue", Roast.light.id, "LIGHT")

checkEqual("Storage 数量", Storage.allCases.count, 3)
checkEqual("Storage rawValue", Storage.allCases.map(\.rawValue), ["ROOM", "FRIDGE", "FREEZER"])
checkEqual("Storage label", Storage.allCases.map(\.label), ["常温", "冷藏", "冷冻"])

checkEqual("IngredientKind 数量", IngredientKind.allCases.count, 7)
checkEqual("IngredientKind rawValue", IngredientKind.allCases.map(\.rawValue), ["LIQUID", "FOAM", "SYRUP", "PUREE", "CHUNK", "ICE", "SPARKLING"])
checkEqual("IngredientKind label", IngredientKind.allCases.map(\.label), ["液体", "奶泡", "糖浆", "果泥", "果肉", "冰块", "气泡"])
checkEqual("IngredientKind.defaultRate", IngredientKind.allCases.map(\.defaultRate), [34, 20, 12, 24, 24, 80, 45])
check("IngredientKind.defaultRate > 0", IngredientKind.allCases.allSatisfy { $0.defaultRate > 0 })

checkEqual("BeanStatus label", [BeanStatus.resting.label, BeanStatus.peak.label, BeanStatus.stable.label, BeanStatus.fading.label, BeanStatus.frozen.label],
           ["养豆中", "最佳赏味期", "风味稳定", "风味衰退期", "冷冻中"])
let statusCases: [BeanStatus] = [.resting, .peak, .stable, .fading, .frozen]
checkEqual("BeanStatus 背景色", statusCases.map(\.bgHex), ["F3E8BE", "E7F0C7", "DDE9EE", "F0DED7", "DCE7F2"])
checkEqual("BeanStatus 文字色", statusCases.map(\.inkHex), ["6E5B22", "536A1A", "3E5E6A", "7A4A37", "3D5873"])
check("BeanStatus 颜色合法", statusCases.allSatisfy { isUppercaseHex6($0.bgHex) && isUppercaseHex6($0.inkHex) })
checkEqual("BeanStatus 颜色成对唯一", Set(statusCases.map { $0.bgHex + $0.inkHex }).count, statusCases.count)

// MARK: - 3. Bean
section("3. Bean 逻辑")

let emptyA = Bean.empty()
let emptyB = Bean.empty()
checkEqual("Bean.empty 名称/产地为空", emptyA.name, "")
checkEqual("Bean.empty process", emptyA.process, "水洗")
checkEqual("Bean.empty roast", emptyA.roast, Roast.medium)
checkEqual("Bean.empty storage", emptyA.storage, Storage.room)
checkEqual("Bean.empty 总克数", emptyA.totalGrams, 150.0)
checkEqual("Bean.empty 剩余克数", emptyA.remainingGrams, 150.0)
checkEqual("Bean.empty imagePath nil", emptyA.imagePath, nil)
checkEqual("Bean.empty lastUsedAt 0", emptyA.lastUsedAt, 0)
checkEqual("Bean.empty openedAt == roastDate", emptyA.openedAt, emptyA.roastDate)
checkEqual("Bean.empty createdAt == roastDate", emptyA.createdAt, emptyA.roastDate)
check("Bean.empty id 非空且唯一", !emptyA.id.isEmpty && emptyA.id != emptyB.id, "id = \(emptyA.id) / \(emptyB.id)")

let bean9 = beanWithAge(9)
checkEqual("Bean.displayOrigin 有产地", bean9.displayOrigin, "埃塞俄比亚")
var noOrigin = fullBean()
noOrigin.origin = ""
checkEqual("Bean.displayOrigin 空产地兜底", noOrigin.displayOrigin, "未记录产地")

var ratioBean = fullBean()
ratioBean.totalGrams = 150
ratioBean.remainingGrams = 86
check("Bean.remainingRatio 86/150", approximatelyEqual(ratioBean.remainingRatio, 86.0 / 150.0), "= \(ratioBean.remainingRatio)")
ratioBean.remainingGrams = -10
checkEqual("Bean.remainingRatio 负数钳到 0", ratioBean.remainingRatio, 0)
ratioBean.remainingGrams = 999
checkEqual("Bean.remainingRatio 超量钳到 1", ratioBean.remainingRatio, 1)
ratioBean.totalGrams = 0
checkEqual("Bean.remainingRatio total=0 返回 0", ratioBean.remainingRatio, 0)

checkEqual("Bean.ageDays 0 天", beanWithAge(0).ageDays, 0)
checkEqual("Bean.ageDays 9 天", bean9.ageDays, 9)
checkEqual("Bean.ageDays 45 天", beanWithAge(45).ageDays, 45)

checkEqual("Bean.status 0 天 = 养豆中", beanWithAge(0).status, BeanStatus.resting)
checkEqual("Bean.status 3 天 = 养豆中", beanWithAge(3).status, BeanStatus.resting)
checkEqual("Bean.status 4 天 = 最佳赏味", beanWithAge(4).status, BeanStatus.peak)
checkEqual("Bean.status 30 天 = 最佳赏味", beanWithAge(30).status, BeanStatus.peak)
checkEqual("Bean.status 31 天 = 稳定", beanWithAge(31).status, BeanStatus.stable)
checkEqual("Bean.status 45 天 = 稳定", beanWithAge(45).status, BeanStatus.stable)
checkEqual("Bean.status 46 天 = 衰退", beanWithAge(46).status, BeanStatus.fading)
checkEqual("Bean.status 冷冻优先", beanWithAge(0, storage: .freezer).status, BeanStatus.frozen)
checkEqual("Bean.status 冷藏不触发冷冻", beanWithAge(0, storage: .fridge).status, BeanStatus.resting)

checkEqual("peakHint 养豆中(2 天)", beanWithAge(2).peakHint, "再养 2 天")
checkEqual("peakHint 养豆中(0 天)", beanWithAge(0).peakHint, "再养 4 天")
checkEqual("peakHint 最佳赏味", beanWithAge(9).peakHint, "第 9 天 · 正好喝")
checkEqual("peakHint 稳定", beanWithAge(40).peakHint, "第 40 天 · 尽快喝完")
checkEqual("peakHint 衰退", beanWithAge(60).peakHint, "已开 60 天")
checkEqual("peakHint 冷冻", beanWithAge(60, storage: .freezer).peakHint, "冷冻保存")

checkEqual("Bean.status == 枚举相等", beanWithAge(0).status, .resting)
check("Bean.status 不相等判定", beanWithAge(0).status != .fading)

// MARK: - 4. Recipe / RecipeLayer
section("4. Recipe / RecipeLayer")

let recipe = fullRecipe()
checkEqual("Recipe.totalGrams = 层克数之和", recipe.totalGrams, 186)
checkEqual("Recipe.totalText", recipe.totalText, "186g")
var emptyRecipe = fullRecipe()
emptyRecipe.layers = []
checkEqual("Recipe.totalGrams 空层 = 0", emptyRecipe.totalGrams, 0)
checkEqual("Recipe.totalText 空层", emptyRecipe.totalText, "0g")
checkEqual("Recipe.layer kind 保留", recipe.layers[0].kind, IngredientKind.liquid)
checkEqual("Recipe.layer alpha 保留", recipe.layers[0].alpha, 1.0)

// MARK: - 5. CustomIngredient / IngredientSpec / MakerDraft
section("5. CustomIngredient / IngredientSpec / MakerDraft")

let custom = CustomIngredient(id: "custom-1", name: "洛神花", colorHex: "C0392B", kind: .syrup, createdAt: nowMillis())
let customSpec = custom.spec
checkEqual("CustomIngredient.spec id", customSpec.id, "custom-1")
checkEqual("CustomIngredient.spec name", customSpec.name, "洛神花")
checkEqual("CustomIngredient.spec colorHex", customSpec.colorHex, "C0392B")
checkEqual("CustomIngredient.spec rate = kind.defaultRate", customSpec.rate, IngredientKind.syrup.defaultRate)
checkEqual("CustomIngredient.spec kind", customSpec.kind, IngredientKind.syrup)
checkEqual("CustomIngredient.spec alpha", customSpec.alpha, 1.0)
checkEqual("CustomIngredient.spec isCustom", customSpec.isCustom, true)

let builtinSpec = IngredientSpec(id: "espresso", name: "浓缩", colorHex: "2A1708", rate: 20, kind: .liquid)
checkEqual("IngredientSpec alpha 默认 1", builtinSpec.alpha, 1.0)
checkEqual("IngredientSpec isCustom 默认 false", builtinSpec.isCustom, false)

var draft = MakerDraft()
checkEqual("MakerDraft 默认总克数", draft.totalGrams, 0)
checkEqual("MakerDraft 默认剩余", draft.remaining, CUP_CAPACITY)
checkEqual("MakerDraft 默认 beanId", draft.beanId, nil)
checkEqual("MakerDraft 默认 stirred", draft.stirred, false)
draft.layers = [fullLayer(grams: 60), fullLayer(grams: 100)]
checkEqual("MakerDraft 层求和", draft.totalGrams, 160)
checkEqual("MakerDraft 剩余", draft.remaining, CUP_CAPACITY - 160)
draft.layers = [fullLayer(grams: 250), fullLayer(grams: 250)]
checkEqual("MakerDraft 超容量剩余钳到 0", draft.remaining, 0)
draft.layers = [fullLayer(grams: 420)]
checkEqual("MakerDraft 恰好装满剩余 0", draft.remaining, 0)
let draftFromStoreInit = MakerDraft(beanId: "bean-9")
checkEqual("MakerDraft(beanId:) memberwise init", draftFromStoreInit.beanId, "bean-9")

// MARK: - 6. AppData 查询 / 汇总
section("6. AppData")

var appData = AppData()
checkEqual("AppData 默认 schemaVersion", appData.schemaVersion, 1)
checkEqual("AppData 默认 beans 为空", appData.beans.count, 0)
checkEqual("AppData 默认 recipes 为空", appData.recipes.count, 0)
checkEqual("AppData 默认 customIngredients 为空", appData.customIngredients.count, 0)
checkEqual("AppData.totalRemaining 空库", appData.totalRemaining, 0)

var beanA = fullBean(imagePath: nil)
beanA.id = "a"
beanA.remainingGrams = 50
var beanB = fullBean(imagePath: nil)
beanB.id = "b"
beanB.remainingGrams = 120
appData.beans = [beanA, beanB]
checkEqual("AppData.totalRemaining", appData.totalRemaining, 170)
checkEqual("AppData.bean(id)", appData.bean("a")?.name ?? "<nil>", "Ethiopia Guji")
checkEqual("AppData.bean(nil)", appData.bean(nil), nil)
checkEqual("AppData.bean(不存在)", appData.bean("missing"), nil)
appData.recipes = [fullRecipe()]
checkEqual("AppData.recipe(id)", appData.recipe("recipe-1")?.name ?? "<nil>", "测试配方")
checkEqual("AppData.recipe(不存在)", appData.recipe("missing"), nil)

// MARK: - 7. Codable 往返
section("7. Codable 往返")

let encoder = JSONEncoder()
encoder.outputFormatting = [.sortedKeys, .prettyPrinted]
let decoder = JSONDecoder()

do {
    let data = try encoder.encode(fullBean())
    let decoded = try decoder.decode(Bean.self, from: data)
    checkEqual("Bean Codable 往返相等", decoded, fullBean())

    let data2 = try encoder.encode(recipe)
    let decodedRecipe = try decoder.decode(Recipe.self, from: data2)
    checkEqual("Recipe Codable 往返相等", decodedRecipe, recipe)

    let layerData = try encoder.encode(fullLayer(grams: 42))
    let decodedLayer = try decoder.decode(RecipeLayer.self, from: layerData)
    checkEqual("RecipeLayer Codable 往返相等", decodedLayer, fullLayer(grams: 42))

    let customData = try encoder.encode(custom)
    let decodedCustom = try decoder.decode(CustomIngredient.self, from: customData)
    checkEqual("CustomIngredient Codable 往返相等", decodedCustom, custom)

    var app = AppData()
    app.beans = [beanA, beanB]
    app.recipes = [recipe]
    app.customIngredients = [custom]
    app.schemaVersion = 2
    let appDataEncoded = try encoder.encode(app)
    let appDecoded = try decoder.decode(AppData.self, from: appDataEncoded)
    checkEqual("AppData schemaVersion 往返", appDecoded.schemaVersion, 2)
    checkEqual("AppData beans 往返", appDecoded.beans, app.beans)
    checkEqual("AppData recipes 往返", appDecoded.recipes, app.recipes)
    checkEqual("AppData customIngredients 往返", appDecoded.customIngredients, app.customIngredients)

    let nilBeanIdRecipe = fullRecipe(beanId: nil)
    let nilRecipeData = try encoder.encode(nilBeanIdRecipe)
    let nilRecipeDecoded = try decoder.decode(Recipe.self, from: nilRecipeData)
    checkEqual("Recipe.beanId nil 往返", nilRecipeDecoded.beanId, nil)

    var nilImageBean = fullBean()
    nilImageBean.imagePath = nil
    let nilImageData = try encoder.encode(nilImageBean)
    let nilImageDecoded = try decoder.decode(Bean.self, from: nilImageData)
    checkEqual("Bean.imagePath nil 往返", nilImageDecoded.imagePath, nil)

    let imageBeanData = try encoder.encode(fullBean(imagePath: "bean_images/bean_X.png"))
    let imageBeanDecoded = try decoder.decode(Bean.self, from: imageBeanData)
    checkEqual("Bean.imagePath 路径往返", imageBeanDecoded.imagePath, "bean_images/bean_X.png")
} catch {
    fail("Codable 往返", "抛出异常: \(error)")
}

// MARK: - 8. JSON 字段契约（与 Android 版离线文件兼容的关键）
section("8. JSON 字段契约")

do {
    let beanDict = try jsonObject(fullBean(imagePath: nil))
    let expectedBeanKeys: Set<String> = [
        "id", "name", "roaster", "origin", "region", "process", "roast", "flavors",
        "totalGrams", "remainingGrams", "roastDate", "openedAt", "storage",
        "note", "createdAt", "lastUsedAt"
    ]
    checkEqual("Bean JSON 字段集合（imagePath=nil 时省略）", Set(beanDict.keys), expectedBeanKeys)
    checkEqual("Bean.roast 编码为大写 rawValue", beanDict["roast"] as? String ?? "<nil>", "LIGHT")
    checkEqual("Bean.storage 编码为大写 rawValue", beanDict["storage"] as? String ?? "<nil>", "ROOM")
    check("Bean.roastDate 编码为整数毫秒", beanDict["roastDate"] is NSNumber, "type = \(type(of: beanDict["roastDate"]!))")
    check("Bean.totalGrams 编码为数字", beanDict["totalGrams"] is NSNumber)
    check("Bean.flavors 编码为数组", beanDict["flavors"] is [Any])

    let beanWithImageDict = try jsonObject(fullBean(imagePath: "bean_images/x.png"))
    check("Bean JSON imagePath 有值时出现", beanWithImageDict["imagePath"] as? String == "bean_images/x.png")

    let recipeDict = try jsonObject(fullRecipe(beanId: nil))
    let expectedRecipeKeys: Set<String> = [
        "id", "name", "beanName", "layers", "rating", "notes", "mouthfeel",
        "sweetness", "beanGrams", "stirred", "createdAt"
    ]
    checkEqual("Recipe JSON 字段集合（beanId=nil 时省略）", Set(recipeDict.keys), expectedRecipeKeys)
    let layers = recipeDict["layers"] as? [[String: Any]]
    checkEqual("Recipe.layers JSON 数量", layers?.count ?? -1, 2)
    let layerKeys = Set(layers?.first?.keys.map { String($0) } ?? [])
checkEqual("RecipeLayer JSON 字段集合", layerKeys, Set(["ingredientId", "name", "colorHex", "kind", "grams", "alpha"]))
    checkEqual("RecipeLayer.kind 编码为大写 rawValue", layers?.first?["kind"] as? String ?? "<nil>", "LIQUID")

    let appDict = try jsonObject(AppData())
    checkEqual("AppData JSON 字段集合", Set(appDict.keys), Set(["schemaVersion", "beans", "recipes", "customIngredients"]))
    checkEqual("AppData.schemaVersion JSON", appDict["schemaVersion"] as? Int ?? -1, 1)

    // 稳定性：相同输入两次编码结果一致（sortedKeys）
    let sortedEncoder = JSONEncoder()
    sortedEncoder.outputFormatting = .sortedKeys
    let e1 = try sortedEncoder.encode(fullBean())
    let e2 = try sortedEncoder.encode(fullBean())
    check("同输入两次编码一致（确定性）", e1 == e2)
} catch {
    fail("JSON 字段契约", "抛出异常: \(error)")
}

// MARK: - 9. 兼容性风险探测（只报告，不改 App 代码）
section("9. 解码兼容性风险探测")

// 缺字段：AppData 用合成 Codable，没有自定义 init(from:)，缺字段会整体解码失败。
let missingCustom = #"{"schemaVersion":1,"beans":[],"recipes":[]}"#.data(using: .utf8)!
do {
    let decoded = try decoder.decode(AppData.self, from: missingCustom)
    warn("AppData 缺字段解码", "缺 customIngredients 时解码成功（schemaVersion=\(decoded.schemaVersion)）")
} catch {
    pass("AppData 缺字段解码失败（已确认风险）")
    note("风险：AppData 缺任一非可选字段即整体解码失败；AppStore.init 会静默回退到 DemoData.make()，旧数据/第三方文件可能丢失。")
}

// 未知枚举值：合成 Codable 会抛错，未来新增烘焙度/材料类型会导致旧版本打不开新导出文件。
let unknownRoast = #"{"id":"x","name":"n","roaster":"r","origin":"o","region":"","process":"水洗","roast":"TURBO","flavors":[],"totalGrams":150,"remainingGrams":150,"roastDate":0,"openedAt":0,"storage":"ROOM","note":"","createdAt":0,"lastUsedAt":0}"#.data(using: .utf8)!
do {
    _ = try decoder.decode(Bean.self, from: unknownRoast)
    warn("未知 Roast rawValue", "解码成功（意外宽松）")
} catch {
    pass("未知 Roast rawValue 解码失败（已确认风险）")
    note("风险：新增烘焙度取值后，旧版本 App 无法解码含新取值的 Bean/AppData。")
}

do {
    // 可选字段缺失（旧数据补字段场景）应成功。
    let missingOptional = #"{"id":"x","name":"n","roaster":"r","origin":"o","region":"","process":"水洗","roast":"LIGHT","flavors":[],"totalGrams":150,"remainingGrams":150,"roastDate":0,"openedAt":0,"storage":"ROOM","note":"","createdAt":0,"lastUsedAt":0}"#.data(using: .utf8)!
    let decoded = try decoder.decode(Bean.self, from: missingOptional)
    checkEqual("Bean 缺可选字段 imagePath 解码成功", decoded.imagePath, nil)
} catch {
    fail("Bean 缺可选字段解码", "\(error)")
}

do {
    // 未知顶层字段应被忽略（前向兼容）
    let extra = #"{"schemaVersion":1,"beans":[],"recipes":[],"customIngredients":[],"futureField":true}"#.data(using: .utf8)!
    let decoded = try decoder.decode(AppData.self, from: extra)
    checkEqual("AppData 未知字段被忽略", decoded.schemaVersion, 1)
} catch {
    fail("AppData 未知字段", "\(error)")
}

do {
    // 空 JSON 必须失败
    checkThrows("AppData 空 JSON 解码失败") {
        _ = try decoder.decode(AppData.self, from: Data("{}".utf8))
    }
}

// MARK: - 10. DemoData 完整性
section("10. DemoData.make() 完整性")

let demo = DemoData.make()
let demo2 = DemoData.make()

checkEqual("DemoData schemaVersion", demo.schemaVersion, 1)
checkEqual("DemoData 示例豆数量", demo.beans.count, 2)
checkEqual("DemoData 示例配方数量", demo.recipes.count, 3)
checkEqual("DemoData 自定义材料为空", demo.customIngredients.count, 0)
checkEqual("DemoData 豆 ID 唯一", Set(demo.beans.map(\.id)).count, demo.beans.count)
checkEqual("DemoData 配方 ID 唯一", Set(demo.recipes.map(\.id)).count, demo.recipes.count)
check("DemoData 豆 ID 非空", demo.beans.allSatisfy { !$0.id.isEmpty })
check("DemoData 配方 ID 非空", demo.recipes.allSatisfy { !$0.id.isEmpty })
check("DemoData 两次 make 生成不同 ID", Set(demo.beans.map(\.id)).isDisjoint(with: Set(demo2.beans.map(\.id))))

let now = nowMillis()
check("DemoData 豆 roastDate <= now", demo.beans.allSatisfy { $0.roastDate <= now })
check("DemoData 豆 openedAt <= now", demo.beans.allSatisfy { $0.openedAt <= now })
check("DemoData 豆 createdAt <= now", demo.beans.allSatisfy { $0.createdAt <= now })
check("DemoData 豆 lastUsedAt <= now", demo.beans.allSatisfy { $0.lastUsedAt <= now })
check("DemoData 豆 createdAt 合理（近 1 年）", demo.beans.allSatisfy { $0.createdAt >= now - 365 * DAY_MS })
check("DemoData 豆总克数 > 0", demo.beans.allSatisfy { $0.totalGrams > 0 })
check("DemoData 豆剩余克数 0...总量", demo.beans.allSatisfy { $0.remainingGrams >= 0 && $0.remainingGrams <= $0.totalGrams })
check("DemoData 豆赏味期年龄合理", demo.beans.allSatisfy { $0.ageDays >= 0 && $0.ageDays <= 365 })
check("DemoData 豆名称/烘焙商非空", demo.beans.allSatisfy { !$0.name.isEmpty && !$0.roaster.isEmpty })
check("DemoData 豆产地非空", demo.beans.allSatisfy { !$0.origin.isEmpty })
check("DemoData 豆风味非空", demo.beans.allSatisfy { !$0.flavors.isEmpty })
check("DemoData 豆 storage 合法", demo.beans.allSatisfy { Storage.allCases.contains($0.storage) })
check("DemoData 豆 roast 合法", demo.beans.allSatisfy { Roast.allCases.contains($0.roast) })

let beanIDs = Set(demo.beans.map(\.id))
check("DemoData 配方 beanId 均存在", demo.recipes.allSatisfy { recipe in
    guard let beanId = recipe.beanId else { return false }
    return beanIDs.contains(beanId)
})
check("DemoData 配方 beanName 与豆一致", demo.recipes.allSatisfy { recipe in
    guard let beanId = recipe.beanId, let bean = demo.beans.first(where: { $0.id == beanId }) else { return false }
    return recipe.beanName == bean.name
})
check("DemoData 配方层非空", demo.recipes.allSatisfy { !$0.layers.isEmpty })
check("DemoData 配方总克数 <= CUP_CAPACITY", demo.recipes.allSatisfy { $0.totalGrams <= CUP_CAPACITY })
check("DemoData 配方层克数 > 0", demo.recipes.allSatisfy { $0.layers.allSatisfy { $0.grams > 0 } })
check("DemoData 配方层 alpha 0...1", demo.recipes.allSatisfy { $0.layers.allSatisfy { $0.alpha >= 0 && $0.alpha <= 1 } })
check("DemoData 配方层颜色合法", demo.recipes.allSatisfy { $0.layers.allSatisfy { isHex6($0.colorHex) } })
check("DemoData 配方评分 1...5", demo.recipes.allSatisfy { $0.rating >= 1 && $0.rating <= 5 })
check("DemoData 配方用豆克数 > 0", demo.recipes.allSatisfy { $0.beanGrams > 0 })
check("DemoData 配方备注非空", demo.recipes.allSatisfy { !$0.notes.isEmpty })
check("DemoData 配方 createdAt <= now", demo.recipes.allSatisfy { $0.createdAt <= now })
check("DemoData 配方 createdAt 合理（近 1 年）", demo.recipes.allSatisfy { $0.createdAt >= now - 365 * DAY_MS })
check("DemoData 配方可筛选评分", demo.recipes.allSatisfy { (1...5).contains($0.rating) })

let builtinIDs = Set(Ingredients.builtIn.map(\.id))
let demoLayerIDs = Set(demo.recipes.flatMap { $0.layers.map(\.ingredientId) })
check("DemoData 配方层 ingredientId 均在内置材料中", demoLayerIDs.isSubset(of: builtinIDs), "缺: \(demoLayerIDs.subtracting(builtinIDs))")

// DemoData 产生的整库可完整 Codable 往返
do {
    let encoded = try encoder.encode(demo)
    let decoded = try decoder.decode(AppData.self, from: encoded)
    checkEqual("DemoData AppData Codable 往返 beans", decoded.beans, demo.beans)
    checkEqual("DemoData AppData Codable 往返 recipes", decoded.recipes, demo.recipes)
} catch {
    fail("DemoData Codable 往返", "\(error)")
}

// MARK: - 11. 内置材料库
section("11. Ingredients.builtIn")

checkEqual("内置材料数量", Ingredients.builtIn.count, 27)
checkEqual("内置材料 id 唯一", Set(Ingredients.builtIn.map(\.id)).count, Ingredients.builtIn.count)
check("内置材料 id/name 非空", Ingredients.builtIn.allSatisfy { !$0.id.isEmpty && !$0.name.isEmpty })
check("内置材料颜色合法", Ingredients.builtIn.allSatisfy { isHex6($0.colorHex) })
check("内置材料 rate > 0", Ingredients.builtIn.allSatisfy { $0.rate > 0 })
check("内置材料 alpha 0...1", Ingredients.builtIn.allSatisfy { $0.alpha >= 0 && $0.alpha <= 1 })
check("内置材料 isCustom 默认 false", Ingredients.builtIn.allSatisfy { !$0.isCustom })
check("内置材料含核心 id", ["espresso", "water", "milk", "ice", "soda"].allSatisfy { builtinIDs.contains($0) })
checkEqual("内置材料 alpha 半透明项", Ingredients.builtIn.first(where: { $0.id == "water" })?.alpha ?? -1, 0.55)

// MARK: - 12. 日期 / 时间辅助
section("12. 日期与时间辅助")

checkEqual("Int64.date 换算", Int64(1_700_000_000_000).date.timeIntervalSince1970, 1_700_000_000)
checkEqual("Date.millis 精确毫秒往返", Int64(1_700_000_000_123).date.millis, Int64(1_700_000_000_123))
check("nowMillis 与当前时间接近", abs(nowMillis() - Date().millis) < 2_000, "nowMillis=\(nowMillis()) date.millis=\(Date().millis)")

let feb14 = localDate(year: 2026, month: 2, day: 14)
let dec1 = localDate(year: 2025, month: 12, day: 1)
checkEqual("Date.dayLabel 2月14日", feb14.dayLabel, "2月14日")
checkEqual("Date.dayLabel 12月1日（月/日不补零）", dec1.dayLabel, "12月1日")
let morning = localDate(year: 2026, month: 11, day: 6, hour: 9, minute: 5)
checkEqual("Date.shortTime HH:mm", morning.shortTime, "09:05")
let midnight = localDate(year: 2026, month: 11, day: 6, hour: 0, minute: 0)
checkEqual("Date.shortTime 零点补零", midnight.shortTime, "00:00")

var todayRecipe = fullRecipe()
todayRecipe.createdAt = nowMillis()
check("Recipe.dateTitle 今天", todayRecipe.dateTitle.hasPrefix("今天 "), "\(todayRecipe.dateTitle)")
checkEqual("Recipe.dateTitle 今天时间", todayRecipe.dateTitle, "今天 " + Date().shortTime)
checkEqual("Recipe.localDate == createdAt.date", todayRecipe.localDate, todayRecipe.createdAt.date)

var yesterdayRecipe = fullRecipe()
yesterdayRecipe.createdAt = Calendar.current.startOfDay(for: Date()).addingTimeInterval(-3_600).millis
check("Recipe.dateTitle 昨天", yesterdayRecipe.dateTitle.hasPrefix("昨天 "), "dateTitle = \(yesterdayRecipe.dateTitle)")

var oldRecipe = fullRecipe()
oldRecipe.createdAt = localDate(year: 2025, month: 1, day: 2, hour: 15).millis
checkEqual("Recipe.dateTitle 更早日期", oldRecipe.dateTitle, "1月2日")

check("时区固定为 Asia/Shanghai", TimeZone.current.identifier == "Asia/Shanghai", "当前 = \(TimeZone.current.identifier)")

// MARK: - 13. 文本/旗帜辅助
section("13. formatGrams / originFlag")

checkEqual("formatGrams 整数", formatGrams(150), "150g")
checkEqual("formatGrams 0", formatGrams(0), "0g")
checkEqual("formatGrams 一位小数", formatGrams(149.5), "149.5g")
checkEqual("formatGrams 12.5", formatGrams(12.5), "12.5g")
checkEqual("formatGrams 1", formatGrams(1), "1g")
checkEqual("formatGrams 0.5", formatGrams(0.5), "0.5g")

let flagCases: [(String, String)] = [
    ("埃塞俄比亚", "🇪🇹"), ("肯尼亚", "🇰🇪"), ("卢旺达", "🇷🇼"), ("哥伦比亚", "🇨🇴"),
    ("巴西", "🇧🇷"), ("危地马拉", "🇬🇹"), ("哥斯达黎加", "🇨🇷"), ("巴拿马", "🇵🇦"),
    ("洪都拉斯", "🇭🇳"), ("秘鲁", "🇵🇪"), ("牙买加", "🇯🇲"), ("中国云南", "🇨🇳"),
    ("云南普洱", "🇨🇳"), ("印尼", "🇮🇩"), ("越南", "🇻🇳"), ("未知产区", "◌"), ("", "◌")
]
for (origin, flag) in flagCases {
    checkEqual("originFlag(\(origin.isEmpty ? "空" : origin))", originFlag(origin), flag)
}

// MARK: - 14. 汇总
print("\n=== SUMMARY ===")
print("PASS: \(gPassed)   FAIL: \(gFailed)   WARN: \(gWarnings.count)")
if !gWarnings.isEmpty {
    print("--- WARNINGS ---")
    for warning in gWarnings { print("WARN  \(warning)") }
}
print("EXIT CODE: \(gFailed == 0 ? 0 : 1)")
if gFailed > 0 {
    exit(1)
}
exit(0)
