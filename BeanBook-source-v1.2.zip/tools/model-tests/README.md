# tools/model-tests —— 无需 Xcode 的本地 QA 工具

本目录是 iOS 工程（`ios/BeanBook`）的**静态 QA + 可运行逻辑测试**工具集，配合 `docs/qa/qa-report.md` 使用。
它不修改 `ios/` 下任何文件，也不要求安装 Xcode：只需要 macOS 自带的 Command Line Tools（含 `swiftc`、`plutil`、`sips`）。

| 脚本 | 作用 |
| --- | --- |
| `run-tests.sh` | 把 `Models.swift` + 从 `Store.swift` 抽取的 `DemoData` + `ModelTests.swift` 编译成 macOS 可执行测试并真实运行（211 条断言） |
| `glass-typecheck/check-glass-api.sh` | 用 macOS 26 SDK 对 Theme/RootView 中的 Liquid Glass 代码做 `swiftc -typecheck`（含共享 `BottomActionBar` 声明与用法），并静态审计编译器门禁/可用性作用域双门禁、旧 Xcode 回退路径；检查器自带 5 个自测样例 |
| `project-check.sh` | `plutil -lint`、pbxproj Sources 完整性、Info.plist 键、AppIcon、权限描述键、CI 脚本交叉检查 |

## 运行

```bash
cd beans-app

# 1) 数据层逻辑测试（需要 CLT；输出 PASS/FAIL 与退出码）
./tools/model-tests/run-tests.sh
# 最近一次结果：PASS 211 / FAIL 0 / exit 0

# 2) Liquid Glass iOS 26 API 类型检查 + 门禁审计（含 Self-test）
./tools/model-tests/glass-typecheck/check-glass-api.sh
# 最近一次结果（2026-11-06 20:45）: PASS 6 / FAIL 0 / exit 0
#   SELFTEST_OK (5/5)，GATING_OK occurrences=9（Theme 3 + RootView 6），NO_LEAK

# 3) iOS 工程文件静态校验
./tools/model-tests/project-check.sh
# 最近一次结果：PASS 24 / FAIL 0 / exit 0
```

## ModelTests.swift 的设计说明

- `ios/BeanBook/Models.swift` 只 `import Foundation`，可以直接在 macOS 编译，测试的是**真实 App 源码**；
- `DemoData` 位于 `ios/BeanBook/Store.swift` 尾部，而 `Store.swift` 依赖 UIKit/Combine，无法整体在 macOS 编译。
  `run-tests.sh` 构建时用 `awk` 把 `DemoData` 枚举**原样抽取**并补一行 `import Foundation`（Swift 的 import 是文件级作用域），
  因此 App 源码改动会自动进入测试，不存在手工复制副本漂移；
- Swift 规定多文件编译时顶层可执行代码只能写在 `main.swift`，所以脚本把 `ModelTests.swift` 原样复制成
  `build/main.swift` 再编译；`ModelTests.swift` 本身仍保持“顶层 main 代码”形态；
- 测试固定 `Asia/Shanghai` 时区（脚本同时设置 `TZ` 与测试内 `NSTimeZone.default`），日期断言与运行机器时区无关；
- 断言失败输出 `FAIL` 并以退出码 1 结束；`WARN`/`NOTE` 只提示风险，不影响退出码。

## 检查器说明

- `check 4` 的判定按**花括号作用域**（不是行距窗口）：符号必须在 `#if compiler(>=6.2)` 真分支内，且位于 `if #available(iOS 26.0, *)` 真分支或 `@available(iOS 26.0, *)` 标注的声明体内；`if #available` 的 else 分支不算；
- 内置 5 个自测样例：2 类违规必须被抓到、3 类合规写法不得误报（`SELFTEST_OK (5/5)`），防止审计脚本本身退化为“永远 PASS”；
- iOS 26 符号清单包含 `Glass`、`GlassEffectContainer`、`glassEffect`、`glassEffectID`、`glassEffectTransition`、`liquidGlassStyle`；
- BottomBar 检查的 stub 需与 RootView 实际引用的 `C` 颜色同步（当前含 `ink/lime/limeDeep/limeSoft/lineSoft/muted`）。

## 局限（必须在报告中如实对待）

- 本机**没有 iOS SDK**，`swiftc -parse` 只能验证语法，不能验证 iOS 目标下的类型检查；
- UIKit / SwiftUI 视图层（约 15 个 View 文件）无法在 macOS 编译，只能做静态审查；
- Liquid Glass 检查利用「iOS 26 与 macOS 26 的 SwiftUI Glass API 相同」这一事实在 macOS 26 SDK 上做类型检查，
  真正的 `-target arm64-apple-ios26.0` 编译仍必须由 Xcode 26 完成。
