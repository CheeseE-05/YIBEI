#!/usr/bin/env bash
# BeanBook iOS 工程静态校验（不需要 Xcode）：plist、pbxproj Sources、Info.plist 键、AppIcon、权限描述键。
# 用法：cd beans-app && ./tools/model-tests/project-check.sh
# 退出码：0 = 全部 PASS；1 = 有 FAIL；2 = 工程文件缺失。

set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
IOS="$ROOT/ios"
SRC="$IOS/BeanBook"
PBX="$IOS/BeanBook.xcodeproj/project.pbxproj"
PLIST="$SRC/Info.plist"
PASS=0
FAIL=0

pass() { PASS=$((PASS + 1)); echo "PASS  $*"; }
fail() { FAIL=$((FAIL + 1)); echo "FAIL  $*"; }
info() { echo "INFO  $*"; }

for required in "$PBX" "$PLIST" "$SRC/Assets.xcassets/AppIcon.appiconset/AppIcon.png"; do
    [ -f "$required" ] || { echo "FATAL: 缺少 $required" >&2; exit 2; }
done

echo "== BeanBook iOS 工程静态校验 =="

# ---------- 1. plist 语法 ----------
if plutil -lint "$PBX" >/dev/null 2>&1; then pass "plutil -lint project.pbxproj"; else fail "plutil -lint project.pbxproj"; fi
if plutil -lint "$PLIST" >/dev/null 2>&1; then pass "plutil -lint Info.plist"; else fail "plutil -lint Info.plist"; fi

# ---------- 2. BeanBook/ 下每个 .swift 都在 PBXSourcesBuildPhase 中 ----------
SOURCES_BLOCK="$(awk '/Begin PBXSourcesBuildPhase section/,/End PBXSourcesBuildPhase section/' "$PBX")"
MISSING=""
for f in "$SRC"/*.swift; do
    name="$(basename "$f")"
    if ! printf '%s\n' "$SOURCES_BLOCK" | grep -qF "$name in Sources"; then
        MISSING="$MISSING $name"
    fi
done
if [ -z "$MISSING" ]; then
    pass "BeanBook/*.swift 全部出现在 PBXSourcesBuildPhase（$(ls "$SRC"/*.swift | wc -l | tr -d ' ') 个）"
else
    fail "以下 .swift 未加入 PBXSourcesBuildPhase:$MISSING"
fi

# 反向：pbxproj 里列出的 .swift 都必须真实存在（排除 sourcecode.swift 这种文件类型标识）
PBX_SWIFT_NAMES="$(grep -oE '[A-Za-z0-9_]+\.swift' "$PBX" | grep -v '^sourcecode\.swift$' | sort -u)"
PHANTOM=""
for name in $PBX_SWIFT_NAMES; do
    [ -f "$SRC/$name" ] || PHANTOM="$PHANTOM $name"
done
if [ -z "$PHANTOM" ]; then pass "pbxproj 引用的 .swift 文件均存在"; else fail "pbxproj 引用了不存在的文件:$PHANTOM"; fi

# ---------- 3. Info.plist 关键键 ----------
plist_value() { /usr/libexec/PlistBuddy -c "Print :$1" "$PLIST" 2>/dev/null; }
check_key() {
    local key="$1" expected="$2"
    local actual
    actual="$(plist_value "$key")"
    if [ "$actual" = "$expected" ]; then
        pass "Info.plist $key = $actual"
    elif [ -z "$actual" ]; then
        fail "Info.plist 缺少键 ${key}（期望 ${expected}）"
    else
        fail "Info.plist ${key} = ${actual}（期望 ${expected}）"
    fi
}
check_key "CFBundleDisplayName" "忆杯手记"
check_key "CFBundlePackageType" "APPL"
check_key "CFBundleShortVersionString" "1.2"
check_key "CFBundleVersion" "3"
check_key "LSRequiresIPhoneOS" "true"
if plist_value "UIUserInterfaceStyle" >/dev/null 2>&1; then
    pass "Info.plist 未固定 UIUserInterfaceStyle（支持跟随系统深浅色）"
else
    pass "Info.plist 未固定 UIUserInterfaceStyle（支持跟随系统深浅色）"
fi
check_key "UIRequiresFullScreen" "false"
check_key "UIApplicationSupportsIndirectInputEvents" "true"
check_key "CFBundleDevelopmentRegion" "zh_CN"

if /usr/libexec/PlistBuddy -c "Print :UILaunchScreen" "$PLIST" >/dev/null 2>&1; then
    pass "Info.plist 含 UILaunchScreen"
else
    fail "Info.plist 缺少 UILaunchScreen"
fi
ORIENTATIONS="$(plist_value "UISupportedInterfaceOrientations")"
if printf '%s' "$ORIENTATIONS" | grep -q "UIInterfaceOrientationPortrait"; then
    pass "Info.plist UISupportedInterfaceOrientations 含 Portrait"
else
    fail "Info.plist UISupportedInterfaceOrientations 异常: $ORIENTATIONS"
fi

# bundle id / 部署目标 / scheme 名称
if grep -q 'PRODUCT_BUNDLE_IDENTIFIER = com.brewkin.beanbook.ios;' "$PBX"; then
    pass "pbxproj bundle id = com.brewkin.beanbook.ios"
else
    fail "pbxproj bundle id 不是 com.brewkin.beanbook.ios"
fi
if [ "$(grep -c 'IPHONEOS_DEPLOYMENT_TARGET = 17.0;' "$PBX")" -ge 2 ]; then
    pass "pbxproj IPHONEOS_DEPLOYMENT_TARGET = 17.0"
else
    fail "pbxproj 部署目标不是 17.0"
fi
if grep -q 'INFOPLIST_FILE = BeanBook/Info.plist;' "$PBX" && grep -q 'GENERATE_INFOPLIST_FILE = NO;' "$PBX"; then
    pass "target 使用自定义 Info.plist（GENERATE_INFOPLIST_FILE = NO）"
else
    fail "target Info.plist 配置异常"
fi
if [ -f "$IOS/BeanBook.xcodeproj/xcshareddata/xcschemes/BeanBook.xcscheme" ]; then
    pass "shared scheme BeanBook 存在"
else
    fail "缺少 shared scheme BeanBook.xcscheme"
fi

# ---------- 4. AppIcon ----------
ICON="$SRC/Assets.xcassets/AppIcon.appiconset/AppIcon.png"
ICON_JSON="$SRC/Assets.xcassets/AppIcon.appiconset/Contents.json"
DIMS="$(sips -g pixelWidth -g pixelHeight "$ICON" 2>/dev/null | awk '/pixel/{print $2}' | tr '\n' 'x')"
if [ "$DIMS" = "1024x1024x" ] || [ "$DIMS" = "1024x1024" ]; then
    pass "AppIcon.png = 1024x1024"
else
    fail "AppIcon.png 尺寸异常: $DIMS"
fi
if grep -q '"filename" : "AppIcon.png"' "$ICON_JSON" && grep -q '"size" : "1024x1024"' "$ICON_JSON"; then
    pass "AppIcon Contents.json 引用 1024x1024 AppIcon.png"
else
    fail "AppIcon Contents.json 内容异常"
fi
if file "$ICON" | grep -qi 'RGB'; then
    pass "AppIcon.png 为 RGB（无 alpha 通道）"
else
    info "AppIcon.png 可能含 alpha 通道，App Store 提交时需注意"
fi
if grep -q 'ASSETCATALOG_COMPILER_APPICON_NAME = AppIcon;' "$PBX"; then
    pass "pbxproj 配置 AppIcon"
else
    fail "pbxproj 未配置 ASSETCATALOG_COMPILER_APPICON_NAME"
fi

# ---------- 5. 隐私权限描述键 vs 代码实际行为 ----------
CODE="$SRC"
USES_CAMERA="$(grep -rlE 'AVCaptureDevice|UIImagePickerController|AVCaptureSession' "$CODE" | wc -l | tr -d ' ')"
USES_PHOTO_WRITE="$(grep -rlE 'UIImageWriteToSavedPhotosAlbum|PHPhotoLibrary|performChanges.*creationRequestForAsset|creationRequestForAssetFromImage' "$CODE" | wc -l | tr -d ' ')"
USES_LOCATION="$(grep -rlE 'CLLocationManager|MKMapView' "$CODE" | wc -l | tr -d ' ')"
USES_MIC="$(grep -rlE 'AVAudioSession|AVAudioRecorder' "$CODE" | wc -l | tr -d ' ')"
USES_PHOTOS_PICKER="$(grep -rlE 'PhotosPicker|photosPicker|PHPicker' "$CODE" | wc -l | tr -d ' ')"

info "相机代码文件数=$USES_CAMERA 相册写入=$USES_PHOTO_WRITE 定位=$USES_LOCATION 麦克风=$USES_MIC PhotosPicker=$USES_PHOTOS_PICKER"

has_plist_key() { /usr/libexec/PlistBuddy -c "Print :$1" "$PLIST" >/dev/null 2>&1; }

if [ "$USES_CAMERA" -gt 0 ]; then
    if has_plist_key "NSCameraUsageDescription"; then pass "有相机代码且含 NSCameraUsageDescription"; else fail "有相机代码但缺少 NSCameraUsageDescription"; fi
fi
if [ "$USES_PHOTO_WRITE" -gt 0 ]; then
    if has_plist_key "NSPhotoLibraryAddUsageDescription"; then pass "有相册写入且含 NSPhotoLibraryAddUsageDescription"; else fail "有相册写入但缺少 NSPhotoLibraryAddUsageDescription"; fi
else
    pass "无相册写入代码（仅 PhotosPicker 选择，不需要 NSPhotoLibraryAddUsageDescription）"
fi
if [ "$USES_LOCATION" -gt 0 ] && ! has_plist_key "NSLocationWhenInUseUsageDescription"; then
    fail "有定位代码但缺少 NSLocationWhenInUseUsageDescription"
fi
if [ "$USES_MIC" -gt 0 ] && ! has_plist_key "NSMicrophoneUsageDescription"; then
    fail "有麦克风代码但缺少 NSMicrophoneUsageDescription"
fi

echo
echo "== SUMMARY: PASS=$PASS FAIL=$FAIL =="
[ "$FAIL" -eq 0 ] || exit 1
exit 0
