package com.brewkin.beanbook.data

import java.time.ZonedDateTime
import java.util.UUID

object DemoData {
    fun create(): AppState {
        val now = System.currentTimeMillis()
        val zone = ZonedDateTime.now().zone
        fun daysAgo(days: Long, hour: Int = 9): Long =
            ZonedDateTime.now(zone).minusDays(days).withHour(hour).withMinute(20)
                .withSecond(0).withNano(0).toInstant().toEpochMilli()

        fun hoursAgo(hours: Long): Long = now - hours * 60L * 60L * 1000L

        val guji = Bean(
            id = UUID.randomUUID().toString(),
            name = "Ethiopia Guji",
            roaster = "Coffee Buff",
            origin = "埃塞俄比亚",
            region = "Guji",
            process = "水洗",
            roast = Roast.LIGHT,
            flavors = listOf("茉莉", "柠檬", "红茶感"),
            totalGrams = 150.0,
            remainingGrams = 86.0,
            roastDate = daysAgo(9, 10),
            openedAt = daysAgo(7, 10),
            note = "手冲很干净，做成 Dirty 会有很亮的柑橘尾韵。",
            createdAt = daysAgo(9),
            lastUsedAt = hoursAgo(20)
        )
        val lychee = Bean(
            id = UUID.randomUUID().toString(),
            name = "Colombia Lychee",
            roaster = "RAW",
            origin = "哥伦比亚",
            region = "Huila",
            process = "蜜处理",
            roast = Roast.MEDIUM_LIGHT,
            flavors = listOf("荔枝", "白葡萄", "焦糖"),
            totalGrams = 200.0,
            remainingGrams = 146.0,
            roastDate = daysAgo(3, 12),
            openedAt = daysAgo(2, 12),
            note = "开袋就是荔枝糖的甜香，适合和气泡水做一杯。",
            createdAt = daysAgo(3),
            lastUsedAt = hoursAgo(4)
        )

        val lycheeSoda = Recipe(
            id = UUID.randomUUID().toString(),
            name = "荔枝气泡冷萃",
            beanId = lychee.id,
            beanName = lychee.name,
            layers = listOf(
                RecipeLayer("ice", "冰块", "#DDE6E3", IngredientKind.ICE, 60, 0.55f),
                RecipeLayer("soda", "气泡水", "#E3E9E5", IngredientKind.SPARKLING, 100, 0.55f),
                RecipeLayer("coldbrew", "冷萃", "#3B2414", IngredientKind.LIQUID, 60)
            ),
            rating = 5,
            notes = "荔枝壳与白葡萄的香气被气泡托起来，最后一点焦糖甜留得很长。",
            mouthfeel = "清爽",
            sweetness = "微甜",
            beanGrams = 18,
            createdAt = hoursAgo(4)
        )

        val osmanthusLatte = Recipe(
            id = UUID.randomUUID().toString(),
            name = "桂花燕麦拿铁",
            beanId = guji.id,
            beanName = guji.name,
            layers = listOf(
                RecipeLayer("osmanthus", "桂花糖浆", "#D9A441", IngredientKind.SYRUP, 12),
                RecipeLayer("espresso", "浓缩", "#2A1708", IngredientKind.LIQUID, 36),
                RecipeLayer("oat", "燕麦奶", "#E8D9BC", IngredientKind.LIQUID, 150),
                RecipeLayer("foam", "奶泡", "#FAF5E9", IngredientKind.FOAM, 26)
            ),
            rating = 4,
            notes = "燕麦奶的谷物甜把桂花衬得很温柔，下次奶温再低一点。",
            mouthfeel = "均衡",
            sweetness = "甜感适中",
            beanGrams = 16,
            createdAt = hoursAgo(26)
        )

        val dirty = Recipe(
            id = UUID.randomUUID().toString(),
            name = "Guji Dirty",
            beanId = guji.id,
            beanName = guji.name,
            layers = listOf(
                RecipeLayer("milk", "牛奶", "#F1EADB", IngredientKind.LIQUID, 150),
                RecipeLayer("espresso", "浓缩", "#2A1708", IngredientKind.LIQUID, 40)
            ),
            rating = 4,
            notes = "不搅拌，第一口是热的浓缩，第二口撞进冰牛奶里。",
            mouthfeel = "浓郁",
            sweetness = "微甜",
            beanGrams = 18,
            createdAt = hoursAgo(76)
        )

        return AppState(
            beans = listOf(lychee, guji),
            recipes = listOf(lycheeSoda, osmanthusLatte, dirty)
        )
    }
}
