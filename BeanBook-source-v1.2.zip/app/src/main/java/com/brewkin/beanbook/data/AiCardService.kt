package com.brewkin.beanbook.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.addJsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import java.io.BufferedReader
import java.net.HttpURLConnection
import java.net.URL

/** AI 返回的卡片文案草稿（本地渲染，不做图像生成）。 */
data class AiCardDraft(
    val title: String = "",
    val subtitle: String = "",
    val tags: List<String> = emptyList(),
    val themeColorHex: String? = null,
    val template: String? = null
)

/**
 * OpenAI 兼容 chat/completions 客户端（只依赖 HttpURLConnection + kotlinx.serialization，无新依赖）。
 * Base URL 支持 `https://api.openai.com/v1`、`.../v1/chat/completions` 或自定义反代根地址。
 */
object AiCardService {
    private val json = Json { ignoreUnknownKeys = true; isLenient = true }

    private fun endpoint(baseUrl: String): String {
        val base = baseUrl.trim().trimEnd('/')
        return when {
            base.endsWith("/chat/completions") -> base
            base.endsWith("/v1") -> "$base/chat/completions"
            else -> "$base/v1/chat/completions"
        }
    }

    /** 连通性测试：GET /v1/models（OpenAI 兼容服务通用；本地 mock 也支持）。 */
    suspend fun testConnection(config: AiConfig): Result<String> = runCatching {
        if (config.apiKey.isBlank()) throw IllegalStateException("还没有填写 API Key")
        val modelsUrl = modelsEndpoint(config.baseUrl)
        withContext(Dispatchers.IO) {
            val connection = (URL(modelsUrl).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 15_000
                readTimeout = 30_000
                setRequestProperty("Authorization", "Bearer ${config.apiKey.trim()}")
            }
            try {
                val code = connection.responseCode
                val text = (if (code in 200..299) connection.inputStream else connection.errorStream)
                    ?.bufferedReader(Charsets.UTF_8)?.use(BufferedReader::readText).orEmpty()
                if (code !in 200..299) {
                    val message = runCatching {
                        json.parseToJsonElement(text).jsonObject["error"]?.jsonObject
                            ?.get("message")?.jsonPrimitive?.contentOrNull
                    }.getOrNull()
                    throw IllegalStateException(message ?: "连接失败（HTTP $code）")
                }
                val count = runCatching {
                    json.parseToJsonElement(text).jsonObject["data"]?.jsonArray?.size
                }.getOrNull()
                if (count != null) "连接成功（$count 个可用模型）" else "连接成功"
            } finally {
                connection.disconnect()
            }
        }
    }

    private fun modelsEndpoint(baseUrl: String): String {
        val base = baseUrl.trim().trimEnd('/')
        return when {
            base.endsWith("/chat/completions") -> base.removeSuffix("/chat/completions") + "/models"
            base.endsWith("/v1") -> "$base/models"
            else -> "$base/v1/models"
        }
    }

    suspend fun generateCard(
        config: AiConfig,
        description: String,
        recipeName: String,
        existingTags: List<String>
    ): Result<AiCardDraft> = runCatching {
        val prompt = buildString {
            appendLine("你是咖啡品牌「忆杯手记」的文案。请为下面这杯咖啡生成一张横版宣传卡片的文案与配色建议。")
            appendLine("咖啡名：$recipeName")
            if (existingTags.isNotEmpty()) appendLine("已有风味标签：${existingTags.joinToString("、")}")
            appendLine("用户描述：$description")
            appendLine()
            appendLine("只输出严格 JSON（不要 markdown 代码块，不要多余解释），字段要求：")
            appendLine("- title: 卡片大标题，中文，不超过 12 个字，有画面感但不要浮夸")
            appendLine("- subtitle: 一行副标题/品鉴笔记，中文，不超过 30 个字")
            appendLine("- tags: 3 到 4 个中文风味标签，每个不超过 6 个字")
            appendLine("- theme: 从 LIME / BUTTER / ROSE / SKY / INK 中选一个最贴合的主题")
            appendLine("- template: 从 LIGHT / DARK / LIME 中选一个模板")
        }
        val content = chat(config, prompt)
        parseDraft(content)
    }

    private suspend fun chat(config: AiConfig, userPrompt: String): String = withContext(Dispatchers.IO) {
        if (config.apiKey.isBlank()) throw IllegalStateException("还没有填写 API Key")
        if (config.model.isBlank()) throw IllegalStateException("还没有填写模型名")
        val payload = buildJsonObject {
            put("model", config.model)
            putJsonArray("messages") {
                addJsonObject {
                    put("role", "user")
                    put("content", userPrompt)
                }
            }
            put("temperature", 0.8)
        }
        val connection = (URL(endpoint(config.baseUrl)).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15_000
            readTimeout = 60_000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Authorization", "Bearer ${config.apiKey.trim()}")
        }
        try {
            connection.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val text = (if (code in 200..299) connection.inputStream else connection.errorStream)
                ?.bufferedReader(Charsets.UTF_8)?.use(BufferedReader::readText).orEmpty()
            if (code !in 200..299) {
                val message = runCatching {
                    json.parseToJsonElement(text).jsonObject["error"]?.jsonObject
                        ?.get("message")?.jsonPrimitive?.contentOrNull
                }.getOrNull()
                throw IllegalStateException(message ?: "AI 请求失败（HTTP $code）")
            }
            val root = json.parseToJsonElement(text).jsonObject
            root["choices"]?.jsonArray?.firstOrNull()?.jsonObject
                ?.get("message")?.jsonObject?.get("content")?.jsonPrimitive?.contentOrNull
                ?.takeIf { it.isNotBlank() }
                ?: throw IllegalStateException("AI 返回内容为空")
        } finally {
            connection.disconnect()
        }
    }

    /** 从可能带 ```json 代码块/前后说明的文字里抠出第一个合法 JSON 对象。 */
    fun parseDraft(raw: String): AiCardDraft {
        val start = raw.indexOf('{')
        val end = raw.lastIndexOf('}')
        if (start < 0 || end <= start) throw IllegalStateException("AI 返回的不是 JSON：${raw.take(80)}")
        val body = raw.substring(start, end + 1)
        val element = json.parseToJsonElement(body).jsonObject
        fun str(key: String): String = element[key]?.jsonPrimitive?.contentOrNull?.trim().orEmpty()
        val tags = element["tags"]?.jsonArray?.mapNotNull { it.jsonPrimitive.contentOrNull?.trim() }
            ?.filter { it.isNotBlank() }?.take(5).orEmpty()
        return AiCardDraft(
            title = str("title").take(24),
            subtitle = str("subtitle").take(60),
            tags = tags,
            themeColorHex = str("theme").takeIf { it.isNotBlank() },
            template = str("template").takeIf { it.isNotBlank() }
        )
    }
}
