package com.brewkin.beanbook.data

import android.content.Context
import android.graphics.Bitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import java.io.File
import java.util.UUID

class BeanRepository(private val context: Context) {
    private val json = Json {
        prettyPrint = true
        ignoreUnknownKeys = true
        encodeDefaults = true
    }
    private val file = File(context.filesDir, "beanbook.json")
    private val mutex = Mutex()

    private val _state = MutableStateFlow(load())
    val state: StateFlow<AppState> = _state.asStateFlow()

    private fun load(): AppState {
        val loaded = runCatching {
            if (file.exists()) json.decodeFromString(AppState.serializer(), file.readText()) else null
        }.getOrNull()
        if (loaded != null) return loaded
        val seed = DemoData.create()
        runCatching { writeBlocking(seed) }
        return seed
    }

    suspend fun update(transform: (AppState) -> AppState) {
        mutex.withLock {
            val next = transform(_state.value)
            withContext(Dispatchers.IO) { writeBlocking(next) }
            _state.value = next
        }
    }

    private fun writeBlocking(state: AppState) {
        file.parentFile?.mkdirs()
        val tmp = File(file.parentFile, "${file.name}.tmp")
        tmp.writeText(json.encodeToString(AppState.serializer(), state))
        if (!tmp.renameTo(file)) {
            file.writeText(tmp.readText())
            tmp.delete()
        }
    }

    fun saveBeanImage(bitmap: Bitmap): String? = runCatching {
        val dir = File(context.filesDir, "bean_images").apply { mkdirs() }
        val name = "bean_${UUID.randomUUID()}.png"
        val out = File(dir, name)
        out.outputStream().use { stream ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
        }
        "bean_images/$name"
    }.getOrNull()

    fun beanImageFile(path: String?): File? {
        if (path.isNullOrBlank()) return null
        val f = if (path.startsWith("/")) File(path) else File(context.filesDir, path)
        return f.takeIf { it.exists() }
    }

    fun deleteBeanImage(path: String?) {
        beanImageFile(path)?.delete()
    }
}
