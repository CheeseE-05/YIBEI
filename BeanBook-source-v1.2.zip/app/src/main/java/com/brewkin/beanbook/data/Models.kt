package com.brewkin.beanbook.data

import kotlinx.serialization.Serializable
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.ChronoUnit

const val CUP_CAPACITY = 420

@Serializable
enum class Roast(val label: String, val short: String, val toneHex: String) {
    LIGHT("浅烘", "浅", "#DCC99A"),
    MEDIUM_LIGHT("中浅烘", "中浅", "#C9A875"),
    MEDIUM("中烘", "中", "#AE8253"),
    MEDIUM_DARK("中深烘", "中深", "#805535"),
    DARK("深烘", "深", "#50301C")
}

@Serializable
enum class Storage(val label: String) {
    ROOM("常温"),
    FRIDGE("冷藏"),
    FREEZER("冷冻")
}

@Serializable
enum class IngredientKind(val label: String) {
    LIQUID("液体"),
    FOAM("奶泡"),
    SYRUP("糖浆"),
    PUREE("果泥"),
    CHUNK("果肉"),
    ICE("冰块"),
    SPARKLING("气泡")
}

data class IngredientSpec(
    val id: String,
    val name: String,
    val colorHex: String,
    val rate: Int,
    val kind: IngredientKind,
    val alpha: Float = 1f,
    val isCustom: Boolean = false
)

@Serializable
data class CustomIngredient(
    val id: String,
    val name: String,
    val colorHex: String,
    val kind: IngredientKind = IngredientKind.LIQUID,
    val createdAt: Long = System.currentTimeMillis()
) {
    fun toSpec(): IngredientSpec = IngredientSpec(
        id = id,
        name = name,
        colorHex = colorHex,
        rate = when (kind) {
            IngredientKind.SYRUP -> 12
            IngredientKind.FOAM -> 20
            IngredientKind.PUREE, IngredientKind.CHUNK -> 24
            IngredientKind.ICE -> 80
            IngredientKind.SPARKLING -> 45
            IngredientKind.LIQUID -> 34
        },
        kind = kind,
        isCustom = true
    )
}

@Serializable
data class Bean(
    val id: String,
    val name: String,
    val roaster: String = "",
    val origin: String = "",
    val region: String = "",
    val process: String = "水洗",
    val roast: Roast = Roast.MEDIUM,
    val flavors: List<String> = emptyList(),
    val totalGrams: Double = 150.0,
    val remainingGrams: Double = 150.0,
    val roastDate: Long = System.currentTimeMillis(),
    val openedAt: Long = System.currentTimeMillis(),
    val storage: Storage = Storage.ROOM,
    val imagePath: String? = null,
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val lastUsedAt: Long = 0L
) {
    val displayOrigin: String
        get() = origin.ifBlank { "未记录产地" }

    val flavorLine: String
        get() = flavors.take(3).joinToString(" · ").ifBlank { process }

    fun remainingRatio(): Float {
        if (totalGrams <= 0.0) return 0f
        return (remainingGrams / totalGrams).toFloat().coerceIn(0f, 1f)
    }
}

@Serializable
data class RecipeLayer(
    val ingredientId: String,
    val name: String,
    val colorHex: String,
    val kind: IngredientKind = IngredientKind.LIQUID,
    val grams: Int,
    val alpha: Float = 1f
)

/** 横版宣传卡片配置（持久化到 Recipe 的可选字段，旧数据反序列化为 null，完全兼容）。 */
/** 卡片上每个元素在横/竖版中的归一化位置、缩放与对齐（旧数据无此字段）。 */
@Serializable
data class ElementPlacement(
    /** 元素左上角归一化坐标（0..1，相对卡面宽/高）。 */
    val x: Float,
    val y: Float,
    /** 文字字号缩放 / 图片缩放，1 = 自动排版大小。 */
    val scale: Float = 1f,
    /** LEFT / CENTER / RIGHT（仅文字有意义）。 */
    val align: String = "AUTO",
    /** 每元素独立字号（pt，8–72；0 或空 = 使用默认自动字号）。 */
    val fontSizePt: Float = 0f,
    /** 自动排版时的真实宽度（归一化，用于手动布局保持换行与碰撞框；0 = 未记录）。 */
    val width: Float = 0f,
    /** 自动排版时的真实高度（归一化）。 */
    val height: Float = 0f
)

/** 卡片各文案元素的可编辑文本；空字符串 = 使用配方自动生成的默认文案。 */
@Serializable
data class CardCopy(
    val category: String = "",
    val meta: String = "",
    val price: String = "",
    val englishName: String = "",
    val chineseName: String = "",
    /** 旧版合并字段（中文\\n英文），iOS 同款拆分字段为空时回退到这里。 */
    val ingredients: String = "",
    val flavors: String = "",
    val keywords: String = "",
    /** 1.2 card editor v3（iOS 同款拆分字段；旧数据为空 = 自动生成）。 */
    val ingredientsChinese: String = "",
    val ingredientsEnglish: String = "",
    val flavorsChinese: String = "",
    val flavorsEnglish: String = ""
)

/** 每个文字元素的独立字号（设计点 pt，8–72；横/竖版分别保存）。 */
@Serializable
data class CardFontSizes(
    val portrait: Map<String, Float> = emptyMap(),
    val landscape: Map<String, Float> = emptyMap()
) {
    fun forOrientation(orientation: String): Map<String, Float> =
        if (orientation == "PORTRAIT") portrait else landscape

    fun isEmpty(): Boolean = portrait.isEmpty() && landscape.isEmpty()
}

@Serializable
data class RecipeCardConfig(
    val template: String = "LIGHT",
    val themeColorHex: String = "#A3CD39",
    val title: String = "",
    val subtitle: String = "",
    val tags: List<String> = emptyList(),
    /** CUP / BEAN / GALLERY / ILLUSTRATION（AI 手绘）/ IMPORTED（相册抠图透明图） */
    val coverKind: String = "CUP",
    val coverImagePath: String? = null,
    /** LANDSCAPE（16:9）/ PORTRAIT（3:4） */
    val orientation: String = "LANDSCAPE",
    /** AI 插画在 App 私有目录中的相对路径（1.3 新增，旧数据为 null） */
    val illustrationPath: String? = null,
    /** AI 插画原始生成图（未抠图/未去水印）路径，保留用于重试/回退；旧数据为 null。 */
    val illustrationRawPath: String? = null,
    /** 实物图 → 插画 prompt 的原始照片路径（可选；旧数据为 null）。 */
    val photoPromptImagePath: String? = null,
    /** prompt 来源：空 = 默认配方 prompt；PHOTO_VISION（图片理解 API）/ PHOTO_LOCAL（本地降级）。 */
    val promptSource: String = "",
    /** 相册导入并自动抠图后的透明 PNG 相对路径（1.3 新增，旧数据为 null） */
    val importedImagePath: String? = null,
    /** NONE / AI / IMPORTED；记录插画来源，旧数据为 NONE。 */
    val illustrationSource: String = "NONE",
    /** 生成插画时使用的 prompt（便于复现/重新生成）。 */
    val illustrationPrompt: String = "",
    /** 相册导入时保存的原图（抠图失败/改用原图时回退）。 */
    val importedOriginalImagePath: String? = null,
    /** 主视觉是否加柔和阴影（iOS 同款开关，默认关：手绘卡直接叠在纸上）。 */
    val illustrationShadow: Boolean = false,
    /** 导出尺寸：SOCIAL（社交分享图）/ PRINT_A6（A6 300dpi 打印）。 */
    val exportSize: String = "SOCIAL",
    val brand: String = "忆杯手记",
    val aiPrompt: String = "",
    /** 1.3 卡片编辑器 v3：所有元素的文案覆盖（空 = 自动生成）。 */
    val copy: CardCopy = CardCopy(),
    /** 隐藏的元素 id：CATEGORY/META/PRICE/ENGLISH/CHINESE/INGREDIENTS/FLAVORS/KEYWORDS/ILLUSTRATION。 */
    val hidden: List<String> = emptyList(),
    /** 横版手动排版（归一化），键为元素 id；旧数据为空 = 自动排版。 */
    val landscapeLayout: Map<String, ElementPlacement> = emptyMap(),
    /** 竖版手动排版（归一化）。 */
    val portraitLayout: Map<String, ElementPlacement> = emptyMap(),
    /** 每元素独立字号（pt，横/竖版分别保存；旧数据为空 = 使用默认字号）。 */
    val fontSizes: CardFontSizes = CardFontSizes(),
    val updatedAt: Long = 0L
)

@Serializable
data class Recipe(
    val id: String,
    val name: String,
    val beanId: String? = null,
    val beanName: String = "",
    val layers: List<RecipeLayer> = emptyList(),
    val rating: Int = 4,
    val notes: String = "",
    val mouthfeel: String = "均衡",
    val sweetness: String = "甜感适中",
    val beanGrams: Int = 15,
    val stirred: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    /** 菜单价格（元）；0 或 null 表示未设置。旧 JSON 兼容。 */
    val price: Int? = null,
    /** 1.3：该配方的随杯卡配置；旧数据为 null。 */
    val card: RecipeCardConfig? = null
) {
    val totalGrams: Int get() = layers.sumOf { it.grams }
    val coffeeGrams: Int get() = layers.filter {
        it.ingredientId in setOf("espresso", "coldbrew", "water", "matcha", "blacktea", "oolong")
    }.sumOf { it.grams }
}

@Serializable
data class AppState(
    val schemaVersion: Int = 1,
    val beans: List<Bean> = emptyList(),
    val recipes: List<Recipe> = emptyList(),
    val customIngredients: List<CustomIngredient> = emptyList()
) {
    fun beanById(id: String?): Bean? = beans.firstOrNull { it.id == id }
    fun recipeById(id: String?): Recipe? = recipes.firstOrNull { it.id == id }
    fun recentBeans(limit: Int = 4): List<Bean> =
        beans.sortedWith(compareByDescending<Bean> { it.lastUsedAt }.thenByDescending { it.createdAt }).take(limit)

    fun recentRecipes(limit: Int = 3): List<Recipe> =
        recipes.sortedByDescending { it.createdAt }.take(limit)

    fun totalRemaining(): Double = beans.sumOf { it.remainingGrams }
}

enum class BeanStatus(val label: String, val bgHex: String, val inkHex: String) {
    RESTING("养豆中", "#F3E8BE", "#6E5B22"),
    PEAK("最佳赏味期", "#E7F0C7", "#536A1A"),
    STABLE("风味稳定", "#DDE9EE", "#3E5E6A"),
    FADING("风味衰退期", "#F0DED7", "#7A4A37"),
    FROZEN("冷冻中", "#DCE7F2", "#3D5873")
}

fun Bean.status(now: Long = System.currentTimeMillis()): BeanStatus {
    if (storage == Storage.FREEZER) return BeanStatus.FROZEN
    val zone = ZoneId.systemDefault()
    val roastDay = Instant.ofEpochMilli(roastDate).atZone(zone).toLocalDate()
    val today = Instant.ofEpochMilli(now).atZone(zone).toLocalDate()
    val days = ChronoUnit.DAYS.between(roastDay, today).toInt()
    return when {
        days < 4 -> BeanStatus.RESTING
        days <= 30 -> BeanStatus.PEAK
        days <= 45 -> BeanStatus.STABLE
        else -> BeanStatus.FADING
    }
}

fun Bean.ageDays(now: Long = System.currentTimeMillis()): Int {
    val zone = ZoneId.systemDefault()
    val roastDay = Instant.ofEpochMilli(roastDate).atZone(zone).toLocalDate()
    val today = Instant.ofEpochMilli(now).atZone(zone).toLocalDate()
    return ChronoUnit.DAYS.between(roastDay, today).toInt().coerceAtLeast(0)
}

fun Bean.peakHint(now: Long = System.currentTimeMillis()): String = when (status(now)) {
    BeanStatus.RESTING -> "再养 ${(4 - ageDays(now)).coerceAtLeast(1)} 天"
    BeanStatus.PEAK -> "第 ${ageDays(now)} 天 · 正好喝"
    BeanStatus.STABLE -> "第 ${ageDays(now)} 天 · 尽快喝完"
    BeanStatus.FADING -> "已开 ${ageDays(now)} 天"
    BeanStatus.FROZEN -> "冷冻保存"
}

fun Recipe.periodLabel(): String {
    val date = Instant.ofEpochMilli(createdAt).atZone(ZoneId.systemDefault()).toLocalDate()
    return date.toString()
}

fun Recipe.localDate(): LocalDate =
    Instant.ofEpochMilli(createdAt).atZone(ZoneId.systemDefault()).toLocalDate()
