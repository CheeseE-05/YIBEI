package com.brewkin.beanbook.data

import android.graphics.Bitmap
import android.graphics.Color
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.addJsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import kotlinx.serialization.json.putJsonObject
import java.io.BufferedReader
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * 「实物图 → 插画 prompt」图片理解服务（OpenAI 兼容 chat + image_url content）。
 *
 * - 默认智谱 `https://open.bigmodel.cn/api/paas/v4` + `glm-4v-flash`（Key 用户自填）；
 * - 也可在设置里换成任意 OpenAI 兼容视觉模型；
 * - 未配置 / 调用失败 → [localFallbackPrompt] 用照片主色/亮度 + 配方本地降级；
 * - 输出 prompt 限制 ≤200 字符且明确透明背景、无文字无水印。
 */
object AiVisionService {
    private val json = Json { ignoreUnknownKeys = true; isLenient = true }

    /** 仅作为描述兜底长度上限；透明底风格后缀由 ImageGenService.composePrompt 统一补全。 */
    private const val MAX_DESCRIPTION = 600

    private fun endpoint(baseUrl: String): String {
        val base = baseUrl.trim().trimEnd('/')
        return when {
            base.endsWith("/chat/completions") -> base
            base.endsWith("/v1") -> "$base/chat/completions"
            base.endsWith("/images/generations") -> base.removeSuffix("/images/generations") + "/chat/completions"
            else -> "$base/v1/chat/completions"
        }
    }

    suspend fun describeForIllustration(
        config: VisionConfig,
        photo: Bitmap,
        recipe: Recipe,
        bean: Bean?
    ): Result<String> = runCatching {
        if (!config.isReady) throw IllegalStateException("未配置图片理解 API")
        withContext(Dispatchers.IO) {
            val dataUrl = "data:image/jpeg;base64," + Base64.encodeToString(imageToJpegBase64(photo), Base64.NO_WRAP)
            val recipeHint = buildString {
                append("这杯叫「${recipe.name}」")
                if (bean != null) append("，豆子：${bean.name}")
                val layers = recipe.layers.map { it.name }.distinct().take(6)
                if (layers.isNotEmpty()) append("，配方层次：${layers.joinToString("、")}")
            }
            val payload = buildJsonObject {
                put("model", config.model.trim())
                put("temperature", 0.6)
                putJsonArray("messages") {
                    addJsonObject {
                        put("role", "system")
                        put(
                            "content",
                            "你是咖啡插画提示词助手。根据实物照片写一句英文插画 prompt：描述主体造型、杯型/器皿、层次颜色、配料点缀、构图与光线；" +
                                "只输出 prompt 本身，不要解释、不要 Markdown、不要任何文字/水印需求；控制在 120 字符内。"
                        )
                    }
                    addJsonObject {
                        put("role", "user")
                        putJsonArray("content") {
                            addJsonObject {
                                put("type", "text")
                                put("text", "请为这张咖啡实物照片写插画 prompt。$recipeHint")
                            }
                            addJsonObject {
                                put("type", "image_url")
                                putJsonObject("image_url") {
                                    put("url", dataUrl)
                                }
                            }
                        }
                    }
                }
            }
            val connection = (URL(endpoint(config.baseUrl)).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 20_000
                readTimeout = 90_000
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("Authorization", "Bearer ${config.apiKey.trim()}")
            }
            try {
                connection.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
                val code = connection.responseCode
                val text = (if (code in 200..299) connection.inputStream else connection.errorStream)
                    ?.bufferedReader(Charsets.UTF_8)?.use(BufferedReader::readText).orEmpty()
                if (code !in 200..299) {
                    val message = runCatching {
                        json.parseToJsonElement(text).jsonObject["error"]?.jsonObject
                            ?.get("message")?.jsonPrimitive?.contentOrNull
                    }.getOrNull()
                    throw IllegalStateException(message ?: "图片理解失败（HTTP $code）")
                }
                val content = json.parseToJsonElement(text).jsonObject["choices"]?.jsonArray
                    ?.firstOrNull()?.jsonObject?.get("message")?.jsonObject
                    ?.get("content")?.jsonPrimitive?.contentOrNull
                    ?: throw IllegalStateException("图片理解接口没有返回内容")
                cleanDescription(content)
            } finally {
                connection.disconnect()
            }
        }
    }

    /** 未配置/失败时的本地降级：照片主色/亮度 + 配方生成描述（仍有透明底/无文字要求）。 */
    fun localFallbackPrompt(photo: Bitmap, recipe: Recipe, bean: Bean?): String {
        val (r, g, b) = averageColor(photo)
        val brightness = (0.299f * r + 0.587f * g + 0.114f * b) / 255f
        val tone = when {
            brightness > 0.72f -> "bright, airy"
            brightness > 0.5f -> "soft, warm"
            else -> "rich, moody"
        }
        val photoColor = "#%02X%02X%02X".format(r, g, b)
        val layers = recipe.layers.map { it.name }.distinct().take(4).joinToString(", ")
        val base = buildString {
            append("A coffee drink illustration inspired by a real photo")
            append(", ${recipe.name}")
            if (bean != null && bean.name.isNotBlank()) append(" with ${bean.name}")
            if (layers.isNotBlank()) append(", ingredients: $layers")
            append(", photo palette $photoColor, $tone light")
            if (bean != null && bean.flavors.isNotEmpty()) {
                append(", flavor notes ${bean.flavors.take(2).joinToString(", ")}")
            }
        }
        return cleanDescription(base)
    }

    private fun cleanDescription(raw: String): String {
        val clean = raw
            .replace("\r", " ")
            .replace("\n", " ")
            .replace(Regex("\\s+"), " ")
            .trim()
            .trim('"', '\'', '`', '。', '.', ',', '，')
        if (clean.isBlank()) return ""
        return if (clean.length <= MAX_DESCRIPTION) clean else clean.take(MAX_DESCRIPTION)
    }

    private fun imageToJpegBase64(photo: Bitmap): ByteArray {
        val longest = maxOf(photo.width, photo.height)
        val scaled = if (longest <= 768) photo else {
            val scale = 768f / longest
            Bitmap.createScaledBitmap(
                photo,
                (photo.width * scale).toInt().coerceAtLeast(1),
                (photo.height * scale).toInt().coerceAtLeast(1),
                true
            )
        }
        val out = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.JPEG, 82, out)
        if (scaled !== photo) scaled.recycle()
        return out.toByteArray()
    }

    private fun averageColor(photo: Bitmap): Triple<Int, Int, Int> {
        val w = photo.width
        val h = photo.height
        if (w < 2 || h < 2) return Triple(200, 180, 150)
        var rs = 0L; var gs = 0L; var bs = 0L; var n = 0L
        val step = maxOf(1, minOf(w, h) / 64)
        var y = 0
        while (y < h) {
            var x = 0
            while (x < w) {
                val p = photo.getPixel(x, y)
                rs += Color.red(p); gs += Color.green(p); bs += Color.blue(p); n++
                x += step
            }
            y += step
        }
        if (n == 0L) return Triple(200, 180, 150)
        return Triple((rs / n).toInt(), (gs / n).toInt(), (bs / n).toInt())
    }
}
