package com.brewkin.beanbook.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** OpenAI 兼容 API 配置。 */
data class AiConfig(
    val baseUrl: String = DEFAULT_AI_BASE_URL,
    val apiKey: String = "",
    val model: String = DEFAULT_AI_MODEL
) {
    val isReady: Boolean get() = apiKey.isNotBlank() && model.isNotBlank()
}

const val DEFAULT_VISION_BASE_URL = "https://open.bigmodel.cn/api/paas/v4"
const val DEFAULT_VISION_MODEL = "glm-4v-flash"

/** 图片理解 API（OpenAI 兼容 chat + image_url；用于「实物图 → 插画 prompt」）。 */
data class VisionConfig(
    val baseUrl: String = DEFAULT_VISION_BASE_URL,
    val apiKey: String = "",
    val model: String = DEFAULT_VISION_MODEL
) {
    val isReady: Boolean get() = apiKey.isNotBlank() && baseUrl.isNotBlank() && model.isNotBlank()
}

const val DEFAULT_AI_BASE_URL = "https://api.openai.com/v1"
const val DEFAULT_AI_MODEL = "gpt-4o-mini"
const val DEFAULT_IMAGE_MODEL = "glm-image"
const val DEFAULT_IMAGE_SIZE = "1024x1440"
const val DEFAULT_IMAGE_BASE_URL = "https://open.bigmodel.cn/api/paas/v4"

object ImageProvider {
    const val ZHIPU = "ZHIPU"
    const val SILICONFLOW = "SILICONFLOW"
    const val CUSTOM = "CUSTOM"
    val all = listOf(ZHIPU, SILICONFLOW, CUSTOM)
    fun label(id: String): String = when (id) {
        ZHIPU -> "智谱 BigModel · GLM-Image"
        SILICONFLOW -> "硅基流动"
        else -> "自定义"
    }
    fun defaults(id: String): Pair<String, String> = when (id) {
        ZHIPU -> "https://open.bigmodel.cn/api/paas/v4" to "glm-image"
        SILICONFLOW -> "https://api.siliconflow.cn/v1" to "Kwai-Kolors/Kolors"
        else -> "" to ""
    }
}

/** GLM-Image / 兼容网关可用尺寸（官方要求 512–2048、32 的倍数）。 */
object ImageSizes {
    val presets = listOf(
        "1024x1440" to "竖版 5:7",
        "1440x1024" to "横版 5:7",
        "1280x1280" to "1:1",
        "1728x960" to "16:9"
    )
    val presetValues = presets.map { it.first }

    /** 校验自定义尺寸：宽高都 512–2048 且为 32 的倍数。 */
    fun validate(size: String): String? {
        val parts = size.lowercase().trim().split("x")
        if (parts.size != 2) return "尺寸格式应为 宽x高，如 1024x1440"
        val w = parts[0].toIntOrNull() ?: return "尺寸格式应为 宽x高，如 1024x1440"
        val h = parts[1].toIntOrNull() ?: return "尺寸格式应为 宽x高，如 1024x1440"
        if (w !in 512..2048 || h !in 512..2048) return "宽高需在 512–2048 之间"
        if (w % 32 != 0 || h % 32 != 0) return "宽高需为 32 的倍数（如 1024x1440）"
        return null
    }

    /** 未显式指定尺寸时按卡片方向选：竖版 1024×1440、横版 1440×1024。 */
    fun forOrientation(orientation: String, configured: String): String {
        val value = configured.trim()
        return when {
            orientation == "PORTRAIT" && value !in presetValues -> "1024x1440"
            orientation != "PORTRAIT" && value !in presetValues -> "1440x1024"
            orientation == "PORTRAIT" -> "1024x1440"
            else -> "1440x1024"
        }
    }
}

/** 插画生成（OpenAI 兼容 images/generations）配置，独立 Base URL / Key / 模型 / 尺寸。 */
data class ImageGenConfig(
    val provider: String = ImageProvider.ZHIPU,
    val baseUrl: String = DEFAULT_IMAGE_BASE_URL,
    val apiKey: String = "",
    val model: String = DEFAULT_IMAGE_MODEL,
    val size: String = DEFAULT_IMAGE_SIZE
) {
    val isReady: Boolean get() = apiKey.isNotBlank() && baseUrl.isNotBlank() && model.isNotBlank()
}

/** 文案 API 预设。 */
object TextProvider {
    const val DEEPSEEK = "DEEPSEEK"
    const val OPENAI = "OPENAI"
    const val CUSTOM = "CUSTOM"
    val all = listOf(DEEPSEEK, OPENAI, CUSTOM)
    fun label(id: String): String = when (id) {
        DEEPSEEK -> "DeepSeek"
        OPENAI -> "OpenAI"
        else -> "自定义"
    }
    fun defaults(id: String): Pair<String, String> = when (id) {
        DEEPSEEK -> "https://api.deepseek.com/v1" to "deepseek-chat"
        OPENAI -> "https://api.openai.com/v1" to "gpt-4o-mini"
        else -> "" to ""
    }
}

/** 外观模式。 */
object ThemeMode {
    const val SYSTEM = "system"
    const val LIGHT = "light"
    const val DARK = "dark"
    val all = listOf(SYSTEM, LIGHT, DARK)
    fun label(mode: String): String = when (mode) {
        LIGHT -> "浅色"
        DARK -> "深色"
        else -> "跟随系统"
    }
}

/**
 * 本机设置持久化（SharedPreferences）。
 * AI 配置 + 外观模式；数据仍由 BeanRepository 保存。
 */
class SettingsStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("beanbook_settings", Context.MODE_PRIVATE)

    private val _themeMode = MutableStateFlow(prefs.getString(KEY_THEME_MODE, ThemeMode.SYSTEM) ?: ThemeMode.SYSTEM)
    val themeMode: StateFlow<String> = _themeMode.asStateFlow()

    private val _aiConfig = MutableStateFlow(
        AiConfig(
            baseUrl = prefs.getString(KEY_AI_BASE_URL, DEFAULT_AI_BASE_URL) ?: DEFAULT_AI_BASE_URL,
            apiKey = prefs.getString(KEY_AI_KEY, "") ?: "",
            model = prefs.getString(KEY_AI_MODEL, DEFAULT_AI_MODEL) ?: DEFAULT_AI_MODEL
        )
    )
    val aiConfig: StateFlow<AiConfig> = _aiConfig.asStateFlow()

    fun setThemeMode(mode: String) {
        val safe = if (mode in ThemeMode.all) mode else ThemeMode.SYSTEM
        prefs.edit().putString(KEY_THEME_MODE, safe).apply()
        _themeMode.value = safe
    }

    fun saveAiConfig(config: AiConfig) {
        prefs.edit()
            .putString(KEY_AI_BASE_URL, config.baseUrl.trim())
            .putString(KEY_AI_KEY, config.apiKey.trim())
            .putString(KEY_AI_MODEL, config.model.trim())
            .apply()
        _aiConfig.value = config.copy(
            baseUrl = config.baseUrl.trim(),
            apiKey = config.apiKey.trim(),
            model = config.model.trim()
        )
    }

    private val _imageConfig = MutableStateFlow(
        ImageGenConfig(
            provider = prefs.getString(KEY_IMAGE_PROVIDER, ImageProvider.ZHIPU) ?: ImageProvider.ZHIPU,
            baseUrl = prefs.getString(KEY_IMAGE_BASE_URL, DEFAULT_IMAGE_BASE_URL) ?: DEFAULT_IMAGE_BASE_URL,
            apiKey = prefs.getString(KEY_IMAGE_KEY, "") ?: "",
            model = prefs.getString(KEY_IMAGE_MODEL, DEFAULT_IMAGE_MODEL) ?: DEFAULT_IMAGE_MODEL,
            size = prefs.getString(KEY_IMAGE_SIZE, DEFAULT_IMAGE_SIZE) ?: DEFAULT_IMAGE_SIZE
        )
    )
    val imageConfig: StateFlow<ImageGenConfig> = _imageConfig.asStateFlow()

    fun saveImageConfig(config: ImageGenConfig) {
        val clean = config.copy(
            baseUrl = config.baseUrl.trim().trimEnd('/'),
            apiKey = config.apiKey.trim(),
            model = config.model.trim(),
            size = config.size.trim()
        )
        prefs.edit()
            .putString(KEY_IMAGE_PROVIDER, clean.provider)
            .putString(KEY_IMAGE_BASE_URL, clean.baseUrl)
            .putString(KEY_IMAGE_KEY, clean.apiKey)
            .putString(KEY_IMAGE_MODEL, clean.model)
            .putString(KEY_IMAGE_SIZE, clean.size)
            .apply()
        _imageConfig.value = clean
    }

    private val _visionConfig = MutableStateFlow(
        VisionConfig(
            baseUrl = prefs.getString(KEY_VISION_BASE_URL, DEFAULT_VISION_BASE_URL) ?: DEFAULT_VISION_BASE_URL,
            apiKey = prefs.getString(KEY_VISION_KEY, "") ?: "",
            model = prefs.getString(KEY_VISION_MODEL, DEFAULT_VISION_MODEL) ?: DEFAULT_VISION_MODEL
        )
    )
    val visionConfig: StateFlow<VisionConfig> = _visionConfig.asStateFlow()

    fun saveVisionConfig(config: VisionConfig) {
        val clean = config.copy(
            baseUrl = config.baseUrl.trim().trimEnd('/'),
            apiKey = config.apiKey.trim(),
            model = config.model.trim()
        )
        prefs.edit()
            .putString(KEY_VISION_BASE_URL, clean.baseUrl)
            .putString(KEY_VISION_KEY, clean.apiKey)
            .putString(KEY_VISION_MODEL, clean.model)
            .apply()
        _visionConfig.value = clean
    }

    fun resetVisionConfig() {
        prefs.edit()
            .putString(KEY_VISION_BASE_URL, DEFAULT_VISION_BASE_URL)
            .putString(KEY_VISION_KEY, "")
            .putString(KEY_VISION_MODEL, DEFAULT_VISION_MODEL)
            .apply()
        _visionConfig.value = VisionConfig()
    }

    fun resetImageConfig() {
        val defaults = ImageGenConfig()
        saveImageConfig(defaults)
    }

    fun resetAiConfig() {
        prefs.edit()
            .putString(KEY_AI_BASE_URL, DEFAULT_AI_BASE_URL)
            .putString(KEY_AI_KEY, "")
            .putString(KEY_AI_MODEL, DEFAULT_AI_MODEL)
            .apply()
        _aiConfig.value = AiConfig()
    }

    private companion object {
        const val KEY_THEME_MODE = "theme_mode"
        const val KEY_AI_BASE_URL = "ai_base_url"
        const val KEY_AI_KEY = "ai_api_key"
        const val KEY_AI_MODEL = "ai_model"
        const val KEY_VISION_BASE_URL = "ai_vision_base_url"
        const val KEY_VISION_KEY = "ai_vision_key"
        const val KEY_VISION_MODEL = "ai_vision_model"
        const val KEY_IMAGE_PROVIDER = "ai_image_provider"
        const val KEY_IMAGE_BASE_URL = "ai_image_base_url"
        const val KEY_IMAGE_KEY = "ai_image_key"
        const val KEY_IMAGE_MODEL = "ai_image_model"
        const val KEY_IMAGE_SIZE = "ai_image_size"
    }
}
