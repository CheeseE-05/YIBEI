package com.brewkin.beanbook.data

import android.content.Context
import android.net.Uri
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import java.io.File
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.UUID

object BackupManager {
    const val MIME_JSON = "application/json"
    private const val IMAGE_DIR = "bean_images"

    private val json = Json {
        prettyPrint = true
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    fun backupFileName(): String =
        "YIBEI-Backup-${LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmm"))}.json"

    fun recipeFileName(recipeName: String): String {
        val safe = recipeName
            .replace(Regex("[\\\\/:*?\"<>|\\s]+"), "_")
            .take(28)
            .trim('_')
            .ifBlank { "recipe" }
        return "${safe}-${LocalDateTime.now().format(DateTimeFormatter.ofPattern("MMdd-HHmm"))}.brewkinrecipe.json"
    }

    suspend fun exportDatabase(context: Context, state: AppState, uri: Uri): Unit =
        withContext(Dispatchers.IO) {
            val images = buildMap {
                state.beans.mapNotNull { it.imagePath }.distinct().forEach { path ->
                    imageBase64(context, path)?.let { put(path, it) }
                }
            }
            val bundle = DatabaseBundle(data = state, images = images)
            val text = json.encodeToString(DatabaseBundle.serializer(), bundle)
            writeText(context, uri, text)
        }

    suspend fun importDatabase(
        context: Context,
        uri: Uri,
        current: AppState,
        mode: DatabaseImportMode
    ): Pair<AppState, TransferOutcome> = withContext(Dispatchers.IO) {
        val root = readJson(context, uri)
        val kind = root.jsonObject["kind"]?.jsonPrimitive?.content
        if (kind != DatabaseBundle.KIND_DATABASE) {
            throw IllegalArgumentException("这不是豆仓的整库备份文件。请选择 .json 备份。")
        }
        val bundle = json.decodeFromJsonElement(DatabaseBundle.serializer(), root)
        writeImages(context, bundle.images)
        val imported = bundle.data
        if (mode == DatabaseImportMode.REPLACE) {
            imported to TransferOutcome(
                message = "已恢复 ${imported.beans.size} 支豆子、${imported.recipes.size} 杯配方",
                importedRecipes = imported.recipes.size,
                importedBeans = imported.beans.size,
                importedIngredients = imported.customIngredients.size
            )
        } else {
            val existingRecipes = current.recipes.map { it.id }.toSet()
            val existingBeans = current.beans.map { it.id }.toSet()
            val existingIngredients = current.customIngredients.map { it.id }.toSet()
            val newRecipes = imported.recipes.filterNot { it.id in existingRecipes }
            val newBeans = imported.beans.filterNot { it.id in existingBeans }
            val newIngredients = imported.customIngredients.filterNot { it.id in existingIngredients }
            val merged = current.copy(
                beans = current.beans + newBeans,
                recipes = (newRecipes + current.recipes).distinctBy { it.id },
                customIngredients = current.customIngredients + newIngredients
            )
            merged to TransferOutcome(
                message = "已合并导入 ${newBeans.size} 支豆子、${newRecipes.size} 杯配方",
                importedRecipes = newRecipes.size,
                importedBeans = newBeans.size,
                importedIngredients = newIngredients.size,
                skipped = (imported.beans.size - newBeans.size) + (imported.recipes.size - newRecipes.size)
            )
        }
    }

    suspend fun importRecipeShare(
        context: Context,
        uri: Uri,
        current: AppState
    ): Pair<AppState, TransferOutcome> = withContext(Dispatchers.IO) {
        val root = readJson(context, uri)
        val kind = root.jsonObject["kind"]?.jsonPrimitive?.content
        if (kind != RecipeShareBundle.KIND_RECIPE) {
            throw IllegalArgumentException("这不是离线配方文件。请选择 .brewkinrecipe.json 文件。")
        }
        val bundle = json.decodeFromJsonElement(RecipeShareBundle.serializer(), root)
        val now = System.currentTimeMillis()
        var beans = current.beans
        var beanId: String? = null
        var importedBean = false

        val sourceBean = bundle.bean
        if (sourceBean != null) {
            val existing = beans.firstOrNull {
                it.name.trim().equals(sourceBean.name.trim(), ignoreCase = true) &&
                    it.roaster.trim().equals(sourceBean.roaster.trim(), ignoreCase = true)
            }
            if (existing != null) {
                beanId = existing.id
                val newImagePath = bundle.beanImageBase64?.let { writeImage(context, it) }
                if (existing.imagePath == null && newImagePath != null) {
                    beans = beans.map { if (it.id == existing.id) it.copy(imagePath = newImagePath) else it }
                }
            } else {
                val targetId = if (beans.any { it.id == sourceBean.id }) UUID.randomUUID().toString() else sourceBean.id
                val newImagePath = bundle.beanImageBase64?.let { writeImage(context, it) }
                val copied = sourceBean.copy(id = targetId, imagePath = newImagePath)
                beans = listOf(copied) + beans
                beanId = targetId
                importedBean = true
            }
        } else {
            beanId = bundle.recipe.beanId?.takeIf { id -> current.beans.any { it.id == id } }
        }

        var ingredients = current.customIngredients
        var importedIngredientCount = 0
        bundle.customIngredients.forEach { ingredient ->
            if (ingredients.none { it.id == ingredient.id }) {
                ingredients = ingredients + ingredient
                importedIngredientCount++
            }
        }

        val idConflict = current.recipes.any { it.id == bundle.recipe.id }
        val importedId = if (idConflict) UUID.randomUUID().toString() else bundle.recipe.id
        val nameConflict = current.recipes.any { it.name.trim() == bundle.recipe.name.trim() }
        val importedRecipe = bundle.recipe.copy(
            id = importedId,
            name = if (nameConflict) "${bundle.recipe.name}（导入）" else bundle.recipe.name,
            beanId = beanId,
            beanName = beans.firstOrNull { it.id == beanId }?.name ?: bundle.recipe.beanName,
            createdAt = now
        )
        val next = current.copy(
            beans = beans,
            recipes = listOf(importedRecipe) + current.recipes,
            customIngredients = ingredients
        )
        next to TransferOutcome(
            message = "已导入配方「${importedRecipe.name}」" +
                if (importedBean) "，并新增了 1 支豆子" else "",
            importedRecipes = 1,
            importedBeans = if (importedBean) 1 else 0,
            importedIngredients = importedIngredientCount
        )
    }

    suspend fun createRecipeShareFile(
        context: Context,
        recipe: Recipe,
        bean: Bean?,
        customIngredients: List<CustomIngredient>
    ): File = withContext(Dispatchers.IO) {
        val image = bean?.imagePath?.let { imageBase64(context, it) }
        val bundle = RecipeShareBundle(
            recipe = recipe,
            bean = bean,
            beanImageBase64 = image,
            customIngredients = customIngredients.filter { custom ->
                recipe.layers.any { it.ingredientId == custom.id }
            }
        )
        val text = json.encodeToString(RecipeShareBundle.serializer(), bundle)
        val dir = File(context.cacheDir, "exports").apply { mkdirs() }
        File(dir, recipeFileName(recipe.name)).apply { writeText(text) }
    }

    private fun readJson(context: Context, uri: Uri) = run {
        val text = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
            ?: throw IllegalArgumentException("文件读不出来。")
        json.parseToJsonElement(text)
    }

    private fun writeText(context: Context, uri: Uri, text: String) {
        context.contentResolver.openOutputStream(uri, "wt")?.bufferedWriter()?.use { it.write(text) }
            ?: throw IllegalStateException("无法写入所选文件。")
    }

    private fun imageBase64(context: Context, path: String): String? = runCatching {
        val file = File(context.filesDir, path)
        if (!file.exists()) return null
        Base64.encodeToString(file.readBytes(), Base64.NO_WRAP)
    }.getOrNull()

    private fun writeImage(context: Context, base64: String): String {
        val bytes = Base64.decode(base64, Base64.DEFAULT)
        val dir = File(context.filesDir, IMAGE_DIR).apply { mkdirs() }
        val name = "import_${UUID.randomUUID()}.png"
        File(dir, name).writeBytes(bytes)
        return "$IMAGE_DIR/$name"
    }

    private fun writeImages(context: Context, images: Map<String, String>) {
        val dir = File(context.filesDir, IMAGE_DIR).apply { mkdirs() }
        images.forEach { (path, encoded) ->
            if (!path.startsWith("$IMAGE_DIR/") || path.contains("..") || path.contains('\\')) return@forEach
            val target = File(context.filesDir, path)
            if (!target.canonicalPath.startsWith(dir.canonicalPath + File.separator)) return@forEach
            runCatching {
                target.writeBytes(Base64.decode(encoded, Base64.DEFAULT))
            }
        }
    }
}
