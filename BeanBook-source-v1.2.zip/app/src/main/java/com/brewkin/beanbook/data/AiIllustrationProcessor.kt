package com.brewkin.beanbook.data

import android.graphics.Bitmap
import android.graphics.Color
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** AI 插画后处理结果：透明 PNG（既有 alpha / 纯色背景键控 / 棋盘格透明底）+ 水印清理。 */
data class AiIllustrationProcessResult(
    val bitmap: Bitmap,
    val backgroundKeyed: Boolean,
    val watermarkBlobsRemoved: Int,
    val warning: String? = null,
    /** 背景处理方式：KEPT_ALPHA / COLOR_KEY / CHECKERBOARD / NONE。 */
    val mode: String = "NONE"
)

/**
 * AI 插画专用透明化处理（不使用 U²-Net）：
 * 1. 返回图**本身带 alpha**（透明 PNG）→ 直接裁透明外边距后保留；
 * 2. 纯色背景 → 四边 2% 环带中位数估计背景色，颜色键控 + 四边连通域（主体内部近背景色不被误抠）；
 * 3. 模型画了「棋盘格透明底」→ 检测双色棋盘（两个高亮低饱和色交替）并作为背景整体键控；
 * 4. 背景不纯 → 回退原图并提示；
 * 5. 外圈小面积低饱和/近白灰（或小面积深色文字）独立连通块清理（AI 水印/角标）；
 * 6. 裁透明外边距 + 短边 1.5%（≥3px）padding，输出 ARGB_8888 透明 PNG。
 */
object AiIllustrationProcessor {
    private const val RING_RATIO = 0.02f
    private const val RING_TOLERANCE = 46f
    private const val PURE_BG_RATIO = 0.82f
    private const val KEY_FULL = 48f
    private const val CROP_ALPHA = 8

    suspend fun process(source: Bitmap): Result<AiIllustrationProcessResult> =
        withContext(Dispatchers.Default) { runCatching { processSync(source) } }

    fun processSync(source: Bitmap): AiIllustrationProcessResult {
        val w = source.width
        val h = source.height
        if (w < 16 || h < 16) {
            return AiIllustrationProcessResult(source, false, 0, "插画尺寸过小，已保留原图")
        }
        val pixels = IntArray(w * h)
        source.getPixels(pixels, 0, w, 0, 0, w, h)

        // 1) 返回图已有 alpha：直接保留透明（仅裁透明外边距）
        if (source.hasAlpha()) {
            val transparent = countTransparent(pixels)
            if (transparent > pixels.size * 0.01f) {
                val cropped = cropToContent(pixels, w, h) ?: return AiIllustrationProcessResult(
                    source, true, 0, "已保留透明背景（图片已带 alpha）", "KEPT_ALPHA"
                )
                return AiIllustrationProcessResult(
                    cropped, true, 0, "已保留透明背景（图片自带 alpha 通道）", "KEPT_ALPHA"
                )
            }
        }

        // 2) 估计背景色（1 个纯色，或 2 色棋盘格）
        val estimate = estimateBackground(pixels, w, h)
            ?: return AiIllustrationProcessResult(source, false, 0, "没有识别到纯色/棋盘格背景，已保留原图")
        val bgColors = estimate.colors

        // 3) 背景纯度检查
        val ring = max(2, (min(w, h) * RING_RATIO).toInt())
        var samples = 0
        var nearBg = 0
        fun checkRing(x: Int, y: Int) {
            samples++
            if (minDistance(pixels[y * w + x], bgColors) <= RING_TOLERANCE) nearBg++
        }
        for (x in 0 until w step max(1, ring / 2)) {
            for (y in 0 until ring) { checkRing(x, y); checkRing(x, h - 1 - y) }
        }
        for (y in 0 until h step max(1, ring / 2)) {
            for (x in 0 until ring) { checkRing(x, y); checkRing(w - 1 - x, y) }
        }
        val purity = if (samples == 0) 0f else nearBg.toFloat() / samples
        if (purity < PURE_BG_RATIO) {
            return AiIllustrationProcessResult(
                source, false, 0,
                "插画背景不是纯色/棋盘格，已保留原图（可重新生成）"
            )
        }

        // 4) 颜色键控 + despill：背景 = 与四边连通、接近任一背景色的像素
        val total = w * h
        val alpha = IntArray(total)
        val bgMask = BooleanArray(total)
        val stack = IntArray(total)
        var top = 0
        fun seed(x: Int, y: Int) {
            if (x < 0 || y < 0 || x >= w || y >= h) return
            val idx = y * w + x
            if (bgMask[idx]) return
            if (minDistance(pixels[idx], bgColors) <= KEY_FULL) {
                bgMask[idx] = true
                stack[top++] = idx
            }
        }
        for (x in 0 until w) { seed(x, 0); seed(x, h - 1) }
        for (y in 0 until h) { seed(0, y); seed(w - 1, y) }
        while (top > 0) {
            val idx = stack[--top]
            val x = idx % w
            val y = idx / w
            seed(x - 1, y); seed(x + 1, y); seed(x, y - 1); seed(x, y + 1)
        }
        for (i in 0 until total) {
            val p = pixels[i]
            val r = Color.red(p); val g = Color.green(p); val b = Color.blue(p)
            if (bgMask[i]) {
                alpha[i] = 0
                pixels[i] = Color.argb(0, r, g, b)
                continue
            }
            val nearest = nearestBgColor(p, bgColors)
            val d = distanceTo(p, nearest)
            val nearBg = (i % w > 0 && bgMask[i - 1]) || (i % w < w - 1 && bgMask[i + 1]) ||
                (i >= w && bgMask[i - w]) || (i < total - w && bgMask[i + w])
            val a = if (nearBg && d < KEY_FULL + 26f) {
                (((d - KEY_FULL) / 26f) * 255f).toInt().coerceIn(0, 255)
            } else 255
            if (a in 1..254) {
                val af = a / 255f
                val br = Color.red(nearest); val bgc = Color.green(nearest); val bb = Color.blue(nearest)
                val nr = (((r - (1f - af) * br) / af).toInt()).coerceIn(0, 255)
                val ng = (((g - (1f - af) * bgc) / af).toInt()).coerceIn(0, 255)
                val nb = (((b - (1f - af) * bb) / af).toInt()).coerceIn(0, 255)
                pixels[i] = Color.argb(a, nr, ng, nb)
            } else {
                pixels[i] = Color.argb(a, r, g, b)
            }
            alpha[i] = a
        }

        // 5) 外圈水印/角标连通块清理
        val removed = removeOuterWatermarkBlobs(pixels, alpha, w, h)

        // 6) 裁透明外边距 + padding
        val cropped = cropToContent(pixels, w, h)
            ?: return AiIllustrationProcessResult(source, false, removed, "插画里没有检测到主体，已保留原图")
        val mode = if (estimate.checkerboard) "CHECKERBOARD" else "COLOR_KEY"
        return AiIllustrationProcessResult(cropped, true, removed, warning = null, mode = mode)
    }

    private data class BgEstimate(val colors: List<Int>, val checkerboard: Boolean)

    private fun estimateBackground(pixels: IntArray, w: Int, h: Int): BgEstimate? {
        val ring = max(2, (min(w, h) * RING_RATIO).toInt())
        val samples = ArrayList<Int>(2048)
        fun add(x: Int, y: Int) { samples.add(pixels[y * w + x]) }
        for (x in 0 until w step 2) {
            for (y in 0 until ring) { add(x, y); add(x, h - 1 - y) }
        }
        for (y in 0 until h step 2) {
            for (x in 0 until ring) { add(x, y); add(w - 1 - x, y) }
        }
        if (samples.isEmpty()) return null
        // 第一主色：逐通道中位数
        val rList = IntArray(samples.size) { Color.red(samples[it]) }.sortedArray()
        val gList = IntArray(samples.size) { Color.green(samples[it]) }.sortedArray()
        val bList = IntArray(samples.size) { Color.blue(samples[it]) }.sortedArray()
        val mid = samples.size / 2
        val bg1 = Color.rgb(rList[mid], gList[mid], bList[mid])

        // 第二主色（棋盘格）：远离 bg1 的样本中位数
        val far = samples.filter { distanceTo(it, bg1) > 30f }
        val colors = mutableListOf(bg1)
        var checker = false
        if (far.size >= samples.size * 0.15f) {
            val r2 = IntArray(far.size) { Color.red(far[it]) }.sortedArray()
            val g2 = IntArray(far.size) { Color.green(far[it]) }.sortedArray()
            val b2 = IntArray(far.size) { Color.blue(far[it]) }.sortedArray()
            val bg2 = Color.rgb(r2[far.size / 2], g2[far.size / 2], b2[far.size / 2])
            val lum = luminance(bg2)
            if (lum > 0.55f && saturation(bg2) < 0.25f && distanceTo(bg1, bg2) < 120f) {
                colors.add(bg2)
                checker = true
            }
        }
        return BgEstimate(colors, checker)
    }

    private fun cropToContent(pixels: IntArray, w: Int, h: Int): Bitmap? {
        var minX = w; var minY = h; var maxX = -1; var maxY = -1
        for (y in 0 until h) {
            for (x in 0 until w) {
                if ((pixels[y * w + x] ushr 24) > CROP_ALPHA) {
                    if (x < minX) minX = x
                    if (x > maxX) maxX = x
                    if (y < minY) minY = y
                    if (y > maxY) maxY = y
                }
            }
        }
        if (maxX < minX || maxY < minY) return null
        val cw = maxX - minX + 1
        val ch = maxY - minY + 1
        val pad = max(3, (min(cw, ch) * 0.015f).toInt())
        val tw = cw + pad * 2
        val th = ch + pad * 2
        val out = IntArray(tw * th)
        for (y in 0 until ch) {
            for (x in 0 until cw) {
                out[(y + pad) * tw + (x + pad)] = pixels[(y + minY) * w + (x + minX)]
            }
        }
        val result = Bitmap.createBitmap(tw, th, Bitmap.Config.ARGB_8888)
        result.setPixels(out, 0, tw, 0, 0, tw, th)
        return result
    }

    private fun removeOuterWatermarkBlobs(pixels: IntArray, alpha: IntArray, w: Int, h: Int): Int {
        val total = w * h
        val visited = BooleanArray(total)
        val stack = IntArray(total)
        val members = IntArray(total)
        // 主连通块面积
        var mainArea = 0
        for (i in 0 until total) {
            if (visited[i] || alpha[i] <= 32) continue
            var top = 0; var area = 0
            stack[top++] = i; visited[i] = true
            while (top > 0) {
                val idx = stack[--top]; area++
                val x = idx % w; val y = idx / w
                fun push(nx: Int, ny: Int) {
                    if (nx < 0 || ny < 0 || nx >= w || ny >= h) return
                    val ni = ny * w + nx
                    if (!visited[ni] && alpha[ni] > 32) { visited[ni] = true; stack[top++] = ni }
                }
                push(x - 1, y); push(x + 1, y); push(x, y - 1); push(x, y + 1)
            }
            if (area > mainArea) mainArea = area
        }
        visited.fill(false)
        var removed = 0
        for (i in 0 until total) {
            if (visited[i] || alpha[i] <= 32) continue
            var top = 0; var count = 0
            var sumSat = 0f; var sumLum = 0f
            var minX = w; var minY = h; var maxX = -1; var maxY = -1
            stack[top++] = i; visited[i] = true
            while (top > 0) {
                val idx = stack[--top]
                if (count < members.size) members[count++] = idx
                val p = pixels[idx]
                sumSat += saturation(p)
                sumLum += luminance(p)
                val x = idx % w; val y = idx / w
                if (x < minX) minX = x; if (x > maxX) maxX = x
                if (y < minY) minY = y; if (y > maxY) maxY = y
                fun push(nx: Int, ny: Int) {
                    if (nx < 0 || ny < 0 || nx >= w || ny >= h) return
                    val ni = ny * w + nx
                    if (!visited[ni] && alpha[ni] > 32) { visited[ni] = true; stack[top++] = ni }
                }
                push(x - 1, y); push(x + 1, y); push(x, y - 1); push(x, y + 1)
            }
            val area = count
            val avgSat = if (area > 0) sumSat / area else 1f
            val avgLum = if (area > 0) sumLum / area else 0f
            val cxm = (minX + maxX) / 2f
            val cym = (minY + maxY) / 2f
            val inOuter = cym > h * 0.72f || cxm > w * 0.70f || cym < h * 0.10f || cxm < w * 0.10f
            val small = area < max(48, (total * 0.006f).toInt()) && area < mainArea * 0.05f
            val watermarkLike = (avgSat < 0.30f && avgLum > 0.55f) ||
                (avgSat < 0.38f && area < (total * 0.0018f).toInt())
            if (inOuter && small && watermarkLike) {
                for (k in 0 until count) {
                    val idx = members[k]
                    alpha[idx] = 0
                    pixels[idx] = pixels[idx] and 0x00FFFFFF
                }
                removed++
            }
        }
        return removed
    }

    private fun countTransparent(pixels: IntArray): Int {
        var count = 0
        var i = 0
        while (i < pixels.size) {
            if ((pixels[i] ushr 24) < 240) count++
            i += 2
        }
        return count * 2
    }

    private fun minDistance(pixel: Int, colors: List<Int>): Float =
        colors.minOf { distanceTo(pixel, it) }

    private fun nearestBgColor(pixel: Int, colors: List<Int>): Int =
        colors.minByOrNull { distanceTo(pixel, it) } ?: colors.first()

    private fun distanceTo(pixel: Int, bg: Int): Float = distanceTo(pixel, Color.red(bg), Color.green(bg), Color.blue(bg))

    private fun distanceTo(pixel: Int, r: Int, g: Int, b: Int): Float {
        val dr = (Color.red(pixel) - r).toFloat()
        val dg = (Color.green(pixel) - g).toFloat()
        val db = (Color.blue(pixel) - b).toFloat()
        return sqrt(dr * dr + dg * dg + db * db)
    }

    private fun luminance(pixel: Int): Float =
        (0.299f * Color.red(pixel) + 0.587f * Color.green(pixel) + 0.114f * Color.blue(pixel)) / 255f

    private fun saturation(pixel: Int): Float {
        val r = Color.red(pixel); val g = Color.green(pixel); val b = Color.blue(pixel)
        val mx = max(r, max(g, b)); val mn = min(r, min(g, b))
        return if (mx == 0) 0f else (mx - mn).toFloat() / mx
    }
}
