package com.brewkin.beanbook.data

import kotlinx.serialization.Serializable

@Serializable
data class DatabaseBundle(
    val kind: String = KIND_DATABASE,
    val app: String = "忆杯手记",
    val version: Int = 1,
    val exportedAt: Long = System.currentTimeMillis(),
    val data: AppState,
    val images: Map<String, String> = emptyMap()
) {
    companion object {
        const val KIND_DATABASE = "beanbook-database"
    }
}

@Serializable
data class RecipeShareBundle(
    val kind: String = KIND_RECIPE,
    val app: String = "忆杯手记",
    val version: Int = 1,
    val exportedAt: Long = System.currentTimeMillis(),
    val recipe: Recipe,
    val bean: Bean? = null,
    val beanImageBase64: String? = null,
    val customIngredients: List<CustomIngredient> = emptyList()
) {
    companion object {
        const val KIND_RECIPE = "beanbook-recipe"
    }
}

enum class DatabaseImportMode {
    MERGE,
    REPLACE
}

data class TransferOutcome(
    val message: String,
    val importedRecipes: Int = 0,
    val importedBeans: Int = 0,
    val importedIngredients: Int = 0,
    val skipped: Int = 0
)
