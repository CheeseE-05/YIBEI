package com.brewkin.beanbook.ui.theme

import androidx.compose.ui.graphics.Color
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

fun String.hexColor(fallback: Color = BrewColors.Ink): Color =
    runCatching { Color(android.graphics.Color.parseColor(this)) }.getOrDefault(fallback)

fun formatGrams(value: Double): String =
    if (value % 1.0 == 0.0) "${value.toInt()}g" else String.format(Locale.CHINA, "%.1fg", value)

fun formatIntG(value: Int): String = "${value}g"

fun todayStart(): Long = LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()

fun Long.toLocalDate(): LocalDate =
    Instant.ofEpochMilli(this).atZone(ZoneId.systemDefault()).toLocalDate()

fun Long.toTimeLabel(): String {
    val date = toLocalDate()
    val today = LocalDate.now()
    val time = Instant.ofEpochMilli(this).atZone(ZoneId.systemDefault())
        .format(DateTimeFormatter.ofPattern("HH:mm"))
    return when (date) {
        today -> "今天 $time"
        today.minusDays(1) -> "昨天 $time"
        else -> "${date.monthValue}月${date.dayOfMonth}日"
    }
}

fun Long.toDateLabel(): String {
    val date = toLocalDate()
    return "${date.year}.${String.format(Locale.CHINA, "%02d", date.monthValue)}.${String.format(Locale.CHINA, "%02d", date.dayOfMonth)}"
}

fun Long.toShortDate(): String {
    val date = toLocalDate()
    return "${date.monthValue}月${date.dayOfMonth}日"
}

fun Long.toWeekday(): String {
    val date = toLocalDate()
    return when (date.dayOfWeek.value) {
        1 -> "周一"
        2 -> "周二"
        3 -> "周三"
        4 -> "周四"
        5 -> "周五"
        6 -> "周六"
        else -> "周日"
    }
}

fun greeting(): String {
    val hour = java.time.LocalTime.now().hour
    return when (hour) {
        in 5..10 -> "早上好"
        in 11..13 -> "中午好"
        in 14..17 -> "下午好"
        in 18..22 -> "晚上好"
        else -> "夜深了"
    }
}

fun monthTitle(): String {
    val now = LocalDate.now()
    return "${now.year} · ${String.format(Locale.CHINA, "%02d", now.monthValue)}"
}

fun originFlag(origin: String): String = when {
    origin.contains("埃塞") -> "🇪🇹"
    origin.contains("肯尼亚") -> "🇰🇪"
    origin.contains("卢旺达") -> "🇷🇼"
    origin.contains("哥伦比亚") -> "🇨🇴"
    origin.contains("巴西") -> "🇧🇷"
    origin.contains("危地马拉") -> "🇬🇹"
    origin.contains("哥斯达黎加") -> "🇨🇷"
    origin.contains("巴拿马") -> "🇵🇦"
    origin.contains("洪都拉斯") -> "🇭🇳"
    origin.contains("秘鲁") -> "🇵🇪"
    origin.contains("牙买加") -> "🇯🇲"
    origin.contains("云南") || origin.contains("中国") -> "🇨🇳"
    origin.contains("印尼") || origin.contains("印度尼西亚") -> "🇮🇩"
    origin.contains("越南") -> "🇻🇳"
    origin.contains("巴布亚") || origin.contains("巴新") -> "🇵🇬"
    origin.contains("美国") -> "🇺🇸"
    origin.contains("日本") -> "🇯🇵"
    else -> "◌"
}

fun ratingText(rating: Int): String = when (rating) {
    5 -> "惊艳"
    4 -> "很好喝"
    3 -> "还不错"
    2 -> "一般"
    else -> "再试试"
}

fun relativeDay(createdAt: Long): String {
    val date = createdAt.toLocalDate()
    val today = LocalDate.now()
    return when (date) {
        today -> "今天"
        today.minusDays(1) -> "昨天"
        else -> "${date.monthValue}月${date.dayOfMonth}日"
    }
}

fun dayPart(epoch: Long): String {
    val date = epoch.toLocalDate()
    val today = LocalDate.now()
    return when (date) {
        today -> "今天"
        today.minusDays(1) -> "昨天"
        else -> "${date.monthValue}月${date.dayOfMonth}日  ${when (date.dayOfWeek.value) {
            1 -> "Mon"
            2 -> "Tue"
            3 -> "Wed"
            4 -> "Thu"
            5 -> "Fri"
            6 -> "Sat"
            else -> "Sun"
        }}"
    }
}
