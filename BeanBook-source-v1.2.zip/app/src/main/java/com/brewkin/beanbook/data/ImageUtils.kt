package com.brewkin.beanbook.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

object ImageUtils {

    suspend fun loadBitmap(context: Context, uri: Uri, maxSide: Int = 1600): Bitmap? =
        withContext(Dispatchers.IO) {
            runCatching {
                val resolver = context.contentResolver
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return@runCatching null

                var sample = 1
                while (maxOf(bounds.outWidth, bounds.outHeight) / sample > maxSide * 2) sample *= 2

                val options = BitmapFactory.Options().apply {
                    inSampleSize = sample
                    inPreferredConfig = Bitmap.Config.ARGB_8888
                }
                val decoded = resolver.openInputStream(uri)?.use {
                    BitmapFactory.decodeStream(it, null, options)
                } ?: return@runCatching null

                val exif = resolver.openInputStream(uri)?.use { ExifInterface(it) }
                val matrix = Matrix()
                when (exif?.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                    ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.setScale(-1f, 1f)
                    ExifInterface.ORIENTATION_ROTATE_180 -> matrix.setRotate(180f)
                    ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.setScale(1f, -1f)
                    ExifInterface.ORIENTATION_TRANSPOSE -> {
                        matrix.setRotate(90f)
                        matrix.postScale(-1f, 1f)
                    }
                    ExifInterface.ORIENTATION_ROTATE_90 -> matrix.setRotate(90f)
                    ExifInterface.ORIENTATION_TRANSVERSE -> {
                        matrix.setRotate(-90f)
                        matrix.postScale(-1f, 1f)
                    }
                    ExifInterface.ORIENTATION_ROTATE_270 -> matrix.setRotate(-90f)
                }
                val oriented = if (!matrix.isIdentity) {
                    Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, matrix, true)
                        .also { if (it !== decoded) decoded.recycle() }
                } else decoded

                val longest = maxOf(oriented.width, oriented.height)
                if (longest <= maxSide) oriented else {
                    val scale = maxSide.toFloat() / longest
                    Bitmap.createScaledBitmap(
                        oriented,
                        (oriented.width * scale).toInt().coerceAtLeast(1),
                        (oriented.height * scale).toInt().coerceAtLeast(1),
                        true
                    ).also { if (it !== oriented) oriented.recycle() }
                }
            }.getOrNull()
        }

    /**
     * 图片是否「已经带透明背景」（PNG alpha）：
     * - 存在显著透明像素（alpha<250 占比 > 2%），或
     * - 任意边缘像素 alpha<250（透明背景图边缘必透明）。
     * 用于相册导入时判断是否直接保留透明、跳过 U²-Net 抠图。
     */
    fun hasSignificantTransparency(bitmap: Bitmap): Boolean {
        if (!bitmap.hasAlpha()) return false
        val w = bitmap.width
        val h = bitmap.height
        if (w < 2 || h < 2) return false
        val pixels = IntArray(w * h)
        bitmap.getPixels(pixels, 0, w, 0, 0, w, h)
        var samples = 0
        var transparent = 0
        for (y in 0 until h step 2) {
            for (x in 0 until w step 2) {
                samples++
                if ((pixels[y * w + x] ushr 24) < 250) transparent++
            }
        }
        val ratio = if (samples == 0) 0f else transparent.toFloat() / samples
        if (ratio > 0.02f) return true
        for (x in 0 until w) {
            if ((pixels[x] ushr 24) < 250 || (pixels[(h - 1) * w + x] ushr 24) < 250) return true
        }
        for (y in 0 until h) {
            if ((pixels[y * w] ushr 24) < 250 || (pixels[y * w + w - 1] ushr 24) < 250) return true
        }
        return false
    }

    /** 已透明导入：裁掉透明外边距并留 1.5% padding（保留 alpha，不调用抠图）。 */
    fun cropTransparentWithPadding(bitmap: Bitmap, paddingRatio: Float = 0.015f): Bitmap {
        val w = bitmap.width
        val h = bitmap.height
        val pixels = IntArray(w * h)
        bitmap.getPixels(pixels, 0, w, 0, 0, w, h)
        var minX = w; var minY = h; var maxX = -1; var maxY = -1
        for (y in 0 until h) {
            for (x in 0 until w) {
                if ((pixels[y * w + x] ushr 24) > 8) {
                    if (x < minX) minX = x
                    if (x > maxX) maxX = x
                    if (y < minY) minY = y
                    if (y > maxY) maxY = y
                }
            }
        }
        if (maxX < minX || maxY < minY) return bitmap
        val cw = maxX - minX + 1
        val ch = maxY - minY + 1
        val pad = kotlin.math.max(3, (kotlin.math.min(cw, ch) * paddingRatio).toInt())
        val tw = cw + pad * 2
        val th = ch + pad * 2
        val out = IntArray(tw * th)
        for (y in 0 until ch) {
            for (x in 0 until cw) {
                out[(y + pad) * tw + (x + pad)] = pixels[(y + minY) * w + (x + minX)]
            }
        }
        val result = Bitmap.createBitmap(tw, th, Bitmap.Config.ARGB_8888)
        result.setPixels(out, 0, tw, 0, 0, tw, th)
        return result
    }

    suspend fun saveTempPng(context: Context, bitmap: Bitmap, name: String): File? =
        withContext(Dispatchers.IO) {
            runCatching {
                val dir = File(context.cacheDir, "bean_work").apply { mkdirs() }
                val f = File(dir, name)
                FileOutputStream(f).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
                f
            }.getOrNull()
        }
}
