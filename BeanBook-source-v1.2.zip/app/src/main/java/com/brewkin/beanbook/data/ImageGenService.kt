package com.brewkin.beanbook.data

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.addJsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import java.io.BufferedReader
import java.net.HttpURLConnection
import java.net.URL

/**
 * OpenAI 兼容插画生成客户端：POST {base}/images/generations。
 * 支持 b64_json 与 url 两种返回，下载后返回 Bitmap（不落盘，由调用方存 App 私有目录）。
 * Base URL / API Key 复用 AI 文案配置；模型与尺寸由设置页「插画生成 API」独立配置。
 */
object ImageGenService {
    private val json = Json { ignoreUnknownKeys = true; isLenient = true }

    private fun endpoint(baseUrl: String): String {
        val base = baseUrl.trim().trimEnd('/')
        return when {
            base.endsWith("/images/generations") -> base
            base.endsWith("/v1") -> "$base/images/generations"
            base.endsWith("/chat/completions") -> base.removeSuffix("/chat/completions") + "/images/generations"
            else -> "$base/v1/images/generations"
        }
    }

    /** 透明底 PNG 风格后缀：任何 prompt 都必须完整保留（照片模式超长时只裁剪描述）。 */
    const val TRANSPARENT_STYLE_SUFFIX =
        "; style: hand-painted watercolor illustration, isolated illustration on a transparent background PNG with alpha, " +
            "no background scene, no paper texture, no shadow, warm amber and cream tones, ingredient garnishes around the cup, " +
            "elegant, minimal, high quality, centered composition, square 1:1, NO text, NO letters, NO words, NO watermark, NO logo"

    /** 配方上下文（紧接主体描述，让照片描述和配方信息一起进 prompt）。 */
    fun recipeContext(recipe: Recipe, bean: Bean?, price: Int? = null): String = buildString {
        append(" Cozy coffee card illustration for ${recipe.name}")
        if (bean != null && bean.name.isNotBlank()) {
            append(", made with ${bean.name} coffee bean")
            if (bean.origin.isNotBlank()) append(" from ${bean.origin}")
        }
        val layers = recipe.layers.map { it.name }.distinct().take(6)
        if (layers.isNotEmpty()) append(", ingredients: ${layers.joinToString(", ")}")
        val flavs = bean?.flavors.orEmpty().take(4)
        if (flavs.isNotEmpty()) append(", flavor notes: ${flavs.joinToString(", ")}")
        append(", mouthfeel ${recipe.mouthfeel}, sweetness ${recipe.sweetness}")
    }

    /**
     * 照片描述 / 任意主体描述 → 完整插画 prompt：
     * 主体描述 + 配方上下文 + 透明底风格后缀，总长 ≤1000；
     * 超长时**只裁剪描述**，配方上下文和风格后缀完整保留。
     */
    fun composePrompt(description: String, recipe: Recipe, bean: Bean?, price: Int? = null): String {
        val desc = description.trim().trimEnd('。', '.', '；', ';', ',')
        val context = recipeContext(recipe, bean, price)
        val budget = (1000 - context.length - TRANSPARENT_STYLE_SUFFIX.length).coerceAtLeast(0)
        val safeDesc = if (desc.length <= budget) desc else desc.take(budget).trimEnd()
        return "$safeDesc$context$TRANSPARENT_STYLE_SUFFIX".take(1000)
    }

    /** 按当前配方动态拼接「手绘水彩特调咖啡」prompt（主体描述 + 配方上下文 + 透明底风格后缀）。 */
    fun buildIllustrationPrompt(recipe: Recipe, bean: Bean?, price: Int? = null): String {
        val layers = recipe.layers.map { it.name }.distinct().take(6).joinToString(", ")
        val flavs = bean?.flavors.orEmpty().take(4).joinToString(", ")
        val colors = recipe.layers.map { it.colorHex }.distinct().take(3).joinToString(", ")
        val cold = recipe.layers.any { it.ingredientId in setOf("ice", "soda", "sparkling", "coldbrew") }
        val cupType = if (cold) "iced drink in a clear glass cup with ice cubes" else "warm drink in a ceramic cup"
        val description = buildString {
            append("A hand-painted watercolor illustration of a specialty coffee drink: ${recipe.name}")
            if (bean != null) {
                append(", made with ${bean.name} coffee bean")
                if (bean.origin.isNotBlank()) append(" from ${bean.origin}")
            }
            append(", $cupType")
            if (layers.isNotBlank()) append(", ingredients: $layers")
            if (flavs.isNotBlank()) append(", flavor notes: $flavs")
            if (colors.isNotBlank()) append(", color palette: $colors")
            append(", mouthfeel ${recipe.mouthfeel}, sweetness ${recipe.sweetness}")
        }
        return composePrompt(description, recipe, bean, price)
    }

    suspend fun generate(
        imageConfig: ImageGenConfig,
        prompt: String
    ): Result<Bitmap> = runCatching {
        if (imageConfig.apiKey.isBlank()) throw IllegalStateException("还没有填写插画 API Key（设置 → 插画生成 API）")
        if (imageConfig.baseUrl.isBlank()) throw IllegalStateException("还没有填写插画 Base URL")
        if (imageConfig.model.isBlank()) throw IllegalStateException("还没有填写插画模型名")
        ImageSizes.validate(imageConfig.size)?.let { throw IllegalStateException(it) }
        withContext(Dispatchers.IO) {
            fun request(watermarkEnabled: Boolean): Bitmap {
                val payload = buildJsonObject {
                    put("model", imageConfig.model.trim())
                    put("prompt", prompt)
                    put("n", 1)
                    put("size", imageConfig.size.trim())
                    put("response_format", "b64_json")
                    // 智谱 GLM-Image 支持 watermark_enabled=false 去水印；部分账号未签免责声明会失败，
                    // 由外层自动回退 true 重试 + 本地连通块清理。
                    put("watermark_enabled", watermarkEnabled)
                }
                val connection = (URL(endpoint(imageConfig.baseUrl)).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 20_000
                    readTimeout = 120_000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json")
                    setRequestProperty("Authorization", "Bearer ${imageConfig.apiKey.trim()}")
                }
                return try {
                    connection.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
                    val code = connection.responseCode
                    val text = (if (code in 200..299) connection.inputStream else connection.errorStream)
                        ?.bufferedReader(Charsets.UTF_8)?.use(BufferedReader::readText).orEmpty()
                    if (code !in 200..299) {
                        val message = runCatching {
                            json.parseToJsonElement(text).jsonObject["error"]?.jsonObject
                                ?.get("message")?.jsonPrimitive?.contentOrNull
                        }.getOrNull()
                        throw IllegalStateException(message ?: "插画生成失败（HTTP $code）")
                    }
                    val root = json.parseToJsonElement(text).jsonObject
                    val item = root["data"]?.jsonArray?.firstOrNull()?.jsonObject
                        ?: throw IllegalStateException("插画接口没有返回图片")
                    val b64 = item["b64_json"]?.jsonPrimitive?.contentOrNull
                    if (!b64.isNullOrBlank()) {
                        val bytes = Base64.decode(b64, Base64.DEFAULT)
                        BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                            ?: throw IllegalStateException("插画数据无法解码")
                    } else {
                        val url = item["url"]?.jsonPrimitive?.contentOrNull
                            ?: throw IllegalStateException("插画接口既没有 b64_json 也没有 url")
                        downloadBitmap(url)
                    }
                } finally {
                    connection.disconnect()
                }
            }
            return@withContext try {
                request(watermarkEnabled = false)
            } catch (first: Throwable) {
                runCatching { request(watermarkEnabled = true) }.getOrElse { second ->
                    throw IllegalStateException(
                        second.message ?: first.message ?: "插画生成失败，请重试",
                        second
                    )
                }
            }
        }
    }

    private fun downloadBitmap(url: String): Bitmap {
        val connection = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 20_000
            readTimeout = 120_000
        }
        try {
            if (connection.responseCode !in 200..299) {
                throw IllegalStateException("插画下载失败（HTTP ${connection.responseCode}）")
            }
            val bytes = connection.inputStream.use { it.readBytes() }
            return BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                ?: throw IllegalStateException("插画数据无法解码")
        } finally {
            connection.disconnect()
        }
    }
}
