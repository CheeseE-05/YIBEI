package com.brewkin.beanbook

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.core.view.WindowCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.brewkin.beanbook.data.ThemeMode
import com.brewkin.beanbook.ui.BeanBookApp
import com.brewkin.beanbook.ui.theme.BeanBookTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: MainViewModel = viewModel()
            val themeMode by viewModel.settings.themeMode.collectAsStateWithLifecycle()
            val systemDark = isSystemInDarkTheme()
            // 截图/验证用：携带 lightTheme extra 启动时强制浅色（不影响正常使用）。
            val forceLight = intent.getBooleanExtra("lightTheme", false)
            val darkTheme = if (forceLight) false else when (themeMode) {
                ThemeMode.LIGHT -> false
                ThemeMode.DARK -> true
                else -> systemDark
            }
            // 状态栏 / 手势条图标跟着主题走，深色下用浅色图标。
            LaunchedEffect(darkTheme) {
                WindowCompat.getInsetsController(window, window.decorView).apply {
                    isAppearanceLightStatusBars = !darkTheme
                    isAppearanceLightNavigationBars = !darkTheme
                }
            }
            BeanBookTheme(darkTheme = darkTheme) {
                BeanBookApp(viewModel = viewModel)
            }
        }
    }
}
