package com.brewkin.beanbook.data

/**
 * The original 27-ingredient palette, tuned for the cup renderer.
 * Rate is roughly how many grams are poured per second while holding a card.
 */
object Ingredients {
    val builtIn: List<IngredientSpec> = listOf(
        IngredientSpec("espresso", "浓缩", "#2A1708", 20, IngredientKind.LIQUID),
        IngredientSpec("coldbrew", "冷萃", "#3B2414", 32, IngredientKind.LIQUID),
        IngredientSpec("water", "热水", "#D8C9AE", 60, IngredientKind.LIQUID, 0.55f),
        IngredientSpec("matcha", "抹茶", "#7E9C4F", 28, IngredientKind.LIQUID),
        IngredientSpec("blacktea", "红茶", "#9C4A1C", 55, IngredientKind.LIQUID, 0.82f),
        IngredientSpec("oolong", "乌龙茶", "#C08A3E", 55, IngredientKind.LIQUID, 0.80f),
        IngredientSpec("milk", "牛奶", "#F1EADB", 55, IngredientKind.LIQUID),
        IngredientSpec("oat", "燕麦奶", "#E8D9BC", 48, IngredientKind.LIQUID),
        IngredientSpec("coconut", "椰奶", "#F3EDE0", 48, IngredientKind.LIQUID),
        IngredientSpec("soy", "豆奶", "#EFE4CB", 50, IngredientKind.LIQUID),
        IngredientSpec("foam", "奶泡", "#FAF5E9", 22, IngredientKind.FOAM),
        IngredientSpec("cheesefoam", "芝士奶盖", "#F7EED6", 18, IngredientKind.FOAM),
        IngredientSpec("cream", "奶油顶", "#FFF8E8", 16, IngredientKind.FOAM),
        IngredientSpec("caramel", "焦糖糖浆", "#A85C17", 12, IngredientKind.SYRUP),
        IngredientSpec("vanilla", "香草糖浆", "#E2BE7B", 14, IngredientKind.SYRUP),
        IngredientSpec("choc", "巧克力酱", "#46280F", 10, IngredientKind.SYRUP),
        IngredientSpec("osmanthus", "桂花糖浆", "#D9A441", 13, IngredientKind.SYRUP),
        IngredientSpec("condensed", "炼乳", "#F0E2BE", 11, IngredientKind.SYRUP),
        IngredientSpec("brownsugar", "黑糖糖浆", "#6B3A17", 12, IngredientKind.SYRUP),
        IngredientSpec("hazelnut", "榛果糖浆", "#9A6B35", 13, IngredientKind.SYRUP),
        IngredientSpec("honey", "蜂蜜", "#DFA231", 10, IngredientKind.SYRUP),
        IngredientSpec("passion", "百香果", "#E9A21B", 18, IngredientKind.PUREE),
        IngredientSpec("lemon", "柠檬", "#E8C93E", 16, IngredientKind.PUREE),
        IngredientSpec("mango", "芒果", "#F2AC3C", 30, IngredientKind.CHUNK),
        IngredientSpec("strawberry", "草莓", "#D8524A", 26, IngredientKind.CHUNK),
        IngredientSpec("ice", "冰块", "#DDE6E3", 90, IngredientKind.ICE, 0.55f),
        IngredientSpec("soda", "气泡水", "#E3E9E5", 48, IngredientKind.SPARKLING, 0.55f)
    )

    private val byId = builtIn.associateBy { it.id }

    fun find(id: String): IngredientSpec? = byId[id]

    fun all(custom: List<CustomIngredient>): List<IngredientSpec> =
        builtIn + custom.map { it.toSpec() }

    val palette: List<String> = listOf(
        "#2A1708", "#6B4A33", "#C08A3E", "#E8C93E",
        "#7E9C4F", "#A3CD39", "#E9A21B", "#D8524A",
        "#C97B84", "#8C6A9E", "#6F8FA6", "#DDE6E3",
        "#F3EDE0", "#F7EED6", "#F0DED7", "#A85C17"
    )
}
