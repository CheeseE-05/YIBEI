# 忆杯手记 iOS 静态 QA 报告

| 项目 | 内容 |
| --- | --- |
| 报告人 | qa-static（Team Lead: lead） |
| 时间 | 2026-11-06 20:37 CST（Asia/Shanghai） |
| 工程 | `/Users/mac/Desktop/zlj/beans-app`，iOS 工程 `ios/BeanBook.xcodeproj`，target/scheme = `BeanBook`，bundle id `com.brewkin.beanbook.ios`，部署目标 iOS 17.0 |
| 审查对象 | `ios/BeanBook/*.swift` 共 17 个文件（6,179 行）、`Info.plist`、`Assets.xcassets`、`project.pbxproj`、`ios/scripts/*.sh`、`.github/workflows/ios-unsigned.yml`；**第二阶段：Lead 的 Liquid Glass 改动 diff** |
| 环境 | macOS + **仅 Command Line Tools**（无 Xcode、无 iOS SDK、无 sudo）；Apple Swift 6.4（`swiftc`，macOS SDK 27.0）；`plutil`/`sips` 可用 |
| 写入范围 | 仅 `tools/model-tests/`、`docs/qa/`；**未修改 `ios/` 下任何文件** |
| 版本固定 | 工程不是 git 仓库（`git rev-parse` 报 not a git repository），因此以文件 SHA256 固定 QA 版本（见附录 A） |

---

## 0. 结论摘要

| # | 检查项 | 结果 | 说明 |
| --- | --- | --- | --- |
| 1 | `swiftc -parse` 全部 17 个 .swift | ✅ **17/17 PASS** | 语法层面全部可解析 |
| 2 | 数据层 macOS 可运行逻辑测试（ModelTests） | ✅ **211 PASS / 0 FAIL**，退出码 0 | 编译并真实运行的断言，覆盖 Codable/枚举/CUP/层克数/DemoData/日期/图片路径 |
| 3 | iOS 工程文件静态校验 | ✅ **24 PASS / 0 FAIL** | plutil、pbxproj Sources、Info.plist 键、AppIcon、权限键、scheme |
| 4 | Liquid Glass（iOS 26）API + 可用性门禁 | ✅ **5 PASS / 0 FAIL** | macOS 26 SDK 类型检查 + 9 处 iOS 26 符号双门禁审计 + 旧 Xcode 回退剥离审计 |
| 5 | **iOS 目标真编译 / 模拟器运行 / 玻璃真机观感** | ⚠️ **本机无法验证** | 必须由 **Xcode 26（iOS 26 SDK）** 完成，见第 7 节 |

**总体结论：本地可验证的部分全部通过；Liquid Glass 改动的 iOS 26 API 使用、`#available` 门禁、`#if compiler(>=6.2)` 旧 Xcode 回退、@Namespace/ViewBuilder 分支均未发现编译风险。仍存在 3 类需要 Xcode/真机确认的残余风险（R1/R3/R4）与 1 个数据兼容性风险（F1，已在模型测试中实证）。**

---

## 1. 复现命令

```bash
cd /Users/mac/Desktop/zlj/beans-app

# 1) 全量语法解析（17 个文件）
for f in ios/BeanBook/*.swift; do swiftc -parse "$f" || echo "PARSE FAIL: $f"; done

# 2) 数据层 macOS 可运行测试（编译 + 真实运行，211 条断言）
./tools/model-tests/run-tests.sh
# => PASS: 211  FAIL: 0  WARN: 0  EXIT CODE: 0  （harness exit code: 0）

# 3) Liquid Glass iOS 26 API 类型检查 + 双门禁审计
./tools/model-tests/glass-typecheck/check-glass-api.sh
# => Round-1: PASS=5；Round-2 终版: PASS=6（新增 BottomActionBar 检查），GATING_OK 9 处，见第 9 节

# 4) iOS 工程文件静态校验
./tools/model-tests/project-check.sh
# => PASS=24 FAIL=0（exit 0）

# 5) 复现 Lead 的独立证据（macOS 26 与 iOS 26 的 SwiftUI Glass API 相同）
swiftc -typecheck -target arm64-apple-macos26.0 /tmp/glasscheck/GlassCheck.swift   # exit 0
swiftc -typecheck -target arm64-apple-macos26.0 /tmp/glasscheck/GlassCheck2.swift  # exit 0
```

工具与说明见 `tools/model-tests/README.md`；本报告的原始输出摘要见附录 B。

---

## 2. 阶段一：`swiftc -parse` 全量结果（最终源码，20:33 之后未再改动）

```
PARSE OK  BeanBookApp.swift        PARSE OK  MakerView.swift
PARSE OK  BeanDetailView.swift     PARSE OK  MenuView.swift
PARSE OK  BeanEditorView.swift     PARSE OK  Models.swift
PARSE OK  BeansView.swift          PARSE OK  RecipeDetailView.swift
PARSE OK  Components.swift         PARSE OK  RootView.swift
PARSE OK  DataView.swift           PARSE OK  StatsView.swift
PARSE OK  HomeView.swift           PARSE OK  Store.swift
PARSE OK  ImageCutout.swift        PARSE OK  Theme.swift
                                   PARSE OK  Transfer.swift
```

17/17 通过，0 失败。注意：`-parse` 只验证语法，**不做类型检查**；类型检查的替代手段见第 3、5 节。

---

## 3. 数据层 macOS 可运行测试（ModelTests）

### 3.1 设计

- `ios/BeanBook/Models.swift` 只 `import Foundation`，直接参与编译 —— 测的是**真实 App 源码**；
- `DemoData` 在 `Store.swift` 尾部，`Store.swift` 依赖 UIKit/Combine 无法在 macOS 编译，测试脚本用 `awk`
  **原样抽取 `enum DemoData {` 到文件末尾**并补 `import Foundation`，不存在手工副本漂移；
- Swift 多文件编译要求顶层代码在 `main.swift`，脚本把 `ModelTests.swift` 原样复制为 `build/main.swift` 再编译；
- 测试内固定 `Asia/Shanghai` 时区，日期断言与机器时区无关。

### 3.2 覆盖与结果（PASS 211 / FAIL 0 / 退出码 0）

| 测试节 | 断言数 | 覆盖内容 |
| --- | --- | --- |
| 1. 常量与调色板 | 5 | `CUP_CAPACITY == 420`、`IMAGE_DIRECTORY == "bean_images"`、`palette` 16 色合法且唯一 |
| 2. 枚举映射 | 21 | Roast/Storage/IngredientKind/BeanStatus 的 rawValue、label、short、toneHex/bgHex/inkHex、defaultRate |
| 3. Bean 逻辑 | 37 | `empty()` 默认值、`displayOrigin`、`remainingRatio`（0/超量/总量 0）、`ageDays`、`status` 边界（3/4/30/31/45/46 天、冷冻优先）、`peakHint` |
| 4. Recipe / RecipeLayer | 6 | `totalGrams` 求和、空层、`totalText`、alpha/kind 保留 |
| 5. CustomIngredient / IngredientSpec / MakerDraft | 18 | 自定义材料 `spec` 映射（rate=kind.defaultRate/isCustom=true）、MakerDraft 默认值/求和/剩余钳制/`MakerDraft(beanId:)` |
| 6. AppData | 11 | `totalRemaining`、`bean(id)`/`bean(nil)`/不存在、`recipe(id)`、默认值 |
| 7. Codable 往返 | 11 | Bean/Recipe/RecipeLayer/CustomIngredient/AppData 往返相等；`beanId`、`imagePath` 为 nil 的往返 |
| 8. JSON 字段契约 | 14 | Bean 16 字段、Recipe 11 字段、RecipeLayer 6 字段、AppData 4 字段集合；枚举编码为大写 rawValue；日期为 Int64 毫秒；`imagePath`/`beanId` 为 nil 时省略；同输入编码确定性 |
| 9. 解码兼容性风险探测 | 5 | 缺字段（`customIngredients`）失败、未知枚举 rawValue 失败、可选字段缺失成功、未知顶层字段忽略、空 JSON 失败 |
| 10. DemoData.make() 完整性 | 38 | 2 豆/3 配方/0 自定义材料；ID 非空且唯一（含两次调用不重复）；评分 1…5；配方 `beanId` 均存在且 `beanName` 一致；层非空/克数>0/alpha∈[0,1]/颜色合法/总克数≤420；各时间戳 ≤ now 且在近 1 年；layer ingredientId 均在内置材料中；整库 Codable 往返 |
| 11. Ingredients.builtIn | 9 | 27 条、id 唯一、颜色合法、rate>0、alpha∈[0,1]、isCustom 默认 false |
| 12. 日期与时间辅助 | 13 | `Int64.date`/`Date.millis` 精确往返、`nowMillis`、`dayLabel`、`shortTime`、Recipe `dateTitle` 今天/昨天/更早、固定时区生效 |
| 13. formatGrams / originFlag | 23 | 整数/小数/0 格式；17 个产地旗帜映射与未知兜底 ◌ |
| **合计** | **211** | 全部 PASS，退出码 0 |

### 3.3 数据层发现（只报告，未改 App 代码）

- **F1（风险，已实证）AppData 合成 Codable 无兼容性兜底**：`AppData` 未自定义 `init(from:)`，缺任一非可选字段（如 `customIngredients`）
  或出现未知枚举 rawValue（如 `roast: "TURBO"`）都会**整体解码失败**；而 `AppStore.init` 在解码失败时**静默回退 `DemoData.make()`**
  （`Store.swift:28-33`），用户会看到示例数据、旧数据/第三方导入文件可能“丢失”。
  测试 9 已用断言锁定该行为；JSON 字段集合测试（测试 8，14 条）同时锁定与 Android 版的离线文件契约，改动 JSON 字段时需同步 Android。
- DemoData 日期均合规：`roastDate/openedAt/createdAt/lastUsedAt ≤ now` 且未出现未来时间；3 个示例配方总克数均 ≤ `CUP_CAPACITY=420`。
- 自定义材料 `spec` 映射一致，`MakerDraft.remaining` 超容量正确钳制到 0。

---

## 4. 阶段一：iOS 工程文件静态校验（PASS 24 / FAIL 0）

| 检查 | 结果 |
| --- | --- |
| `plutil -lint ios/BeanBook.xcodeproj/project.pbxproj` | ✅ OK |
| `plutil -lint ios/BeanBook/Info.plist` | ✅ OK |
| `BeanBook/` 下 17 个 .swift 全部在 `PBXSourcesBuildPhase` | ✅ 17/17 |
| pbxproj 引用的 .swift 文件均真实存在（无幽灵引用） | ✅ |
| Info.plist 关键键 | ✅ `CFBundleDisplayName=忆杯手记`、`CFBundlePackageType=APPL`、`CFBundleShortVersionString=1.0`、`CFBundleVersion=1`、`LSRequiresIPhoneOS=true`、`UIUserInterfaceStyle=Light`、`UIRequiresFullScreen=false`、`UIApplicationSupportsIndirectInputEvents=true`、`CFBundleDevelopmentRegion=zh_CN`、`UILaunchScreen` 存在、`UISupportedInterfaceOrientations` 含 Portrait（iPad 另有 4 向） |
| target 配置 | ✅ `INFOPLIST_FILE=BeanBook/Info.plist` + `GENERATE_INFOPLIST_FILE=NO`；`PRODUCT_BUNDLE_IDENTIFIER=com.brewkin.beanbook.ios`；`IPHONEOS_DEPLOYMENT_TARGET=17.0`（Debug/Release 两处）；`SWIFT_VERSION=5.0`；`SUPPORTED_PLATFORMS=iphoneos iphonesimulator` |
| shared scheme | ✅ `ios/BeanBook.xcodeproj/xcshareddata/xcschemes/BeanBook.xcscheme` 存在，Blueprint `BeanBook` |
| AppIcon | ✅ `AppIcon.png` 1024×1024、RGB（无 alpha，符合 App Store 要求）、`Contents.json` 声明的 filename/size 一致；pbxproj `ASSETCATALOG_COMPILER_APPICON_NAME=AppIcon` |
| 权限描述键 | ✅ 代码中**无**相机/相册写入/定位/麦克风调用（`PhotosPicker`+`loadTransferable` 属于系统代理选择，**不需要** `NSPhotoLibraryUsageDescription`/`NSPhotoLibraryAddUsageDescription`；导出/分享走 `fileExporter`/`UIActivityViewController`，也不需要权限键） |
| CI 交叉检查 | ✅ `ios/scripts/*.sh` 共 5 个脚本 `bash -n` 全部通过；workflow 引用的 4 个脚本均存在；YAML 可被 Ruby YAML 解析；截图脚本的 `-uiTestTab` 与 `RootView.swift` 的 `AppTab.launchArgumentSelection` 契约一致（home/beans/maker/menu/stats → rawValue 小写） |

### 4.1 工程层面的观察（非阻塞）

- **F9 行尾混用（低）**：17 个 .swift 中 16 个为 CRLF、`BeanBookApp.swift` 为 LF；`swiftc` 可正常解析，不影响构建，但建议统一，避免 Xcode 编辑/merge 产生整文件 diff。
- **F10 CI 产物卫生（低）**：根 `.gitignore`/`ios/.gitignore` 未覆盖 `dist/*.sha256`、`ios/artifacts/`（`*.ipa` 已覆盖）；若不想把 CI 产物纳入版本管理，建议补充忽略规则。
- **F11 Info.plist 小项（低，无害）**：`UIStatusBarStyle=UIStatusBarStyleDarkContent` 在默认 `UIViewControllerBasedStatusBarAppearance=true` 下不生效（SwiftUI 用 `.preferredColorScheme`）；`CFBundleDevelopmentRegion=zh_CN` 可考虑改 `zh-Hans`（Apple 惯例，非阻塞）。
- **F12 无 git 仓库**：无法用 commit 固定 QA 版本，本报告用文件 SHA256（附录 A）固定。

---

## 5. 阶段二：Liquid Glass 改动 diff 审查

### 5.1 改动范围（对比 QA 开始时的快照）

| 文件 | 改动量 | 内容 |
| --- | --- | --- |
| `ios/BeanBook/Theme.swift` | +8 / -0（相对 QA 快照） | Liquid Glass 封装已有雏形，最终新增 `#if compiler(>=6.2)` 双门禁与注释；`supportsLiquidGlass`、`liquidGlassStyle`、`LiquidGlassSurface`、`View.liquidGlassSurface` 完整 |
| `ios/BeanBook/RootView.swift` | +129 / -28 | 新增 `AppTab.launchArgumentSelection`（Debug 启动参数直达页签）；SideRail 背景改 `.liquidGlassSurface(in: Rectangle(), fallbackMaterial: .ultraThinMaterial)`；BottomBar 重写：`@Namespace`、`GlassEffectContainer(spacing:18)`、`glassBar`（`.glassEffect(.regular, in: RoundedRectangle(...))` + `.glassEffectID`）、`makerLabel`（`.glassEffect(liquidGlassStyle(tint:interactive:), in: Circle())` + `.glassEffectID`）、`legacyBar`/`legacyMakerLabel` 回退、`.animation(.snappy(duration:0.28), value:)`、`accessibilityLabel/Identifier` |
| `ios/BeanBook/BeanDetailView.swift` | +1 / -1 | `.background(.ultraThinMaterial)` → `.liquidGlassSurface(in: Rectangle(), fallbackMaterial: .ultraThinMaterial)` |
| `ios/BeanBook/BeanEditorView.swift` | +1 / -1 | 同上（底部操作条） |
| `ios/BeanBook/RecipeDetailView.swift` | +1 / -1 | 同上（底部操作条） |
| `ios/README-IOS.md`（QA 期间 20:34–20:37 更新）、`.github/workflows/ios-unsigned.yml`（20:36）、`ios/scripts/*.sh`（20:32–20:37） | Lead 同期更新 | 文档与 CI/截图/打包脚本；不属于 App 源码编译单元，已做交叉一致性检查（见 4） |

已核对的 SHA256（最终版）：`Theme.swift 9da21a48…`、`RootView.swift bd2108f0…`、`BeanDetailView 6d99e1ca…`、`BeanEditorView 31ec32e7…`、`RecipeDetailView c29f3e12…`（完整 17 个见附录 A）。

### 5.2 编译风险审查项与结果

| # | 审查项 | 结果 | 证据 |
| --- | --- | --- | --- |
| 5.2.1 | **iOS 26 专属符号是否都在 `#available(iOS 26.0, *)` 内** | ✅ PASS | 全量共 9 处：`Glass`/`GlassEffectContainer`/`glassEffect`/`glassEffectID`/`liquidGlassStyle`，全部位于 `if #available(iOS 26.0, *)` 分支；审计脚本输出 `GATING_OK occurrences=9` |
| 5.2.2 | **是否同时被 `#if compiler(>=6.2)` 保护（Xcode 16 无 iOS 26 SDK 也能编）** | ✅ PASS | 双门禁审计同 PASS；把 `#if compiler(>=6.2)` 分支剥离后，旧编译器可见源码中 **0 个** iOS 26 符号残留（`NO_LEAK`）；剥离后的回退分支在 macOS 26 SwiftUI 下 typecheck 通过 |
| 5.2.3 | **`@available` 函数调用合规** | ✅ PASS | `liquidGlassStyle` 标注 `@available(iOS 26.0, *)`，3 处调用（Theme body、RootView glassBar 的 `glassEffect` 参数、makerLabel）均在 `#available(iOS 26.0, *)` 内，无警告级违规 |
| 5.2.4 | **`@Namespace` / `GlassEffectContainer` / `glassEffectID` 用法** | ✅ PASS | `@Namespace private var glassNamespace` 同时传给底栏与中央按钮两个 `glassEffectID`，二者同处 `GlassEffectContainer` 子视图层级；BottomBar 真实代码 + 最小 stub 在 macOS 26 下 `swiftc -typecheck` 通过 |
| 5.2.5 | **ViewBuilder 分支** | ✅ PASS | `Group { #if compiler(>=6.2) if #available… { GlassEffectContainer{…} } else { legacyBarStack } #else legacyBarStack #endif }`、`makerLabel` 同样结构；#if/#else 与 if/else 混用在 `@ViewBuilder` 中合法，遗漏 #else 的情况不存在 |
| 5.2.6 | **旧系统分支不含 iOS 26 符号** | ✅ PASS | 剥离审计（5.2.2）为 0 泄漏；`legacyBar`/`legacyMakerLabel`/`legacySurface` 只使用 `.ultraThinMaterial`、`clipShape`、`overlay`、`shadow` 等 iOS 17 可用 API |
| 5.2.7 | **API 名称/签名与 iOS 26 SwiftUI 一致** | ✅ PASS | 从 App 源码**原样抽取**的 Theme Liquid Glass 段落、RootView BottomBar 均在 `-target arm64-apple-macos26.0` 下 typecheck 通过；Lead 的 `/tmp/glasscheck/GlassCheck.swift`、`GlassCheck2.swift` 复现 exit 0 |
| 5.2.8 | **回退视觉与布局等价性** | ✅ PASS（静态）/ ⚠️ 需真机截图 | 三处详情页 `Rectangle()` + shape fill(Material) 等价原 `.background(.ultraThinMaterial)`（无圆角矩形）；SideRail 相同；R4 建议在 Xcode 26 模拟器/真机截图对比回退前后 |
| 5.2.9 | **`.animation(.snappy(duration:))` 等辅助 API** | ✅ PASS | `.snappy` iOS 17+，与部署目标一致 |

### 5.3 独立验证证据（本机可复现）

1. **Theme.swift Liquid Glass 段落原样抽取 → `swiftc -typecheck -target arm64-apple-macos26.0` = exit 0**
2. **RootView.swift BottomBar 原样抽取 + 最小 stub（AppTab/C 颜色/liquidGlassStyle）→ 同 target typecheck = exit 0**
3. **双门禁审计**：从源码统计 9 处 iOS 26 符号，逐处验证同时处于 `#if compiler(>=6.2)` 与 `#available(iOS 26.0, *)` 作用域（`GATING_OK occurrences=9`）
4. **旧 Xcode 模拟**：剥离 `#if compiler(>=6.2)` 后可见源码无 iOS 26 符号残留（`NO_LEAK`），回退分支 typecheck 通过
5. **复现 Lead 证据**：`swiftc -typecheck -target arm64-apple-macos26.0 /tmp/glasscheck/GlassCheck2.swift` → exit 0（macOS 26 与 iOS 26 的 SwiftUI Glass API 相同）

以上证据的局限：macOS 26 SDK 能证明 **API 名称/签名/标注** 正确，但不能替代 `-target arm64-apple-ios26.0` 的真实 iOS SDK 编译（本机无 iOS SDK，`xcrun --sdk iphoneos` 不可用）。

### 5.4 残余风险与建议（R 系列）

- **R1（中，必须 Xcode）** iOS 目标真编译不可在本机验证：SwiftUI/UIKit/Vision/PhotosUI 的类型检查、资源目录编译、签名必须在 **Xcode 26** 完成。建议 Lead/CI 跑一次 `xcodebuild -project ios/BeanBook.xcodeproj -scheme BeanBook -configuration Debug -sdk iphonesimulator` 并把日志补进本报告。
- **R2（低）`#if compiler(>=6.2)` 用编译器版本推断 SDK 版本**：标准 Xcode 26.0 = Swift 6.2、Xcode 16.x = Swift 6.0/6.1，真值表正确；但若 CI/开发者混搭“Swift 6.2+ 工具链 + Xcode 16 的 iOS 18 SDK”（非常规），会编入 iOS 26 路径而失败。建议在注释/README 保留说明（现状已有注释）。
- **R3（中高，交付相关）CI 可能静默产出“无玻璃”IPA**：`.github/workflows/ios-unsigned.yml` 在 `macos-15` 上自动挑选最新 Xcode，但 `sudo -n xcode-select -s` 失败时只 `::warning::` 并继续用默认 Xcode；若 runner 上没有 Xcode 26，构建照常成功、产物无 Liquid Glass。若“带玻璃的 IPA”是交付预期，建议增加硬断言（如选不到 Xcode≥26 时 `exit 1`，或把“是否含玻璃”作为必检项）；另 `macos-15` 镜像是否预装 Xcode 26 需以 runner 实际镜像为准，必要时改 `runs-on: macos-26`。
- **R4（中，需真机/截图）** iOS 26 玻璃的观感：`safeAreaInset` 底部操作条用 `Rectangle()` 无圆角玻璃、玻璃折射/可读性、`GlassEffectContainer(spacing: 18)` 对悬浮底栏布局与融合动画的影响，均需 Xcode 26 模拟器（最好真机）确认；CI 截图只截静态页面，无法验证折射与交互。
- **R5（低）`supportsLiquidGlass` 未被引用**（`Theme.swift:152`，dead code）：不影响编译，可删除或在 UI 分支中使用，避免误读为已接入。
- **R6（低）** 若后续把最低 Xcode 提高/移除 `#if compiler(>=6.2)`，需同步确认 CI runner 的 Xcode ≥ 26，否则 CI 会失败（目前 guard 保证了向下兼容）。
- **R7（低）** 三处详情页底栏从 `.background` 改为 `.liquidGlassSurface` 后，iOS 17–25 视觉应与原版一致（shape fill + clip 等价），但仍建议模拟器截图比对（R4 一并做）。
- **R8（文档一致性）** `README-IOS.md`（QA 期间 20:34–20:37 更新版）与实现一致：明确 Xcode 26+ 才编入玻璃、Xcode 16 回退、CI 会记录是否含玻璃；后续再改 Theme 门禁时请同步文档。

---

## 6. 全量静态审查：潜在 iOS 编译风险清单（17 文件）

| # | 维度 | 结果 |
| --- | --- | --- |
| F2 | `#import`/模块完整性 | ✅ 使用 UIKit 类型的 6 个文件（Theme/Store/Transfer/ImageCutout/BeanEditorView/Components）均 `import UIKit`；`PhotosUI`→BeanEditorView、`Vision`→ImageCutout、`UniformTypeIdentifiers`→DataView/Transfer、`PhotosUI`/`CoreImage` 等各自到位；未发现“用了类型但没 import”的情况 |
| F3 | iOS 18/19/26 新 API 误用 | ✅ 全量 grep：无 iOS 18-only API（新 `Tab` 语法、`onScrollGeometryChange`、`scrollEdgeEffect` 等均未使用）；iOS 26 符号仅 9 处且全部双门禁（见 5.2） |
| F4 | `@MainActor` / 并发隔离 | ✅ `AppStore` 标注 `@MainActor`，所有调用来自 SwiftUI View（MainActor）；MakerView 计时器内 `Task { @MainActor in … }` 正确回主线程；BeanEditorView `Task { await load(item) }` 继承 View 隔离；工程 `SWIFT_VERSION=5.0`（无严格并发检查），当前无编译级问题。风险：未来切 Swift 6 语言模式可能需要处理 `UIImage`/`PhotosPickerItem` 跨 actor 的 Sendable 警告 |
| F5 | PhotosPicker / Vision 用法 | ✅ `.photosPicker(isPresented:selection:matching:)`（iOS 16+）与 `loadTransferable(type: Data.self)` 正确；`VNGenerateForegroundInstanceMaskRequest` 为 iOS 17+，与部署目标一致；`withCheckedContinuation` 的 6 条返回/抛错路径均只 resume 一次（静态走查）；无需相册权限键（见 4） |
| F6 | 强制解包/危险转换 | ✅ 全量 grep：无 `try!`、无 `as!`、无 `fatalError`/`precondition`；`guard let`/`if let` 为主 |
| F7 | 重复声明 | ✅ 无重复类型（检测到的 AppTab/Recipe/UIImage 均为 `extension` 正常形态）；17 个文件全部在 pbxproj Sources 中，无“漏加文件导致符号缺失” |
| F8 | 可用性（API 版本） | ✅ 除第 5 节 iOS 26 门禁外，未发现 iOS 18+ API；`environment(\.horizontalSizeClass)`、`NavigationStack`、`fileExporter`、`ShareLink` 等均 ≤ iOS 17 |
| F9 | 行尾混用（低） | CRLF 16 / LF 1；不影响 `swiftc`，建议统一 |
| F1 | 数据兼容性（已在模型测试实证） | `AppData`/`Bean`/`Recipe` 合成 Codable 对缺字段、未知枚举值无容错；`AppStore.init` 静默回退 DemoData（详见 3.3） |

> 说明：本机无 iOS SDK，无法对 15 个 View 文件做真实类型检查；以上为“语法解析 + 逐项模式审计 + 关键文件人工走查（Models/Store/Theme/RootView/Transfer/ImageCutout/DataView/BeanEditorView/MakerView 关键段）”。编译级残余风险集中在 R1。

---

## 7. 本地可验证 vs 必须 Xcode 验证的分界

**本机已真实验证（可复现）**
- 全部 .swift 语法解析（17/17）；
- Models/DemoData 数据层的 211 条行为断言（编译 + 运行 + 退出码）；
- 工程文件：plist 语法、pbxproj Sources 完整性、Info.plist 键、target/bundle/deployment、scheme、AppIcon、权限键；
- Liquid Glass：API 签名（macOS 26 同源 SwiftUI）、9 处符号的双门禁、旧 Xcode 回退剥离、回退分支 typecheck；
- CI 脚本 `bash -n`、YAML 解析、脚本引用与截图 `-uiTestTab` 契约。

**必须 Xcode 26（iOS 26 SDK）验证**
- iOS target 全量类型检查（SwiftUI/UIKit/Vision/PhotosUI 视图层、Asset Catalog 编译）；
- 模拟器/真机启动、五页导航、iPad 侧栏、PhotoPicker、Vision 抠图、数据导入导出；
- Liquid Glass 的渲染/折射/交互与回退视觉对比、`GlassEffectContainer` 融合动画；
- Release 构建、无签名 IPA 打包与安装验证。

---

## 8. 交付物与附录

**本次新增文件（均在允许写入范围内）**
- `tools/model-tests/run-tests.sh` —— 数据层测试构建/运行脚本；
- `tools/model-tests/ModelTests.swift` —— 211 条断言（顶层 main 代码，构建时复制为 main.swift）；
- `tools/model-tests/glass-typecheck/check-glass-api.sh` —— Liquid Glass API 类型检查 + 双门禁审计；
- `tools/model-tests/project-check.sh` —— iOS 工程静态校验；
- `tools/model-tests/README.md` —— 工具说明；
- `docs/qa/qa-report.md` —— 本报告。

### 附录 A：QA 版本固定（17 个 .swift SHASUMS，Round-1 版本）

> Round-2 终版（2026-11-06 20:45 CST）的 SHA256 见第 9.7 节，以 9.7 为准。

```
258419f5…  BeanBookApp.swift          6d99e1ca…  BeanDetailView.swift
31ec32e7…  BeanEditorView.swift       c3491509…  BeansView.swift
beca0643…  Components.swift           3409c6b7…  DataView.swift
9188c0fd…  HomeView.swift             aab43309…  ImageCutout.swift
56456a11…  MakerView.swift            7a01d882…  MenuView.swift
c991f348…  Models.swift               c29f3e12…  RecipeDetailView.swift
bd2108f0…  RootView.swift             b98e73ef…  StatsView.swift
3c466236…  Store.swift                9da21a48…  Theme.swift
9c5effc6…  Transfer.swift
```

### 附录 B：最终一次运行输出摘要

```
# run-tests.sh
PASS: 211   FAIL: 0   WARN: 0
EXIT CODE: 0

# check-glass-api.sh
macOS SDK: /Library/Developer/CommandLineTools/SDKs/MacOSX.sdk 27.0
iOS SDK:   不存在（本机无 Xcode，无法真正 -target ios）
PASS  Theme.swift Liquid Glass 段落 typecheck（macos26）
PASS  RootView.swift BottomBar typecheck（GlassEffectContainer/glassEffect/glassEffectID/@Namespace，macos26）
NO_LEAK
PASS  Xcode<=16 / Swift<6.2 可见源码无 iOS 26 专属符号残留
PASS  回退分支（legacySurface）typecheck（macos26）
GATING_OK occurrences=9
PASS  iOS 26 符号全部位于 #if compiler(>=6.2) + #available(iOS 26.0, *) 内
== SUMMARY: PASS=5 FAIL=0 ==

# project-check.sh
== SUMMARY: PASS=24 FAIL=0 ==
```

---

### 附：本次 QA 未做的事

- 未修改 `ios/` 下任何文件（含 `Info.plist`、pbxproj、Swift 源码）；
- 未安装 Xcode / 未下载大文件 / 未运行 `xcodebuild`（本机无 Xcode，命令不存在）；
- 未修改 Lead 的 `/tmp/glasscheck/` 证据文件，只做了复现运行。

---

## 9. 修正后复核（Round 2 终版，2026-11-06 20:45:35 CST）

### 9.0 本轮背景

Lead 按 `docs/reviews/liquid-glass-review.md` 的 M1–M4 建议修正代码，并采纳 QA 的 R3（CI 硬门槛）。本轮 QA 在此期间又收到 Lead 的两次更新：先补 `C.limeDeep` 描边/选中字重/`.glassEffectTransition(.materialize)`，并指出 QA 脚本 stub 缺 `C.limeDeep`。本节是在**最终代码**（源码最后修改 20:44:52，此后未再变动）上的复核结果。

### 9.1 相对 Round-1 终版（20:37）的改动

| 文件 | 修改时间 | 本轮 SHA256 | 改动摘要 |
| --- | --- | --- | --- |
| `ios/BeanBook/Theme.swift` | 20:39:53 | `214ed340…` | 删除未用 `supportsLiquidGlass`；新增共享 `BottomActionBar<Content>`（iOS26 悬浮圆角玻璃 / 旧系统全宽 material）；补充“玻璃只用于控件层”注释；Liquid Glass 段整体上移 |
| `ios/BeanBook/RootView.swift` | 20:44:52 | `7bcf9621…` | SideRail 恢复 `.background(.ultraThinMaterial)`；BottomBar：`GlassEffectContainer(spacing: 8)`、`tabLabel`/`tabForeground(_:) -> AnyShapeStyle`（iOS26 未选中 `HierarchicalShapeStyle.secondary`）、`.accessibilityAddTraits(.isSelected)`、选中 tab 字重 semibold + `C.limeDeep` 1px 描边、未选中 FAB `.glassEffectTransition(.materialize)`、makerLabel 选中态回退实心 ink 圆 |
| `ios/BeanBook/BeanDetailView.swift` | 20:40:08 | `c36fef3d…` | 底部操作条改用 `BottomActionBar { HStack {…} }` |
| `ios/BeanBook/BeanEditorView.swift` | 20:40:08 | `3cf0067b…` | 底部操作条改用 `BottomActionBar { PrimaryActionButton(…) }` |
| `ios/BeanBook/RecipeDetailView.swift` | 20:40:08 | `2dd63076…` | 底部操作条改用 `BottomActionBar { HStack {…} }` |
| `.github/workflows/ios-unsigned.yml` | 20:40:53 | — | `runs-on: macos-26`；新增 `require_liquid_glass` 输入（默认 true）；Xcode < 26 时 `exit 1` 硬失败；Job Summary 记录玻璃状态 |
| `ios/README-IOS.md`、`ios/scripts/*.sh` | 20:41:03 / 20:41:05 | — | 文档与 3 个脚本提示同步改为 `macos-26` |
| `ios/.gitignore` | 20:41 左右 | — | 新增 `artifacts/`、`*.ipa.sha256`、`*.xcresult/`（QA 的 F10 已关闭） |
| `tools/model-tests/glass-typecheck/check-glass-api.sh` | 20:45:30（QA 本轮更新） | `85f0ef8f…` | stub 补 `C.limeDeep`；新增 check 1b（BottomActionBar 声明+用法 typecheck）；check 4 改为作用域判定 + 5 样例自测；iOS 26 符号/泄漏清单补 `glassEffectTransition` |

> 其余 12 个 .swift 与 Round-1 完全一致（`Models.swift c991f348…` 等，见 9.7）；`Info.plist` 未改（`b241780a…`）。

### 9.2 四件套重跑（终版，全部 PASS，无回归）

| # | 检查 | 结果 |
| --- | --- | --- |
| 1 | `swiftc -parse` 17 个 .swift | ✅ **17/17 PASS，0 失败** |
| 2 | `tools/model-tests/run-tests.sh` | ✅ **PASS 211 / FAIL 0 / WARN 0，退出码 0**（Models.swift 未变） |
| 3 | `tools/model-tests/project-check.sh` | ✅ **PASS 24 / FAIL 0**（pbxproj/Info.plist 未变） |
| 4 | `tools/model-tests/glass-typecheck/check-glass-api.sh` | ✅ **PASS 6 / FAIL 0**；`SELFTEST_OK (5/5)`；`GATING_OK occurrences=9`；`NO_LEAK` |

运行日志：`/tmp/qa-r2b-{model,project,glass}.log`；运行时刻：2026-11-06 20:45:35 CST。此前 20:44:12 的一轮结果因 RootView 在 20:44:52 又更新而作废，以本轮为准。

### 9.3 对「check 4 判定逻辑」的确认与升级（回答 Lead）

**Lead 的补丁**（符号行在 `#if compiler(>=6.2)` 内，且 12 行窗口内出现 `#available` 或“位于 `#if` 内的 `@available` 标注”）：
- 方向正确，确实消除了删除 `supportsLiquidGlass` 后的 `GATING_PROBLEM` 误报；
- 但本质仍是**距离启发式**，有 3 个盲点：
  1. 12 行内的**无关** `#available` 会让一个未加门禁的符号被误判为合规（漏报）；
  2. `@available` 标注的声明体超过 12 行时，合规符号会误报（对象是长函数时）；
  3. 不区分 `if #available` 的 **else 分支**，在 else 分支使用 iOS 26 符号也会被误判为合规。

**终版做法（已替换）**：check 4 改为**花括号作用域判定**——符号行必须在 `#if compiler(>=6.2)` 真分支内（`#else` 不算），且属于以下任一作用域：`if #available(iOS 26.0, *)` 真分支（else 不算），或 `@available(iOS 26.0, *)` 标注的声明体（标注行本身须在 #if 真分支内）。并内置 **5 个人造样例自测**：2 类违规必须被抓到、3 类合规写法不得误报。终版输出 `SELFTEST_OK (5/5)`、`GATING_OK occurrences=9`。
- 说明：符号计数由 8 → **9**，是因为 Lead 新增 `.glassEffectTransition(.materialize)`（第 9 处 iOS 26 API），QA 已同步把它加入符号/泄漏审计清单；该调用位于 `#if compiler(>=6.2)` + `if #available(iOS 26.0, *)` 内（RootView makerLabel 未选中分支）。
- 结论：当前代码在两种判定下都 PASS；升级后的脚本假阴性/假阳性面更小，后续加长函数或在 else 分支新增符号也不会失守。**你无需再改脚本**（已由 QA 更新，hash `85f0ef8f…`）。
- 局限：仍是正则 + 花括号近似（非 SwiftSyntax 语法树），字符串/注释中的大括号已粗略剔除；真正编译验证仍须 Xcode 26。

### 9.4 终版新代码静态审查

| 项 | 结果 |
| --- | --- |
| `glassEffectTransition(.materialize)`（iOS 26 新 API） | ✅ 位于 makerLabel 的 `#if compiler(>=6.2)` + `if #available(iOS 26.0, *)` 内；macOS 26 SwiftUI typecheck 通过（签名正确）；iOS 17–25/Xcode 16 分支不触达 |
| `tabLabel` pill：`C.limeDeep.opacity(0.35)` 1px 描边 | ✅ `C.limeDeep` 在 Theme 的 `C` enum 中存在（`#7FA51D`）；纯 SwiftUI `Color`/`stroke`，无可用性风险；已补进 BottomBar 检查 stub，typecheck PASS |
| 选中 tab 字重 `selected ? .semibold : .medium` | ✅ 无可用性/类型风险 |
| `tabForeground(_:) -> AnyShapeStyle` + `HierarchicalShapeStyle.secondary` | ✅ `AnyShapeStyle`/`HierarchicalShapeStyle` 均 iOS 15+（部署目标 17 安全）；BottomBar 原样抽取 typecheck PASS |
| `.accessibilityAddTraits(selected == tab ? .isSelected : [])` | ✅ `AccessibilityTraits: SetAlgebra` 支持空数组字面量；BottomBar typecheck PASS |
| `BottomActionBar<Content>` 声明 + 三页尾随闭包用法 | ✅ check 1b 专用 typecheck PASS（`@ViewBuilder` 存储属性 memberwise init 模式成立）；legacy 分支 padding（h20/t12/b10）+ material 与改前逐字等价；iOS26 分支为悬浮圆角玻璃（内 h16/t10/b8 + 外 h16/b8） |
| SideRail 恢复 `.background(.ultraThinMaterial)` | ✅ 与 Theme 注释“iPad 侧栏保持 material”一致；大面积玻璃移除 |
| iOS 26 符号门禁 | ✅ 终版 9 处全部双门禁；旧 Xcode 剥离后 0 泄漏；回退分支 typecheck PASS |
| 旧 Xcode 语义（Info，不阻塞） | `BottomActionBar`/`tabForeground` 的 `if #available(iOS 26.0, *)` 未包 `#if compiler(>=6.2)`；Xcode 16 可编译（分支内只用 `liquidGlassSurface`，无 iOS 26 符号），但「Xcode 16 构建 + iOS 26 设备」会进入 iOS 26 布局分支且材质回退 → 表现为悬浮 material 条/层级 secondary 文字，而非旧的全宽布局。与 README“Xcode 16 无玻璃”一致，属设计选择（同 glass-reviewer 7.3-③） |

### 9.5 CI 复核（R3 / R5 关闭）

- **R3 关闭**：workflow `runs-on: macos-26`；`require_liquid_glass` 输入默认 `true`；Xcode < 26 时输出 `::error::` 并 `exit 1`（严格门槛）。`ruby -ryaml` 解析通过，`runs-on=macos-26`、默认值=true 均验证；5 个脚本 `bash -n` 全部 OK；README/3 个脚本提示已同步 macos-26。
- **R5 关闭**：`supportsLiquidGlass` 已从源码删除，`grep` 源码无残留引用（仅历史报告中提及）。
- 新增 CI 注意项：`macos-26` runner 标签需在当前 GitHub 仓库计划中可用；README 已给出 `macos-15 + require_liquid_glass=false` 或镜像自带 Xcode 26+ 的替代说明。

### 9.6 残余风险（终版）

| 编号 | 级别 | 内容 |
| --- | --- | --- |
| R1 | 中（必须 Xcode 26） | iOS target 真编译/模拟器运行/签名仍须 Xcode 26 验证；本机无 iOS SDK |
| N1 | 低（Info） | Xcode 16 构建 + iOS 26 设备时，`BottomActionBar`/`tabForeground` 走 iOS 26 布局分支 + material 回退（非旧全宽布局）；如需完全等价可给 `BottomActionBar.body` 加 `#if compiler(>=6.2)` |
| N2 | 低（需实机） | M2 选中态 FAB 玻璃形状从 GlassEffectContainer 移除，转场可能“融进底栏”；已有 `.glassEffectTransition(.materialize)` 缓解，需真机确认 |
| N3 | 低（视觉） | 选中 tab `limeSoft` pill 本身对比度弱（约 1.04:1，已有 `limeDeep` 描边 + semibold 缓解）；玻璃染色极端情况需真机看 |
| N4 | 需真机 | 玻璃观感/融合动画、iPad/SE 布局、降低透明度/增强对比度下的降级、滚动帧率（并入 glass-reviewer 7.5 清单） |

**复核结论：0 FAIL、0 回归、0 Blocker、0 Major；本机可验证项全部 PASS；剩余项均为 Xcode 26 真编译 + 真机/模拟器观感确认。与 `docs/reviews/liquid-glass-review.md` 第二轮结论一致。**

### 9.7 Round-2 终版 SHA256（2026-11-06 20:45 CST，工程非 git 仓库）

```
258419f54a6962cab96d07e53f767aa8d848d185aad9d71ba0ad83ebdb0a084d  BeanBookApp.swift
c36fef3d5640b294dbea1c2c09c2772a47d3b9cd2fe775fcd503d831e8d31662  BeanDetailView.swift
3cf0067b1d6b1dcc03238a7270296172fe85e374f89daa6cf81f2de86917c73c  BeanEditorView.swift
c349150939296cf2ad2ebc449aef3dc32f84c3b30225cdf694d09bfa782de78b  BeansView.swift
beca06435e3fe8250fefe6b726d6f393102e9ddb3070e413b08640d700751386  Components.swift
3409c6b70e62bb9767479c126f676a51fe7ffbd6f5fec41db7ebbeb98e1f01db  DataView.swift
9188c0fdad4c95e56a3334a5cb618dce9dcb488b81bcaf234139f3da95ad6eff  HomeView.swift
aab43309cef20b16023000d3bbbd74ec1a9aa1933edca97ed130e427d85fe758  ImageCutout.swift
56456a115c05531583a96ba8a67b9b709a7d9336a93f11547ad56730e60aa141  MakerView.swift
7a01d88281980b57e13acf9917a10e19f4193a6ee6bd5750e91ca9539e17a166  MenuView.swift
c991f348bc065b1fb1b4bdc0a679b72c61f7402bcecec3cd73b8d6b51b75915b  Models.swift
2dd630761c408a4793d179988f852d43a76d5227a5fee15150d7838e6423c1be  RecipeDetailView.swift
7bcf96212ec9075e9dabaf886a9e463bfd63bb293e7c197cbfaf742e7ca3eb23  RootView.swift
b98e73eff8c72fb35109721beffc3ad14a9a886df85e3c9af977d3ce5b3f87ad  StatsView.swift
3c466236a4517a4bf921eeb5d2239564cded8ce5268141cc19bf0fef4ff6992f  Store.swift
214ed3402a5d68f2a6bd546db7cc1715d043cd3e027d888789592a6f174264fa  Theme.swift
9c5effc64638b9d617b6ac96232093a768d87e3517f19b61d55ad6fceadd3662  Transfer.swift
b241780a2ffb70350e5d6e13d79e55825990c2aeecf4ca3367bcb02f386a98ef  Info.plist
```

QA 工具（终版）：`check-glass-api.sh 85f0ef8f…`、`ModelTests.swift 66d5f68f…`、`run-tests.sh e7413258…`、`project-check.sh ce7e858b…`。

---

## 10. Round 3：真实 Xcode 构建验证（2026-11-06 21:48–21:50 CST）

> 本节把此前「必须 Xcode 验证」的项从“未验证”推进为**真实构建已验证**：本机已安装 Xcode 27.2（build 27B52，iOS SDK 27.2，Swift 6.4.2），`xcodebuild`/`simctl` 可用。以下均为 QA 独立复跑（独立 DerivedData + /tmp 输出，未覆盖 `dist/` 现有 IPA）。

### 10.1 环境与版本

```
xcode-select -p          = /Applications/Xcode.app/Contents/Developer
xcodebuild -version      = Xcode 27.2 / Build version 27B52
iphoneos SDK             = 27.2
xcrun swiftc --version   = Apple Swift version 6.4.2 (swiftlang-6.4.2.1.9)
simctl runtimes          = 空（iOS 27.2 模拟器运行时正在下载：约 1.3 GB / 8.05 GB，16%）
磁盘剩余                 ≈ 110 GB
```

工程源码状态：Store.swift 已含 init 修复（`ded9f723…`），package-ipa.sh 已含 SIGPIPE 修复（`af033887…`）；其余 15 个 .swift 与 Round-2 终版一致。真实构建暴露出 Round-1 静态阶段未能发现的 1 个类型错误（见 10.3），这再次说明“必须 Xcode 编译验证”的必要性。

### 10.2 独立复跑 A：模拟器 Debug 构建

命令（自建 DerivedData `/tmp/qa-r3-dd-sim`，不触碰 Lead 的 `ios/build`）：

```bash
xcodebuild -project ios/BeanBook.xcodeproj -scheme BeanBook -configuration Debug \
  -sdk iphonesimulator -destination 'generic/platform=iOS Simulator' \
  -derivedDataPath /tmp/qa-r3-dd-sim CODE_SIGNING_ALLOWED=NO build
```

| 项 | 结果 |
| --- | --- |
| 结果 | ✅ **`** BUILD SUCCEEDED **`**，退出码 0 |
| 耗时 | 14 秒（共享 Xcode 模块缓存已热；首次冷构建会更久） |
| 日志 | `/tmp/qa-r3-logs/sim-build.log`（922 行） |
| 警告 | 1 条，均为无害：`appintentsmetadataprocessor: warning: Metadata extraction skipped, no AppIntents.framework dependency found`（工程未用 AppIntents，标准提示） |
| 错误 | 0 |
| 产物 | `/tmp/qa-r3-dd-sim/Build/Products/Debug-iphonesimulator/BeanBook.app`（Debug，含 `BeanBook.debug.dylib`/`__preview.dylib`，universal x86_64+arm64） |
| 启动参数 | Debug 二进制的 `BeanBook.debug.dylib` 中存在 2 处 `uiTestTab` 字符串 → `-uiTestTab` 截图直达路径已被编入 Debug 构建 |

### 10.3 独立复跑 B：真机 Release 无签名构建（脚本）

```bash
DERIVED_DATA=/tmp/qa-r3-dd-dev bash ios/scripts/build-device-unsigned.sh
```

| 项 | 结果 |
| --- | --- |
| 结果 | ✅ **`** BUILD SUCCEEDED **`**，`DEV_BUILD_EXIT=0` |
| 耗时 | 13 秒（模块缓存已热） |
| 日志 | `/tmp/qa-r3-logs/dev-build.log`（449 行） |
| 警告/错误 | 1 条无害 appintents 警告 / 0 错误；脚本命令行确认 `CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY= DEVELOPMENT_TEAM=` |
| 产物 | `/tmp/qa-r3-dd-dev/Build/Products/Release-iphoneos/BeanBook.app`：Mach-O 64-bit **arm64**，`LC_BUILD_VERSION platform 2`（iOS）、**minos 17.0**、sdk 27.2，`code object is not signed at all`（未签名，符合预期） |
| 与 Lead `ios/build` 产物对比 | `Info.plist`、`Assets.car`、两个 AppIcon、`PkgInfo` **逐字节相同**；主可执行文件仅差 `LC_UUID`（26 字节随机 + 布局），属正常不可复现构建，非代码差异 |

### 10.4 独立复跑 C：未签名 IPA（脚本，输出到 /tmp）

```bash
# ① 用 Lead 已构建的 app 重打包（不覆盖 dist）
bash ios/scripts/package-ipa.sh --app ios/build/Build/Products/Release-iphoneos/BeanBook.app --out /tmp/qa-ipa
# ② 用 QA 自己新构建的 app 打包
bash ios/scripts/package-ipa.sh --app /tmp/qa-r3-dd-dev/Build/Products/Release-iphoneos/BeanBook.app --out /tmp/qa-ipa-fresh
```

| 项 | 结果 |
| --- | --- |
| 结果 | ✅ 两次均 `PACKAGE_EXIT=0`，耗时约 1 秒 |
| 产物 | `/tmp/qa-ipa/BeanBook-1.0-unsigned.ipa`（984,125 B）、`/tmp/qa-ipa-fresh/BeanBook-1.0-unsigned.ipa`（984,140 B），各带 `.sha256`（`<hash>  <filename>` 格式正确） |
| 结构校验 | IPA 内 8 项：`Payload/` + `BeanBook.app/{AppIcon60x60@2x.png, Assets.car, AppIcon76x76@2x~ipad.png, BeanBook, Info.plist, PkgInfo}`；`Payload/BeanBook.app/Info.plist` 精确匹配 ✓ |
| 二进制校验 | arm64、platform iOS、minos 17.0、sdk 27.2、**未签名**（`codesign -dv` 报 code object is not signed at all；无 `_CodeSignature`）✓ |
| Info.plist | `CFBundleIdentifier=com.brewkin.beanbook.ios`、`CFBundleShortVersionString=1.0`、`MinimumOSVersion=17.0`、`DTSDKName=iphoneos27.2`、`UIDeviceFamily=[1,2]` ✓ |
| 内容一致性 | 用 Lead app 重打包的 `/tmp/qa-ipa` 与 `dist/BeanBook-1.0-unsigned.ipa` **Payload 6 个文件 SHA256 全部相同**、两者字节数同为 984,125 → dist IPA 内容 = 当前 `ios/build` 产物；两者 SHA 不同仅因 zip 中 `Payload/` 目录条目的时间戳（21:45 vs 21:48），**IPA 字节级不可复现（正常），SHA 用于完整性校验** |

### 10.5 dist 最终 IPA 独立核验（未修改）

| 项 | 值 |
| --- | --- |
| 文件 | `dist/BeanBook-1.0-unsigned.ipa`，984,125 B（≈961 KB，`du` 964K） |
| SHA256 | `2ffbab0686b733a500fc7221f348a9717a998e920f26993a28a867023ed2e2b2`（与 `.sha256` 内容一致 ✓） |
| 二进制 | arm64 Mach-O，platform iOS(2)，minos 17.0，sdk 27.2，**未签名**（无 `_CodeSignature`） |
| **Liquid Glass 证据** | 二进制 undefined symbols 含 `SwiftUI.GlassEffectContainer`、`GlassEffectTransition.materialize`、`View.glassEffect(_:in:)`、`View.glassEffectID(_:in:)`、`View.glassEffectTransition(_:)`、`Glass.regular/tint/interactive` → **Xcode 27.2/Swift 6.4.2（≥6.2）编译时 `#if compiler(>=6.2)` 为真，Liquid Glass 分支已编入 Release 产物**（此前“代码是否被真正编入”的疑虑解除） |

### 10.6 Store.swift `init` 修复复核（真实编译错误）

- **原问题**：`AppStore.init` 中先给 `data`（`@Published` 属性）赋值，随后在 `draft` 尚未初始化时读取 `self.data` 计算 `draft` 的初始值 → Swift 报 `'self' used before all stored properties are initialized`。该错误只有在真实 SwiftUI/Swift 编译器下才会暴露，`swiftc -parse`（Round 1/2 使用的 CLT 手段）无法发现。
- **修复**：引入局部 `let initialData` 计算初始数据，先 `data = initialData`，再用 `initialData` 计算 `draft`。当前代码见 `Store.swift:16-43`。
- **复核结论**：✅ 正确且无副作用。
  - 语义与原意一致（“先确定初始数据 → 再据此算 draft”），加载失败回退 `DemoData.make()` 的逻辑不变；
  - 所有存储属性完成初始化前不再读取 `self`；
  - `data`/`draft` 的赋值仍发生在 init 内，`@Published` 的 `objectWillChange` 此时没有订阅者，无 UI 副作用；
  - `if !FileManager... { save() }` 的时机与内容不变；
  - Debug/Release 两种配置均构建通过（10.2/10.3）→ 修复有效。

### 10.7 package-ipa.sh SIGPIPE 修复复核 + 其余管道隐患审计

- **原 bug**：`unzip -l ... | grep -q "Payload/BeanBook.app/Info.plist"` 在 `set -o pipefail` 下，`grep -q` 命中后立即退出 → `unzip` 写管道收到 SIGPIPE（141）→ 整条管道判失败 → 误报「IPA 结构异常」。
- **修复**：改为 `unzip -Z1 "$ipa" > 临时清单` 后再 `grep -qx`，并在失败路径清理临时文件（当前 `package-ipa.sh:210-226`）。
- **复核结论**：✅ 正确。QA 独立做了故障复现与修复验证：

```
旧写法 `unzip -l dist/BeanBook-1.0-unsigned.ipa | grep -q ...`，50 次中 33 次返回非 0（SIGPIPE 竞态，复现 Lead 报告）
新写法 `unzip -Z1 > tmpfile && grep -qx ...`，50 次全部通过（0 失败）
通用演示：set -o pipefail; seq 1 200000 | grep -q 1  → rc=141；落文件后 grep -qx → rc=0
```

- **其余脚本/工作流管道审计**（5 个脚本 + workflow，逐一 grep 所有 `|`）：
  - 仅剩 1 处同类 anti-pattern：`package-ipa.sh:131` 的 `security find-identity -v -p codesigning | grep -Fq "$SIGN_IDENTITY"`（只影响可选 `--sign` 重签名路径；本机 `security` 输出仅 1 行，实际风险极低）。建议后续与正式修复统一为「输出落变量/临时文件再 grep」，彻底消除同类隐患。
  - `build-all.sh`/`build-device-unsigned.sh`/`build-simulator.sh` 各 1 处 `xcodebuild -version | head -1`：生产者仅 2 行输出，实测 pipefail 下 rc=0，风险可忽略（即便 SIGPIPE 也发生在命令替换内，只影响显示）。
  - `| sed`、`| awk`、`| cut` 均读到 EOF，无早退；workflow 的 `| head -1 || true` 已兜底；`run-simulator-screenshots.sh` 无早退消费者管道。
  - 结论：除上述 1 条 advisory 外，**未发现其他会误伤构建/打包的 pipefail 隐患**。

### 10.8 静态回归（Store.swift 修改后）

| 检查 | 结果 |
| --- | --- |
| `swiftc -parse` 17 个 .swift | ✅ 17/17（0 失败） |
| `run-tests.sh` 数据层 | ✅ PASS 211 / FAIL 0 / exit 0（Store 中 DemoData 抽取逻辑未受影响） |
| `project-check.sh` | ✅ PASS 24 / FAIL 0 |
| `check-glass-api.sh` | ✅ PASS 6 / FAIL 0；SELFTEST 5/5；GATING 9；NO_LEAK（Theme/RootView 未变） |

### 10.9 阶段结论与剩余事项

- **R1 状态更新**：真实 Xcode 编译已验证 —— 模拟器 Debug、真机 Release 无签名均 `BUILD SUCCEEDED`；未签名 IPA 结构/SHA/二进制属性均独立核验通过；Liquid Glass 分支确认编入 Release 二进制。
- **剩余（Round 4，等 Lead 通知 runtime 就绪与截图生成后）**：
  1. 安装 iOS 27.2 模拟器 runtime（当前下载中，约 16%），必要时用 `xcrun simctl create "iPhone 17" com.apple.CoreSimulator.SimDeviceType.iPhone-17 <runtime-id>` 创建设备（`simctl list devices available` 若为空，截图脚本会直接报错退出；脚本报错提示已友好）；
  2. 启动模拟器 → `-uiTestTab home/beans/maker/menu/stats` 逐页截图，核对 `ios/artifacts/screenshots/*.png` 五页齐全、非空、尺寸合理（10.10 追加）；
  3. `xcrun simctl spawn booted log show --last 5m --predicate 'process == "BeanBook"'` 检查崩溃/错误日志；
  4. 真机安装需用户 Apple ID/证书自签（本机无法代替验收）。
- **风险更新**：N1（Xcode 16 + iOS 26 组合下的 `BottomActionBar` 布局分支）仍为 Info 级；N2/N3/N4（玻璃观感/过渡/可读性/帧率）仍需模拟器截图与真机确认；**无新增 Blocker/Major**。

---

## 11. Round 4：模拟器 UI 实测（2026-11-06 22:12–22:16 CST）

> 本节完成最后一段实测闭环：iOS 27.2 Simulator Runtime 已安装、iPhone Duo（折叠屏，双显示器）已启动，App 已安装并逐页运行；9 张截图、崩溃日志、最终 IPA 均独立复核。QA 全部阶段（Round 1–4）至此收尾。

### 11.1 环境与最终产物

```
Runtime       : iOS 27.2 (27.2 - 24B91014) - com.apple.CoreSimulator.SimRuntime.iOS-27-2-iPhone19-4
设备          : iPhone Duo (D06DB1AD-25F7-4AC6-802E-FD9066D35E88) Booted
App           : 已安装、运行中（UIKitApplication:com.brewkin.beanbook.ios，PID 87640/89820 等）
截图          : ios/artifacts/screenshots/ 9 张 + build-info.txt（同份已复制 screenshots/ios/）
最终 IPA      : dist/BeanBook-1.0-unsigned.ipa（987,074 B）SHA256 29652a77…（与 .sha256 一致）
Xcode         : 27.2 (27B52) / iOS SDK 27.2 / Swift 6.4.2
```

### 11.2 A. 9 张截图复核（全部 PASS）

| 截图 | 尺寸 | 大小 | 内容人工核对 | 结论 |
| --- | --- | --- | --- | --- |
| `home.png` | 1398×2034 | 713,474 B | 首页：问候语/Quick Pour/统计条/最近在用；底栏玻璃 + 未选中态青柠玻璃 FAB（在 GlassEffectContainer 内融合） | ✅ |
| `beans.png` | 1398×2034 | 643,119 B | 豆仓：2 支豆卡片、筛选 chips、选中「豆子」pill；底栏玻璃正常 | ✅ |
| `maker.png` | 1398×2034 | 742,941 B | 调一杯：空杯画布、材料托盘、选中态**实心 ink 圆 FAB 画在玻璃底栏之上**（不再被玻璃盖住变灰） | ✅（修复生效） |
| `menu.png` | 1398×2034 | 624,209 B | 菜单：3 杯汇总、数据与分享入口、配方别册、选中「菜单」pill | ✅ |
| `stats.png` | 1398×2034 | 588,304 B | 统计：近 30 天 hero、冲煮节奏柱状；选中「统计」pill | ✅ |
| `route-bean.png` | 1398×2034 | 534,773 B | 豆子详情：**悬浮圆角玻璃 BottomActionBar「编辑 / 调一杯」**，内容从玻璃下透过、左右 16pt 留边 | ✅ |
| `route-recipe.png` | 1398×2034 | 625,905 B | 配方详情：**悬浮玻璃 BottomActionBar「分享文件 / 再调一杯」** | ✅ |
| `route-data.png` | 1398×2034 | 571,718 B | 数据管理页（该页设计上无底部操作条，符合预期），导出/合并/覆盖卡片完整 | ✅ |
| `route-newbean.png` | 1398×2034 | 480,599 B | 添加豆子编辑页：**悬浮玻璃 BottomActionBar「收进豆仓」**、相册选择入口 | ✅ |

- 9 张尺寸全部一致（1398×2034），无空白/损坏/错页；状态栏统一固定为 09:41 + Wi-Fi + 满电（`simctl status_bar override` 生效）。
- `ios/artifacts/screenshots/` 与 `screenshots/ios/` 的同名文件 **SHA256 全部一致**（逐字节同份），`build-info.txt` 亦一致（simulator=iPhone Duo、runtime=iOS 27.2、app 路径、截取时间 22:12:01）。
- 截图 SHA256 清单见 11.8。

### 11.3 独立端到端复跑截图脚本（发现 1 个 Minor 脚本鲁棒性问题）

为验证「交付脚本可复现」，QA 用同一脚本独立复跑到 `/tmp`（不改交付产物）：

```bash
bash ios/scripts/run-simulator-screenshots.sh --skip-build --sim "iPhone Duo" \
  --app ios/build/Build/Products/Debug-iphonesimulator/BeanBook.app \
  --out /tmp/qa-r4-shots --routes "bean recipe data newbean"
# => SCREENSHOT_SCRIPT_EXIT=0，生成 9 张 + build-info；多显示器自动检测日志 9 次
#    “检测到多显示器设备，自动使用 --display=1 截图”（Lead 新增的 --display 自动检测生效）
```

结果对比：

| 项 | 结果 |
| --- | --- |
| 8/9 截图 | ✅ 与交付截图 **SHA256 逐字节相同**（beans/maker/menu/route-bean/route-data/route-newbean 全同；stats、route-recipe 仅文件大小差 ~100 B、尺寸/内容一致，属动画帧/渲染时序微差） |
| **home.png（首次复跑）** | ⚠️ **空白白屏**（仅状态栏，110,043 B）：脚本在 `simctl install` 后第一次冷启动，`--settle` 默认 3s 不足，截图时机早于首帧渲染；脚本只检查 `[[ -s file ]]`（非空），空白 PNG 也会通过 |
| 复现/定位 | QA 用 `TABS=home --settle 8` 重试 → 生成 713,474 B，且与交付 `home.png` **SHA256 完全相同**（`5876bfb1…`）→ 证明是**冷启动截图时机问题**，非 App/交付产物问题（交付的 9 张均有效，已人工逐张核对） |
| 交付产物影响 | 无；仅 CI 复跑时可能出现偶发空白截图（概率性，依赖启动耗时） |

**建议（Minor，非阻塞）**：截图脚本对「安装后第一次启动」增加就绪等待或重试，例如：① 首张截图前额外等待/轮询 App 前台与首帧；② 对截图做非空校验之外的健壮性检查（如 PNG 字节数阈值或图像方差阈值）后重试 1–2 次；③ 或在 `install_app` 后先预热启动一次再开始正式截图。

### 11.4 崩溃与错误日志复核（PASS）

- `xcrun simctl spawn <udid> log show --last 15m --predicate 'process == "BeanBook"'`：6201 行；`crash|fatal|exception|abort|abnormal|terminat` 检索 **0 命中**（另有 49 行“crash 关键词”实为 `signalKeyboardChanged` 等键盘日志，误报已排除）。
- 错误/故障级消息仅 31 行，全部为系统无害日志：BoardServices pointer UI 兼容性（22）、app_launch_measurement CA Event 发送失败（4）、CoreFSCache fopen 失败（2）、RenderBox 着色管线构建耗时提示（1）。
- 无 `~/Library/Logs/DiagnosticReports/BeanBook*`、无模拟器 CrashReporter 文件；9 次启动对应 9 个 PID（逐页 `simctl terminate/launch` 的正常行为，非崩溃重启）。
- QA 复跑截图脚本后再查日志（last 8m）：仍 **0 crash/fatal**，错误级日志同为上述系统无害项；App 进程正常运行。

### 11.5 B. 最终 IPA 独立核验（PASS）

| 项 | 结果 |
| --- | --- |
| 文件 | `dist/BeanBook-1.0-unsigned.ipa` 987,074 B |
| SHA256 | `29652a7753d818ac50164ddda46958262506701f937e6143c20233eca5f1d6e9`，与 `dist/BeanBook-1.0-unsigned.ipa.sha256` 完全一致 ✓ |
| 结构 | zip 内 8 项：`Payload/` + `BeanBook.app/{AppIcon60x60@2x.png, Assets.car, AppIcon76x76@2x~ipad.png, BeanBook, Info.plist, PkgInfo}` ✓ |
| 二进制 | Mach-O arm64、`LC_BUILD_VERSION platform 2`（iOS）、**minos 17.0**、sdk 27.2、**未签名**（`codesign -dv` = code object is not signed at all，无 `_CodeSignature`）✓ |
| Info.plist | `CFBundleIdentifier=com.brewkin.beanbook.ios`、`CFBundleShortVersionString=1.0`、`MinimumOSVersion=17.0`、`DTSDKName=iphoneos27.2`、`UIDeviceFamily=[1,2]` ✓ |
| Liquid Glass 编入 | Release 二进制 undefined symbols 含 `GlassEffectContainer`、`GlassEffectTransition.materialize`、`glassEffect/glassEffectID/glassEffectTransition`、`Glass.regular/tint/interactive`（共 11 个相关符号）✓ |
| 内容一致性 | IPA 内 6 个 payload 文件 SHA256 与 `ios/build/Build/Products/Release-iphoneos/BeanBook.app` **逐字节相同** ✓ |
| 重打包验证 | 用当前 app 重打包到 /tmp：`PACKAGE_EXIT=0`，同 987,074 B，SHA `f9d7eeac…`（与 dist 不同仅因 zip 中 `Payload/` 目录时间戳；payload 内容完全相同） |
| 独立重建最终源码 | `DERIVED_DATA=/tmp/qa-r4-dd bash ios/scripts/build-device-unsigned.sh` → ✅ BUILD SUCCEEDED（15s、1 条无害 appintents 警告、0 error）；产物 arm64/minos 17.0/未签名；Info/Assets/图标与 Lead 产物逐字节相同，主二进制仅 `LC_UUID` 差异；用其打包得 /tmp IPA（987,075 B，SHA `43b0a82f…`）结构合法 |

### 11.6 C. 最终源码静态回归（PASS）

| 检查 | 结果 |
| --- | --- |
| `swiftc -parse` 17 个 .swift | ✅ 17/17，0 失败（RootView 最终版 `2d7ba1db…`） |
| `run-tests.sh` | ✅ PASS 211 / FAIL 0 / exit 0 |
| `project-check.sh` | ✅ PASS 24 / FAIL 0 |
| `check-glass-api.sh` | ✅ PASS 6 / FAIL 0；SELFTEST 5/5；GATING 9；NO_LEAK（RootView 新增 overlay/route 代码通过抽取 typecheck） |
| Debug 启动参数 | `ios/build/.../Debug-iphonesimulator/BeanBook.app` 的 debug dylib 中 `uiTestTab`×2、`uiTestRoute`×2 → 两个启动参数均已编入 Debug 构建；Release 中不含（`#if DEBUG`）✓ |
| 代码审查 | `Route.launchArgumentValue`（`-uiTestRoute`，Debug only）+ `openLaunchRouteIfNeeded()`（onAppear 一次性打开最近豆/配方/数据/新建页）；BottomBar 选中态 `makerButton` 移到 `GlassEffectContainer` 外的 `.overlay(alignment: .top)`，未选中仍在容器内参与融合 → 与本轮 maker/home 截图行为一致 ✓ |

### 11.7 R1 / N2–N4 状态更新（Round 4 结论）

| 编号 | 原状态 | 更新后 | 依据 |
| --- | --- | --- | --- |
| **R1** 必须 Xcode 26 真编译/运行 | 未验证 | ✅ **关闭** | 真实 Xcode 27.2 编译（Debug 模拟器 + Release 真机构建均 BUILD SUCCEEDED）、iOS 27.2 模拟器安装运行、9 张页面截图、无崩溃日志均已实测。剩余“真机安装”需用户 Apple ID/证书自签，属交付流程非代码质量项 |
| **N1** Xcode16+iOS26 下 BottomActionBar 布局分支 | Info | Info（未变） | 不影响 Xcode 26 正常路径；CI 已硬性要求 Xcode≥26 |
| **N2** FAB 选中态玻璃形状移除过渡 | 需实机 | ✅ **降为 Info（已实测两态形态正确）** | maker 选中（实心 ink 圆在玻璃上方）与 home 未选中（青柠玻璃圆在容器内）截图均正确；`.materialize` 过渡动画平滑度静态截图无法断言，建议真机看动画 |
| **N3** 选中 tab pill 可辨识度 | 低 | ✅ **关闭（视觉可接受）** | beans/menu/stats 截图可见选中态 lime pill + semibold 文字 + `limeDeep` 描边，层级清晰 |
| **N4** 布局/玻璃渲染/降级/帧率 | 需真机 | ⚠️ **部分关闭，保留 Info** | iPhone Duo 折叠屏模拟器上五页+四详情布局/玻璃渲染/悬浮 BottomActionBar 均正常；**“降低透明度/增强对比度”与真机帧率仍未实测**（需真机辅助功能抽检） |
| 新增 N5（Info） | — | Info | iOS 17–25 旧系统回退视觉未在旧 runtime 实测（本机仅装 iOS 27.2 runtime）；回退分支代码静态/类型检查通过且与改前逐字等价，风险低 |
| 新增 P1（Minor，脚本） | — | Minor（非阻塞） | 截图脚本安装后首张冷启动 `--settle 3s` 可能截到空白（QA 复跑复现，交付产物无问题）；建议首张等待/重试或空白检测，见 11.3 |

### 11.8 交付物 SHA256（终版，2026-11-06 22:16 CST）

**截图（`ios/artifacts/screenshots/`，与 `screenshots/ios/` 同份）：**

```
83ff39b3cfcc1cdae4d190c9c03ee8aafb180341aacbeb2b719f7d8c68d09077  beans.png
5876bfb1ff59657f9f503ecb2db4028494ea805d69c900ad17b936fc5b7067c2  home.png
c474145bbf9cdf3d51bfb62a59221f290c50f4188a98cc48d63b4ce892bcd7a9  maker.png
0fc730e96483807a7f9c15e45080c2e3fbd4407d7dbceafe80ba192f4ddc5aee  menu.png
84bf81b22b15a2c40708595352a0bbf0ab96cb0dd45dd313f7392de35d911d9a  route-bean.png
2e163ac0f9e4e995d2ee9d208a9c439a067398dfb5a001a2572c73cbbccfe3d1  route-data.png
66fec6338bae4e4652198142de7543fca7e6554067734f4b977cdc21430133b9  route-newbean.png
c6d470e75de8a3eee10c0c9f4569ccd87c07048f080f76f93f20deb946af4c35  route-recipe.png
1c35e86526c4e5a93a6ebcc5ccf1eff9ee1a1e6d27372d2160890500d7a6f0d4  stats.png
2fa02d97141b7423263d4f71108865a2064d6089abd62bada492b4ddb7184bf1  build-info.txt
```

**其余最终产物：**

```
dist/BeanBook-1.0-unsigned.ipa                       987,074 B
  SHA256 = 29652a7753d818ac50164ddda46958262506701f937e6143c20233eca5f1d6e9
dist/BeanBook-1.0-unsigned.ipa.sha256                （内容一致）

源码（17 个 .swift + Info.plist，仅列本轮变化/关键项）：
2d7ba1dbe065ff996b66162994ad044f4c8e4e4f4c97d786d0c5de085659c62c  RootView.swift（本轮新增 -uiTestRoute + 选中 FAB overlay 修复）
ded9f72308a31dca2f81788d0036ad9a232abaa81002e2e9dbe150f8c2c411d8  Store.swift（init 修复）
214ed3402a5d68f2a6bd546db7cc1715d043cd3e027d888789592a6f174264fa  Theme.swift
c991f348bc065b1fb1b4dc0a679b72c61f7402bcecec3cd73b8d6b51b75915b  Models.swift
b241780a2ffb70350e5d6e13d79e55825990c2aeecf4ca3367bcb02f386a98ef  Info.plist
（其余 12 个 .swift 与 Round-2 终版一致，见 9.7）

脚本：
e9c9705b858837a854a26e0618718dfd6bdeb11f655ee1347f4696ed34a4abe9  ios/scripts/run-simulator-screenshots.sh（--display 自动检测 + --routes）
ac299d6231d1aa01a43d6beb2c91472088d5ce30f01fee0be381d9d3c4633b58  ios/scripts/package-ipa.sh
```

### 11.9 Round 4 结论

- **0 Blocker、0 Major、1 Minor（截图脚本冷启动时机）+ 2 Info（真机辅助功能/帧率、iOS 17–25 回退视觉未实测）**。
- 9 张模拟器实拍截图齐全、尺寸一致、内容正确：五主页面 + 豆子详情/配方详情/数据管理/添加豆子；「调一杯」选中态实心 FAB 已不再被玻璃底栏覆盖（修复生效）；详情页悬浮玻璃 BottomActionBar 正常。
- 最终未签名 IPA SHA256/结构/架构/部署目标/未签名状态全部独立核验通过，且内容与最新构建产物逐字节一致；真实 Xcode 27.2 编译、模拟器运行、无崩溃日志均已闭环。
- **QA 收尾：task-5 完成；R1 关闭，N2/N3 关闭，N4/N5 保留 Info（需真机辅助功能与旧系统抽检），P1 为截图脚本鲁棒性建议（不影响交付）。工程可交付。**

---

## 12. 最终产物核验（Round 5，2026-11-06 22:21–22:24 CST）

> Round 5 变更：glass-reviewer 按真实截图像素评审发现「未选中 tab 文字对比度仅 2.87:1」——iOS 26 的 `.secondary` 在 Liquid Glass 上被系统 vibrancy 提亮，不达 WCAG AA。Lead 已改为显式 `C.ink.opacity(0.72)`（约 5.81:1），重新编译、重截全部 9 张截图并重建最终未签名 IPA；同时按 QA 上轮 P1 给截图脚本加了「冷启动预热」。本节为 QA 对最终产物的快速独立核验（QA 仅更新本报告，未改 `ios/`、`dist/`、`screenshots/ios/`）。

### 12.1 最终产物与版本

```
Xcode / SDK        : 27.2 (27B52) / iOS SDK 27.2 / Swift 6.4.2
Simulator          : iOS 27.2 runtime，iPhone Duo（1398×2034 截图）
最终 IPA           : dist/BeanBook-1.0-unsigned.ipa（986,089 B，≈963 KB）
  SHA256           : 639dcc1cbb22c1eb3be169bfd02dde5052e5bfbd8b10dbaa72f14032aae5a16b
                     （与 dist/BeanBook-1.0-unsigned.ipa.sha256 完全一致）
9 张截图           : ios/artifacts/screenshots/（22:22:12 更新，与 screenshots/ios/ 同份）
源码变化           : RootView.swift b3c34358…（tab 文字改为 C.ink.opacity(0.72)）
截图脚本           : run-simulator-screenshots.sh 30fef4ac…（新增冷启动预热）
```

> 本节最终 IPA 取代 Round 4 记录的 `29652a77…`（Round 4 证据保留在 11.8，仅作历史）。

### 12.2 新 IPA 独立核验（PASS）

| 项 | 结果 |
| --- | --- |
| 大小 / SHA256 | 986,089 B；`639dcc1cbb22c1eb3be169bfd02dde5052e5bfbd8b10dbaa72f14032aae5a16b` **与 `.sha256` 一致** ✓ |
| 结构 | zip 内 8 项：`Payload/` + `BeanBook.app/{AppIcon60x60@2x.png, Assets.car, AppIcon76x76@2x~ipad.png, BeanBook, Info.plist, PkgInfo}` ✓ |
| 二进制 | Mach-O **arm64**、`LC_BUILD_VERSION platform 2`（iOS）、**minos 17.0**、sdk 27.2、**未签名**（`code object is not signed at all`，无 `_CodeSignature`）✓ |
| Info.plist | `CFBundleIdentifier=com.brewkin.beanbook.ios`、`CFBundleShortVersionString=1.0`、`MinimumOSVersion=17.0`、`DTSDKName=iphoneos27.2`、`UIDeviceFamily=[1,2]` ✓ |
| 内容一致性 | IPA 内 6 个 payload 文件 SHA256 与 `ios/build/Build/Products/Release-iphoneos/BeanBook.app` **逐字节相同** ✓ |
| Liquid Glass 编入 | Release 二进制 undefined symbols 中与 Glass 相关共 **15 个**（`GlassEffectContainer`×3、`GlassEffectTransition.materialize`×2、`glassEffect`×2、`glassEffectID`×2、`glassEffectTransition`×2、`Glass.regular/tint/interactive`×4）✓ |

### 12.3 9 张新截图核验（PASS）

- 9 张全部可打开、RGBA、尺寸统一 **1398×2034**；`ios/artifacts/screenshots/` 与 `screenshots/ios/` 同名文件 **SHA256 全部一致**，build-info.txt 也一致（时间为 22:21:25）。
- 本轮截图 SHA256（最终版）：

```
365f5f8efead58564141647b5d4e693194e3a735fd002d8e251837ac02a19ebe  beans.png
a6c0750dbf9c1c1e03e2bde312ccc490f359dda76bc78280e88117b006551e6d  home.png
1dc47b4ac6231a992333858ec9e07ba9b0e4aa1a76c9e5a4387915c4b8d7d08a  maker.png
069c0999af27f6332aa0610d033fc0b289879fcbeb8b84396051bdaa4929f691  menu.png
84bf81b22b15a2c40708595352a0bbf0ab96cb0dd45dd313f7392de35d911d9a  route-bean.png
2e163ac0f9e4e995d2ee9d208a9c439a067398dfb5a001a2572c73cbbccfe3d1  route-data.png
66fec6338bae4e4652198142de7543fca7e6554067734f4b977cdc21430133b9  route-newbean.png
0c8e0edefcc91c665b84d75f57fc31564db96652e50ab26078ead011703ba03f  route-recipe.png
6712c35206424a6974905b6f6962242a2d6d2c5b7babf8f5faf2e18be12fce5c  stats.png
16baea3f0705f9ccb9484da508bbf9aacd5fa7fe4b30992f645585b955f01462  build-info.txt
```

**未选中 tab 文字变深 — 像素级验证**（方法：以 Round 4 旧截图为基准，在底栏区域 y=1600..2000 做像素 diff，差异像素仅集中在未选中 tab 文字行 bbox y=1764..1875；取差异像素中最暗 20% 的 WCAG 相对亮度作文字色，取同 bbox 未变化像素中位亮度作背景，计算对比度）：

| 截图 | 变化像素 | 旧文字 L / 对比度 | 新文字 L / 对比度 | 亮度变化 |
| --- | --- | --- | --- | --- |
| home | 5,209 px | L=0.1962，**3.30:1** | L=0.0978，**5.50:1** | **−50.1%** |
| stats | 5,043 px | L=0.2926，**2.94:1** | L=0.1146，**6.11:1** | **−60.8%** |

- 结论：未选中 tab 文字明显变深，对比度从 ~3:1 提升到 ~5.5–6.1:1，达到 WCAG AA（4.5:1）；与 Lead/评审给出的 2.87:1→5.81:1 方向与量级一致（绝对数值差异来自采样方法不同：QA 用「差异像素最暗 20%」近似字形核心，评审用局部采样）。
- 差异 bbox 仅落在未选中 tab 文字行（y=1764..1875，水平覆盖未选中 tab 文字列），**未出现布局/尺寸/其他 UI 变化**；选中态文字仍为 `C.ink`，符合设计。

### 12.4 P1 修复复核：截图脚本冷启动预热（PASS）

- 脚本现在在 `capture_screenshots` 正式循环前增加了预热：`simctl launch -uiTestTab home` → `sleep(SETTLE_SECONDS + 3)` → `terminate`，再进入逐页截图（`run-simulator-screenshots.sh` 300–309 行附近）。
- QA 独立选择「fresh install」场景复测：`TABS=home ... --out /tmp/qa-r5-shots` → exit 0，`home.png` **714,184 B**（非空白）；与交付的新 `home.png`（714,195 B）逐像素比较差异仅 **171 / 2,843,532 = 0.006%** → 内容一致，P1（冷启动首张空白）**已修复并独立验证**。
- 说明：截图脚本 hash 由 Round 4 的 `e9c9705b…` 更新为 `30fef4ac…`。

### 12.5 最终源码静态回归（PASS）

| 检查 | 结果 |
| --- | --- |
| `swiftc -parse` 17 个 .swift | ✅ 17/17，0 失败（RootView 最终版 `b3c34358…`） |
| `run-tests.sh` | ✅ PASS 211 / FAIL 0 / exit 0 |
| `project-check.sh` | ✅ PASS 24 / FAIL 0 |
| `check-glass-api.sh` | ✅ PASS 6 / FAIL 0；SELFTEST 5/5；GATING 9；NO_LEAK |
| 代码检查 | `tabForeground` 的 iOS 26 未选中分支已改为 `AnyShapeStyle(C.ink.opacity(0.72))`，仅注释保留 `HierarchicalShapeStyle.secondary` 说明，无该 API 调用残留；未新增 iOS 26 API（GATING 仍 9 处，均双门禁）✓ |

### 12.6 Round 5 结论（最终交付）

- **最终产物核验全部 PASS、0 FAIL**：新 IPA（SHA256 `639dcc1c…`）SHA/结构/arm64/minos 17.0/未签名/玻璃符号 15 个均核验通过；9 张新截图齐全、尺寸一致、与 `screenshots/ios/` 同份；未选中 tab 文字像素级对比度由 ~3:1 提升至 ~5.5–6.1:1（AA 达标）；P1 冷启动预热修复经 fresh-install 复测通过。
- **最终交付物**：`dist/BeanBook-1.0-unsigned.ipa`（963 KB，arm64 / iOS / minos 17.0 / 未签名）、`screenshots/ios/`（五页 + 四详情）、`ios/artifacts/screenshots/`、源码 `ios/BeanBook/*.swift`。
- **QA 全流程收尾**：Round 1–5 完成；R1 关闭；N2/N3/P1 关闭；N4（真机辅助功能/帧率）与 N5（iOS 17–25 回退视觉）保留为 Info，建议交付后真机抽检；无 Blocker/Major。工程可交付。

---

## 13. 底部导航重设计 + 最终产物核验（Round 6，2026-11-06 22:34–22:38 CST）

> 用户要求按 Liquid Glass 标准重绘底部导航栏并加入「点击时滑块滑动动画」。Lead 整体重写 `RootView.swift` 的 `BottomBar`：移除「4 tab + 中央大 FAB」安卓式布局，改为 5 个等分入口的悬浮玻璃胶囊 + 青柠玻璃选中滑块（弹簧滑动动画）；iOS 26 走真 Liquid Glass，旧系统走 material/limeSoft 回退；新增 Debug-only `-uiTestAutoCycle <秒>` 供录屏/动画验证。本节为 QA 对最终代码与产物的独立复核（QA 只更新本报告，未改 `ios/` 源码、`dist/` 最终 IPA 与 `screenshots/ios/`）。

### 13.1 本轮代码变更（RootView.swift 整体重写 BottomBar）

| 变更 | 说明 |
| --- | --- |
| 布局 | `GeometryReader` 计算 `itemWidth = width/5`；五个 `AppTab.allCases` 等分入口；悬浮玻璃胶囊（`barHeight=68pt`、左右 `14pt`、距底 `8pt`、圆角 34 连续圆角） |
| 选中滑块 | `selectionIndicator` 宽 `itemWidth-8` / 高 `barHeight-22`；iOS 26：`Capsule().glassEffect(liquidGlassStyle(tint: C.lime.opacity(0.32), interactive: true), in: Capsule())` + `C.limeDeep.opacity(0.28)` 1px 描边 + 顶部白色高光；offset = `itemWidth × selectedIndex`，外层 `.animation(.spring(response: 0.46, dampingFraction: 0.72), value: selected)`；旧系统为 `limeSoft` 实心胶囊同样滑动 |
| 选中态 | 选中文字/图标 `C.ink` + `semibold` + `symbolEffect(.bounce, value: selected == tab)`；未选中 `C.ink.opacity(0.68)`（解决上轮 `.secondary` vibrancy 对比度问题） |
| 无障碍 | `.accessibilityLabel` / `.accessibilityIdentifier("tab_…")` / `.accessibilityAddTraits(.isSelected)` 保留 |
| 玻璃回退 | 旧系统/旧 Xcode：`.liquidGlassSurface` 的 `legacySurface`（material + 描边 + 阴影）与 `legacySelectionIndicator`（limeSoft 胶囊）；iOS 26 分支仍在 `#if compiler(>=6.2)` + `#available(iOS 26.0, *)` 内 |
| 录屏参数 | `-uiTestAutoCycle <秒>`（Debug only）：1.2s 后循环 `AppTab.allCases`，`withAnimation(.spring(...))` + `Task.sleep`，`onDisappear` cancel |

### 13.2 最终 IPA 独立核验（PASS）

| 项 | 结果 |
| --- | --- |
| 文件 / 大小 | `dist/BeanBook-1.0-unsigned.ipa`，973,942 B（952 KB） |
| SHA256 | `039d98d229afedf2e8691b2863519b37718ac322ea067eff757a2f539c6a8b38` **与 `.sha256` 完全一致** ✓ |
| 结构 | zip 内 8 项：`Payload/` + `BeanBook.app/{AppIcon60x60@2x.png, Assets.car, AppIcon76x76@2x~ipad.png, BeanBook, Info.plist, PkgInfo}` ✓ |
| 二进制 | Mach-O **arm64**、`LC_BUILD_VERSION platform 2`（iOS）、**minos 17.0**、sdk 27.2、**未签名**（`code object is not signed at all`，无 `_CodeSignature`）✓ |
| Info.plist | `CFBundleIdentifier=com.brewkin.beanbook.ios`、`CFBundleShortVersionString=1.0`、`MinimumOSVersion=17.0`、`DTSDKName=iphoneos27.2` ✓ |
| 内容一致性 | IPA 内 6 个 payload 文件 SHA256 与 `ios/build/Build/Products/Release-iphoneos/BeanBook.app` **逐字节相同** ✓ |
| Liquid Glass 编入 | Release 二进制含 6 个 Glass 相关 undefined symbols：`View.glassEffect(_:in:)`（F+QOMQ）、`Glass.interactive/tint/regular/Ma` —— 与重设计后只使用 `liquidGlassSurface` 封装一致（不再有 GlassEffectContainer/ID/Transition，符合新设计）✓ |
| Release 参数隔离 | `strings` Release 二进制中 `uiTestAutoCycle` 出现 **0 次**；Debug `BeanBook.debug.dylib` 中出现 **2 次** → Release 不含录屏循环参数 ✓ |

### 13.3 9 张新截图 + 滑动 GIF 核验（PASS）

- 9 张 PNG（`home/beans/maker/menu/stats/route-bean/route-recipe/route-data/route-newbean`）全部存在、可打开、RGBA、尺寸统一 **1398×2034**；`ios/artifacts/screenshots/` 与 `screenshots/ios/` 同名 PNG + `build-info.txt` **SHA256 全部一致**（build-info 时间 22:33:46，iPhone Duo / iOS 27.2）。
- 人工核对：新底栏为 **5 个等分入口的悬浮玻璃胶囊**（无中央大 FAB）；`home` 滑块在「首页」、`maker` 在「调一杯」、`stats` 在「统计」，选中项 ink+semibold、未选中文字明显加深；玻璃条下内容可透过，五页与四个详情页布局正常、无错位。
- **像素级几何测量**（以 `maker.png` 为例，1398px 宽 @3x）：
  - 五个入口标签/图标中心 x ≈ **147 / 357.5 / 571 / 783 / 994 px**，步长 ≈ **211.8 px**（= itemWidth ≈ 70.6pt，与 safe-area 内宽一致）；
  - 青柠滑块 bbox：宽 **189 px（≈63pt = itemWidth−8pt）**、高 **139 px（≈46pt = barHeight−22pt）**，与代码尺寸完全吻合；
  - 滑块中心 vs 选中 tab 中心：home **147.5 vs 147**、maker **572.5 vs 571**、menu **785 vs 783**（偏差 ≤2px，居中正确；stats 因图表青柠柱透过玻璃导致颜色分割受干扰，但人工确认滑块在「统计」位置）。
- **滑动动画 GIF**：`screenshots/ios/nav-slide.gif`，760×143，**8 帧**（首帧 600ms + 7×100ms，共 1.3s）。逐帧青柠滑块质心 x：`52 → 127 → 178 → 199 → 196 → 195 → 195` → 前 3 帧为**滑动中间态**，随后稳定到目标位置；人工查看第 2 帧可见滑块处于两 tab 之间（弹簧滑动过程），证明动画真实存在。
- **端到端复跑**：QA 用交付脚本独立重跑 `run-simulator-screenshots.sh --skip-build --sim "iPhone Duo" --app ios/build/.../Debug-iphonesimulator/BeanBook.app --out /tmp/qa-r6-shots --routes "bean recipe data newbean"` → exit 0，9 张截图与交付版 **SHA256 全部逐字节相同**（含预热后无空白），说明截图产物可复现。
- 说明：`nav-slide.gif` 当前仅位于 `screenshots/ios/`，`ios/artifacts/screenshots/` 中只有 9 张 PNG + build-info（未同步 gif）。若希望 CI artifacts 也归档动画，可把 gif 一并复制进 artifacts 目录（不影响交付）。

### 13.4 `-uiTestAutoCycle` 代码复核（Debug-only，PASS）

- `AppTab.launchArgumentAutoCycleInterval`：`#if DEBUG` 内解析 `-uiTestAutoCycle` 参数（必须 >0），Release 返回 nil且字符串不进入二进制（13.2 已用 strings 验证）。
- `startAutoCycleIfNeeded()`：`onAppear` 启动，`Task { @MainActor in ... }` 先 sleep 1.2s，然后循环 `AppTab.allCases`，用 `withAnimation(.spring(...))` 改 `tab`，每次 `Task.sleep(interval)`；`onDisappear` cancel 并置 nil；无强引用循环/泄漏风险。
- 该参数用于录屏/动画验证，不影响正常用户路径；Debug 二进制保留、Release 剔除，符合预期。

### 13.5 Lead 修改的 glass-typecheck harness 复核（合理，建议可选升级）

Lead 把 `check 2` 的 BottomBar 检查从「简化 stub」改为「真实 Theme.swift Liquid Glass 段（liquidGlassStyle / LiquidGlassSurface / BottomActionBar）+ haptic stub + RootView BottomBar 原文」。QA 复核结论：**改动合理，且比原 stub 更贴近真实**——

- 现在 typecheck 的是 App 内实际使用的 `.liquidGlassSurface` 实现，而不是等价桩，避免「桩通过、真代码不通过」的盲区；
- `haptic` 在 iOS 用 UIKit，macOS typecheck 用 `HapticStub` 替代，边界清晰；
- 已独立复跑：`PASS 6 / FAIL 0`、`SELFTEST_OK (5/5)`、`GATING_OK occurrences=4`（Theme 3 + RootView 1，与重写后代码一致）、`NO_LEAK` —— 全部通过。
- **额外证据（本轮新环境）**：本机现已安装 Xcode 27.2，QA 又用**真实 iOS SDK**（iPhoneSimulator27.2.sdk）对同样抽取的 `Theme` Liquid Glass 段与 `BottomBar` 做 typecheck：`-target arm64-apple-ios17.0-simulator` 均 **exit 0**（0 error/0 warning）→ 部署目标 iOS 17 下 `#available` 分支与 `symbolEffect` 等 API 的真实 iOS 编译语义也通过了。
- 可选小改进（不影响当前 PASS）：① 现在 Xcode 已安装，harness 可自动优先用 iOS SDK（`-target arm64-apple-ios17.0-simulator -sdk "$(xcrun --sdk iphonesimulator --show-sdk-path)"`）替代 macOS 26 近似；② 脚本头部 `xcrun --show-sdk-version` 在装 Xcode 后未带 `--sdk macosx`，输出为空（仅日志 cosmetic）；③ harness 依赖 Theme.swift 的 `// MARK: - Liquid Glass` 锚点与 haptic stub 边界，若后续再移动该段需同步更新。

### 13.6 静态回归（PASS）

| 检查 | 结果 |
| --- | --- |
| `swiftc -parse` 17 个 .swift | ✅ 17/17，0 失败（RootView 最终版 `caaab182…`） |
| `run-tests.sh` | ✅ PASS 211 / FAIL 0 / exit 0 |
| `project-check.sh` | ✅ PASS 24 / FAIL 0 |
| `check-glass-api.sh`（Lead 更新版） | ✅ PASS 6 / FAIL 0；SELFTEST 5/5；GATING 4；NO_LEAK |
| iOS-target 额外 typecheck（QA 补充） | ✅ 真实 iOS 27.2 SDK + deployment iOS 17：Theme 玻璃段 & BottomBar harness 均 exit 0 |

### 13.7 设计/实现层面的 QA 观察（Info，不阻塞）

1. **多处玻璃未使用 `GlassEffectContainer`**：导航条（`.liquidGlassSurface`）与选中滑块（`.glassEffect`）是两个独立玻璃层。当前截图观感正常，但 Apple 对相邻多个玻璃效果推荐放入同一 `GlassEffectContainer`（便于融合与性能）；若后续想让滑块与底栏玻璃「融在一起」或担心双层实时模糊开销，可评估加入容器（非必须）。
2. **滑块 `interactive: true` 的触感可能不触发**：ZStack 中按钮在滑块之上，hit-test 命中按钮，滑块的 interactive 玻璃反馈可能不会触发；若希望点击有玻璃触感，可把 interactive 玻璃放在按钮背景层（Info）。
3. **GIF 归档位置**：`nav-slide.gif` 仅在 `screenshots/ios/`，未同步 `ios/artifacts/screenshots/`；若 CI 需要动画 artifact 可补一份（非阻塞）。
4. 上一轮 N4（真机辅助功能/帧率）与 N5（iOS 17–25 回退视觉）仍为 Info，未在本轮变化；新导航的旧系统回退（material + limeSoft 滑块）仅静态/typecheck 验证，未在旧 runtime 实机跑。

### 13.8 最终产物 SHA256（Round 6 终版，2026-11-06 22:38 CST）

```
# 最终未签名 IPA
973,942 B
SHA256 = 039d98d229afedf2e8691b2863519b37718ac322ea067eff757a2f539c6a8b38
（与 dist/BeanBook-1.0-unsigned.ipa.sha256 一致）

# 9 张新截图（ios/artifacts/screenshots/，与 screenshots/ios/ 同份）
eb84c486e7dc3785145f18ade977cf3e39264b9df29636504ba803cfcd1b8d1f  beans.png
d2d00af93c680433cc11372115bb884fbf1430eb302c9a85b99fc85c287e0c7b  home.png
cdbfa428888f8c0c32b73f3d19916f3c35a6cbeae805469076f37038a390bdbf  maker.png
c8b7cd8563ba5b72cb9d6fbb005ce7a8e39cb41381f4c24f9592d2e2cd0a8f15  menu.png
84bf81b22b15a2c40708595352a0bbf0ab96cb0dd45dd313f7392de35d911d9a  route-bean.png
2e163ac0f9e4e995d2ee9d208a9c439a067398dfb5a001a2572c73cbbccfe3d1  route-data.png
66fec6338bae4e4652198142de7543fca7e6554067734f4b977cdc21430133b9  route-newbean.png
0c8e0edefcc91c665b84d75f57fc31564db96652e50ab26078ead011703ba03f  route-recipe.png
de03afda885283b5fe5bed0cb4ae9bef6d03533880e7f406c1f0b2692058329b  stats.png
799a3cf1bcfb068a27cfd5dde1d7322de8a3d73ae704502ab225ef64f08e148d  build-info.txt
（另：screenshots/ios/nav-slide.gif = f83b3bf49164d0092e6376e1cf6683e589406e0f4dff281ec2d3b049dda9a463）

# 源码/脚本关键 hash
caaab182df4b1c62e9720b07b1ae7f169b4c33e5fdfc0cacb423840e333bb14b  ios/BeanBook/RootView.swift
ded9f72308a31dca2f81788d0036ad9a232abaa81002e2e9dbe150f8c2c411d8  ios/BeanBook/Store.swift
214ed3402a5d68f2a6bd546db7cc1715d043cd3e027d888789592a6f174264fa  ios/BeanBook/Theme.swift
dcae7cedc9071d9710bcd967b9381e06a7395b43473ccdb30a7d1d25d00c2e94  tools/model-tests/glass-typecheck/check-glass-api.sh
30fef4ac89ca341ebd9b02ceda9b4d196f739726b1770abbb4d8af3f43bb2161  ios/scripts/run-simulator-screenshots.sh
ac299d6231d1aa01a43d6beb2c91472088d5ce30f01fee0be381d9d3c4633b58  ios/scripts/package-ipa.sh
```

### 13.9 Round 6 结论

- **0 FAIL、0 Blocker、0 Major**（Info 3 条：`GlassEffectContainer` 容器化建议、滑块 interactive 触感、GIF 归档位置；另有既有 N4/N5 Info）。
- 新底部导航满足需求：5 等分入口悬浮玻璃胶囊、点击滑块弹簧滑动（GIF 逐帧证明中间态）、选中/未选中层级清晰、渐进回退 material/limeSoft；静态、iOS SDK typecheck、模拟器实测、截图与 IPA 全部独立核验通过。
- 最终 IPA（`039d98d2…`，952 KB，arm64 / iOS / minos 17.0 / 未签名）、9 张新截图 + `nav-slide.gif`、源码与脚本已固定 SHA；QA 全流程（Round 1–6）结束，可以交付。

---

## 14. 最终版：系统原生 TabView 核验（Round 7，2026-11-06 22:55–23:00 CST）

> 最终变更：按用户要求，底部导航**不再自绘**，`RootView.swift` 整体重写为系统原生 `TabView(selection:)` + 5 个 `.tabItem`，由 iOS 26/27 系统提供标准 Liquid Glass Tab Bar 与系统原生选中滑块动画；每个 Tab 独立 `NavigationStack`，详情页 `.toolbar(.hidden, for: .tabBar)` 隐藏系统 Tab Bar 并保留悬浮玻璃 `BottomActionBar`。QA 对本轮最终代码与产物做独立复核（只更新本报告，未改 `ios/` 源码、`dist/` 最终 IPA、`screenshots/ios/`）。

### 14.1 本轮变更摘要

| 文件 | 变更 |
| --- | --- |
| `RootView.swift`（48d46a09…） | 删除自绘 `BottomBar`/`SideRail`/自绘滑块/`@Namespace`/`GlassEffectContainer`；改为 `TabView(selection: $tab)` + 5 × `.tabItem { Label }` + `.tag(tab)`；`paths: [AppTab: [Route]]` 每 Tab 独立 `NavigationStack`；`navigationDestination` 上 `.toolbar(.hidden, for: .tabBar)` 隐藏系统 Tab Bar；Debug 参数 `-uiTestTab/-uiTestRoute/-uiTestAutoCycle` 保留；`tabViewContent` 上 `.tint(C.ink)` / PaperBackground |
| `Theme.swift`（0598030e…） | Liquid Glass 段（liquidGlassStyle/LiquidGlassSurface/BottomActionBar）不变；`AdaptivePage` 底部留白 120 → 24（配合系统 Tab Bar 安全区） |
| `BeanDetailView/BeanEditorView/RecipeDetailView` | 内容底部留白 120/118/124 → 24；底部仍为 `safeAreaInset { BottomActionBar { … } }` 悬浮玻璃操作条 |
| `tools/model-tests/glass-typecheck/check-glass-api.sh` | check 2 由 typecheck 自绘 BottomBar 改为「断言 RootView 使用系统原生 TabView 且无自绘 BottomBar」；GATING 变为 3 |

### 14.2 最终 IPA 核验（PASS）

| 项 | 结果 |
| --- | --- |
| 文件 / 大小 | `dist/BeanBook-1.0-unsigned.ipa`，955,184 B（936 KB） |
| SHA256 | `0c43aac8f67d36a4ccef5ec6c8acbec54bcc92946dcf57d75373d7bd23162d64` **与 `.sha256` 完全一致** ✓ |
| 结构 | zip 内 8 项：`Payload/` + `BeanBook.app/{AppIcon60x60@2x.png, Assets.car, AppIcon76x76@2x~ipad.png, BeanBook, Info.plist, PkgInfo}` ✓ |
| 二进制 | Mach-O **arm64**、`LC_BUILD_VERSION platform 2`（iOS）、**minos 17.0**、sdk 27.2、**未签名**（`code object is not signed at all`，无 `_CodeSignature`）✓ |
| Info.plist | `CFBundleIdentifier=com.brewkin.beanbook.ios`、`CFBundleShortVersionString=1.0`、`MinimumOSVersion=17.0`、`DTSDKName=iphoneos27.2` ✓ |
| 内容一致性 | IPA 内 6 个 payload 文件 SHA256 与 `ios/build/Build/Products/Release-iphoneos/BeanBook.app` **逐字节相同** ✓ |
| Glass 符号 | Release 二进制 6 个（`View.glassEffect(_:in:)` F+QOMQ、`Glass.interactive/tint/regular/Ma`）——全部来自自研 `liquidGlassSurface`/`liquidGlassStyle` 封装；系统 Tab Bar/选中滑块由系统 SwiftUI 内部实现，不产生 App 侧符号 ✓ |
| Release 参数隔离 | `uiTestTab / uiTestRoute / uiTestAutoCycle` 在 Release 二进制中均为 **0** 次；Debug `BeanBook.debug.dylib` 中均为 **2** 次 ✓ |
| 独立重建 | `DERIVED_DATA=/tmp/qa-r7-dd bash ios/scripts/build-device-unsigned.sh` → ✅ BUILD SUCCEEDED（16s，1 条无害 appintents 警告，0 error）；产物 arm64 / minos 17.0 / 未签名；Info/Assets/图标与 Lead 产物逐字节相同，主二进制仅 `LC_UUID` 差异；其打包 IPA 955,185 B（SHA `85e2d51e…`，结构合法） |

### 14.3 截图与脚本产物核验（PASS）

- 9 张新 PNG（home/beans/maker/menu/stats/route-bean/route-recipe/route-data/route-newbean）全部存在、可打开、RGBA、尺寸统一 **1398×2034**；`ios/artifacts/screenshots/` 与 `screenshots/ios/` 的 PNG + `build-info.txt` **SHA256 全部一致**（build-info 时间 22:55:46，iPhone Duo / iOS 27.2）。
- 人工逐页核对（本机折叠屏模拟器）：系统原生 `TabView` 在 **regular 宽度下呈现为右侧系统侧栏**（5 个系统图标 + 选中 pill），`-uiTestTab` 选中的入口全部正确——home→①、beans→②、maker→③、menu→④、stats→⑤；内容布局无错位。
- 详情页：`-uiTestRoute` 打开豆子详情后 **系统侧栏/Tab Bar 已隐藏**（`.toolbar(.hidden, for: .tabBar)` 生效），底部保留悬浮圆角玻璃 `BottomActionBar`（编辑/调一杯）；`route-bean` 等 4 张详情截图与上一轮 **SHA256 完全相同**，说明详情页 UI 未受本轮导航重写影响。
- **端到端复跑**：QA 用交付脚本独立重跑 9 张（含预热）→ exit 0，9 张与交付版 **SHA256 全部逐字节相同**，截图产物可复现。
- 说明：上一轮的 `screenshots/ios/nav-slide.gif`（自绘滑块录屏）已随自绘导航删除而移除，当前两个截图目录均无 gif；主 README 与 `docs/DELIVERY-REPORT.md` 已更新为「系统原生 TabView」描述。

### 14.4 关键限制：iPhone 底部形态未能在本机截图实测（Info）

- 本机安装的 iOS 27.2 模拟器 runtime 是**设备专属**（`supportedDeviceTypes = 1`，仅支持 iPhone Duo 折叠屏）；QA 尝试 `xcrun simctl create "iPhone 17" com.apple.CoreSimulator.SimDeviceType.iPhone-17 <runtime>` → `SimError 403 Incompatible device`。
- 因此本机截图只能看到折叠屏的**系统侧栏形态**；常规 iPhone 上同一原生 `TabView` 会由系统渲染为**底部 Liquid Glass Tab Bar + 系统原生大玻璃选中滑块**（Apple Music/News 一致的系统控件，App 代码不参与绘制）。这与 Lead/README 的说明一致，作为已知限制记录（非代码问题）。

### 14.5 静态四件套 + 工具改动复核（PASS）

| 检查 | 结果 |
| --- | --- |
| `swiftc -parse` 17 个 .swift | ✅ 17/17，0 失败（RootView `48d46a09…`） |
| `run-tests.sh` | ✅ PASS 211 / FAIL 0 / exit 0 |
| `project-check.sh` | ✅ PASS 24 / FAIL 0 |
| `check-glass-api.sh`（本轮更新版） | ✅ PASS 6 / FAIL 0；SELFTEST 5/5；`GATING_OK occurrences=3`；NO_LEAK |

**对 Lead 修改的 check 2 的复核意见（合理，建议可选加固）**：
- 改动把「自绘 BottomBar 的 typecheck」换成了对 RootView 的 grep 断言（含 `TabView(selection:`、`.tabItem`、且不存在 `private struct BottomBar: View`）。对本次「改用系统原生控件」的目标是**合理且直接**的，GATING 3 = Theme 的 3 处 iOS 26 符号（`liquidGlassStyle` 声明 2 行 + `glassEffect` 调用 1 行），与重写后 RootView 无直接 iOS 26 API 的现状一致。
- 可选的加固（非阻塞）：① grep 是浅层断言，建议再加 `\|\.tabItem` 出现次数 == 5、`.tag(tab)` / `TabView(selection: $tab)` 选择绑定等断言，防止「部分迁移」误 PASS；② 脚本头部仍写着「本机只有 CLT（无 Xcode / 无 iOS SDK）」，现已安装 Xcode 27.2，文案过时；③ 现在可用真实 iOS SDK 做等价 typecheck——QA 补充验证：用 `-target arm64-apple-ios17.0-simulator -sdk iPhoneSimulator27.2.sdk` 对 Theme Liquid Glass 段与 `BottomActionBar` 声明+用法 typecheck，均 **exit 0**，建议后续脚本优先走 iOS SDK（macOS 26 作为无 Xcode 时的回退）。

### 14.6 其他观察（Info，不阻塞）

1. **README 文档残留**：`ios/README-IOS.md` 第 175–178 行仍保留上一轮「`-uiTestAutoCycle` + 录屏 + 逐帧检查 pill 中间位置」的旧流程，并引用已删除的 `screenshots/ios/nav-slide.gif`；建议改为说明「系统原生 TabView，系统自带选中动画，无需自绘滑块验证」。
2. **行尾混用**：本轮编辑过的 5 个 Swift 文件（RootView/Theme/3 个详情页）变为 LF，其余 11 个仍 CRLF（共 6 LF / 11 CRLF）；`swiftc`/Xcode 均正常，建议后续统一。
3. **RootView 未使用属性**：`@Environment(\.horizontalSizeClass) private var horizontalSizeClass` 已无引用（编译器不告警），可清理。
4. 既有 N4（真机辅助功能/帧率）、N5（iOS 17–25 回退视觉未实测）仍为 Info；本机无旧 runtime，本轮未变化。

### 14.7 最终产物 SHA256（Round 7 终版，2026-11-06 23:00 CST）

```
# 最终未签名 IPA
955,184 B
SHA256 = 0c43aac8f67d36a4ccef5ec6c8acbec54bcc92946dcf57d75373d7bd23162d64
（与 dist/BeanBook-1.0-unsigned.ipa.sha256 一致）

# 9 张新截图（ios/artifacts/screenshots/，与 screenshots/ios/ 同份）
293c34e89b75b98669f7de15f0e90937ae08793444cdc2cd93d8176d723e6304  beans.png
d97bc164d6a91dcf8341fd8c1101ee7715a8a373b19b12d22a3c8f0cfd0e81bd  home.png
56cef75da3cbda7ca06fb230e995e462d40923f8b73e55d013c443c347aff063  maker.png
898dc1df497a281d01febee29d4baacb555359ad1bd47fe23b6315a4900799b5  menu.png
84bf81b22b15a2c40708595352a0bbf0ab96cb0dd45dd313f7392de35d911d9a  route-bean.png
2e163ac0f9e4e995d2ee9d208a9c439a067398dfb5a001a2572c73cbbccfe3d1  route-data.png
66fec6338bae4e4652198142de7543fca7e6554067734f4b977cdc21430133b9  route-newbean.png
0c8e0edefcc91c665b84d75f57fc31564db96652e50ab26078ead011703ba03f  route-recipe.png
67a9ccb8d0ad51b0f01031a8f69d27a90374e581a83da6096e84ac32c63999cd  stats.png
713acf710cd9893c2529d33ff8fba83304da7e76443d586908379c6a809ce6c0  build-info.txt

# 源码（仅列本轮变化；其余见 13.8）
48d46a09a2bf4a5c569d079b7a98d1229a5193cf4805d9d4347820bc28562c00  ios/BeanBook/RootView.swift
0598030e65e9fcfdf319e0c67e5806e1da41841a300261c761ae153fba617d85  ios/BeanBook/Theme.swift
bc205c5e44f9565b2620ae6dd7040d25a57ff41b0a34806b7a1130fa50cea276  ios/BeanBook/BeanDetailView.swift
fca0909a8911a9349efaa4be77afc429dbfdc04c72157aa08edb5108005420c1  ios/BeanBook/BeanEditorView.swift
732da591654f5a93ab6b39d72431abffd494765d21741d10fb0811b0491906fe  ios/BeanBook/RecipeDetailView.swift

1820c1ecd44e0d8ff9029bbf0f9e96db64fc8f4004db48554efd4ce6e90baab4  tools/model-tests/glass-typecheck/check-glass-api.sh
30fef4ac89ca341ebd9b02ceda9b4d196f739726b1770abbb4d8af3f43bb2161  ios/scripts/run-simulator-screenshots.sh
ac299d6231d1aa01a43d6beb2c91472088d5ce30f01fee0be381d9d3c4633b58  ios/scripts/package-ipa.sh
b241780a2ffb70350e5d6e13d79e55825990c2aeecf4ca3367bcb02f386a98ef  ios/BeanBook/Info.plist
```

### 14.8 Round 7 结论

- **0 FAIL、0 Blocker、0 Major**；Info 5 条（iPhone 底部形态本机不可实测、glass 脚本可加固/文案过时、README 残留旧滑块 GIF 说明、行尾混用、未使用属性）。
- 底部导航已按要求改为**系统原生 `TabView`**：iOS 26/27 上由系统提供标准 Liquid Glass Tab Bar + 系统原生选中玻璃滑块动画，不再有自绘导航/滑块；折叠屏模拟器实测为系统侧栏形态、五个入口选中正确；详情页隐藏系统 Tab Bar 并保留悬浮玻璃 `BottomActionBar`；9 张截图可复现、最终 IPA SHA/结构/arm64/minos 17.0/未签名全部核验通过；静态四件套全绿。
- QA 全流程（Round 1–7）结束，可以交付。

---

## 15. iPhone 17 最终截图 + M10-1/Maker 修复核验（Round 8，2026-11-06 23:17–23:22 CST）

> 本轮为最终交付版：安装 iOS 27.2 通用模拟器运行时并创建 iPhone 17，9 张截图全部重拍自 **iPhone 17（1206×2622）**，系统原生底部 Liquid Glass Tab Bar 直接可见；修复 M10-1 导航归属 Bug 与 MakerView 窄屏布局；重建最终 IPA。QA 独立复核结论如下（只更新本报告，未改 `ios/` 源码、`dist/` 最终 IPA）。

### 15.1 本轮变更摘要

| 文件 | 变更 |
| --- | --- |
| `RootView.swift`（`4400762d…`） | **M10-1 修复**：`destination(_ route:, in owner:)` 增加 owner tab 参数；`navigationDestination` 传 `destination(route, in: tab)`（`tabRoot` 参数即所属 Tab）；`onEdit`/`onOpenRecipe`（豆子详情内）与 `onOpenBean`（配方详情内）均 push 到 **owner** 栈；Debug `-uiTestRoute` 也压入当前选中 tab |
| `MakerView.swift`（`3c379ecd…`） | 窄屏布局修复：杯区 `.aspectRatio(0.64, contentMode: .fit)` + `max 280×380`（杯背景圆改为 max 260 + aspectRatio(1)）；主区域左右 24pt、右侧面板 `isWide ? 200 : 128`；杯区额外左右 4pt；原料托盘左右 14pt 留边；移除旧自绘底栏遗留的底部 92pt 留白 |
| 其他 | Theme 未变（`0598030e…`）；`iOS 27.2` 通用运行时 + iPhone 17 设备（UDID EE9792B5…）；截图/ GIF/最终 IPA 更新 |

### 15.2 最终 IPA 核验（PASS）

| 项 | 结果 |
| --- | --- |
| 文件 / 大小 | `dist/BeanBook-1.0-unsigned.ipa`，956,555 B（936 KB） |
| SHA256 | `335e3017a8891227fab01d29f7e1dbd56bf61f2bd95ae94791a394090e2f1962` **与 `.sha256` 完全一致** ✓ |
| 结构 | zip 内 8 项：`Payload/` + `BeanBook.app/{AppIcon60x60@2x.png, Assets.car, AppIcon76x76@2x~ipad.png, BeanBook, Info.plist, PkgInfo}` ✓ |
| 二进制 | Mach-O **arm64**、`LC_BUILD_VERSION platform 2`（iOS）、**minos 17.0**、sdk 27.2、**未签名**（`code object is not signed at all`，无 `_CodeSignature`）✓ |
| Info.plist | `CFBundleIdentifier=com.brewkin.beanbook.ios`、`CFBundleShortVersionString=1.0`、`MinimumOSVersion=17.0`、`DTSDKName=iphoneos27.2` ✓ |
| 内容一致性 | IPA 内 6 个 payload 文件 SHA256 与 `ios/build/Build/Products/Release-iphoneos/BeanBook.app` **逐字节相同** ✓ |
| 玻璃符号 | Release 二进制 6 个（`View.glassEffect(_:in:)` F+QOMQ、`Glass.interactive/tint/regular/Ma`，来自 BottomActionBar 封装；系统 Tab Bar 玻璃由系统实现）✓ |
| Release 参数隔离 | `uiTestTab / uiTestRoute / uiTestAutoCycle` Release 中均 **0** 次；Debug `BeanBook.debug.dylib` 中均 **2** 次 ✓ |
| 独立重建 | `DERIVED_DATA=/tmp/qa-r8-dd bash ios/scripts/build-device-unsigned.sh` → ✅ BUILD SUCCEEDED（15s、1 条无害 appintents 警告、0 error）；产物 arm64 / minos 17.0 / 未签名；Info/Assets/图标与 Lead 产物逐字节相同，主二进制仅 `LC_UUID` 差异；重打包 IPA 956,562 B（SHA `e5232394…`，结构合法） |

### 15.3 iPhone 17 截图 / GIF / 转场图核验（PASS）

- **9 张截图**全部为 **iPhone 17、1206×2622**、可打开；`ios/artifacts/screenshots/` 与 `screenshots/ios/` 的 9 张 PNG + `build-info.txt` **SHA256 全部一致**（build-info：iPhone 17 / iOS 27.2 / UDID EE9792B5… / 时间 23:17:54）。
- **系统原生底部 Liquid Glass Tab Bar 可见**：底栏为系统玻璃胶囊、圆角浮起、内容可透过；五个页面用 `-uiTestTab` 依次选中后，选中胶囊分别落在 ①首页 / ②豆子 / ③调一杯 / ④菜单 / ⑤统计（以 5 张底栏裁剪拼图人工核对，全部正确；系统原生玻璃滑块随页面切换）。
- **详情页**：`route-bean` 等 4 张详情页中系统 Tab Bar 已隐藏（`.toolbar(.hidden, for: .tabBar)` 生效）、底部保留 `BottomActionBar` 悬浮圆角玻璃操作条；四详情页渲染正常。
- **MakerView 窄屏修复**：`maker` 截图中杯子比例正常（修长但不再被拉成细长条）、右侧 IN THE CUP 面板收窄至 128pt、主区域左右留白 24pt、原料托盘左右 14pt 留边、底部不再有旧底栏遗留的 92pt 空白，整体与 iPhone 17 窄屏匹配、无裁切/重叠。
- **导航切换动画**：`nav-slide.gif` 720×187、**16 帧**（450ms + 30ms×12 + 120ms + 30ms + 420ms，总 1.38s）；相邻帧逐帧对比 **15/15 帧均有像素变化**（变化像素 46857→…→118），说明系统选中玻璃滑块动画被完整录制；`nav-slide-transition-sheet.png`（2080×612，16 格逐帧拼图，`ios/artifacts/screenshots/` 独有）人工可见滑块从「首页」滑向「豆子」的中间态。两处 GIF 文件 SHA256 一致（`ab22775a…`）。
- **端到端复跑**：QA 在 iPhone 17 上独立重跑截图脚本（`--sim "iPhone 17" --skip-build --app ios/build/.../Debug-iphonesimulator/BeanBook.app --out /tmp/qa-r8-shots --routes "bean recipe data newbean"`）→ exit 0，9 张全部生成；与交付截图逐像素比较 **0 个差异像素 >10/255（最大差 ≤3）**，视觉完全一致；PNG 文件字节大小有 ~100B 级差异（压缩/渲染舍入，非内容差异）→ 截图可复现。

### 15.4 M10-1（导航归属）修复复核（PASS）

- 代码走查：`tabRoot(_ tab:, path:, content:)` 的 `tab` 参数为**该 Tab 的 owner**；`.navigationDestination` 内 `destination(route, in: tab)` → `BeanDetailView(onEdit: { push(.editBean(id), in: owner) }, onOpenRecipe: { push(.recipe($0), in: owner) })`、`RecipeDetailView(onOpenBean: { push(.bean($0), in: owner) })`，即详情页内继续 push 的页面**始终归入当前所属 Tab 栈**；根视图的回调（Home → `.home`、Beans → `.beans`、Maker → `.maker`、Menu → `.menu`）也各自正确；Debug `-uiTestRoute` 改为 `push(..., in: tab)`（当前选中 Tab）✓。
- 复核结论：修复正确，消除了此前「从首页打开豆子详情再编辑 → 误压入豆子 Tab」的归属错误。
- Minor（Info，非阻塞）：`RecipeDetailView` 的 `onDelete` 里使用 `paths[tab]?.removeLast()`（当前选中 Tab）而非 `paths[owner]`；由于详情页显示时 `tab == owner`，实际等价，建议后续统一为 owner 以增强可读性。
- 说明：本机无 XCUITest target，详情→编辑→返回等**交互路径**无法自动化点击验证；已通过代码走查 + 四详情页截图 + 编译/静态检查覆盖。

### 15.5 MakerView 布局修复复核（PASS）

- Diff（相对 Round-1 基线）与 Lead 描述一致：主区域 `.padding(.horizontal, 24)` + `.padding(.top, 4)`；右侧面板 `isWide ? 200 : 128`；杯背景 `maxWidth/maxHeight 260` + `aspectRatio(1, .fit)`；`CupCanvasView` `.aspectRatio(0.64, contentMode: .fit)` + `.frame(maxWidth: 280, maxHeight: 380)`；杯区 `.padding(.horizontal, 4)`；控制条 `.padding(.horizontal, 24)`；原料托盘 `.padding(.horizontal, 14)`；删除 `.padding(.bottom, isWide ? 20 : 92)`。
- iPhone 17 截图人工核对：杯子比例正常、未被拉长；右侧面板/托盘留边符合设计；底部内容与系统 Tab Bar 无重叠、无旧留白。未发现新的裁切/遮挡问题。

### 15.6 静态四件套 + 可复现性（PASS）

| 检查 | 结果 |
| --- | --- |
| `swiftc -parse` 17 个 .swift | ✅ 17/17，0 失败 |
| `run-tests.sh` | ✅ PASS 211 / FAIL 0 / exit 0 |
| `project-check.sh` | ✅ PASS 24 / FAIL 0 |
| `check-glass-api.sh`（未变） | ✅ PASS 6 / FAIL 0；SELFTEST 5/5；GATING 3；NO_LEAK |

### 15.7 其他观察（Info，不阻塞）

1. 文档已同步：主 `README.md`、`ios/README-IOS.md`、`docs/DELIVERY-REPORT.md` 均已更新为 iPhone 17 / iOS 27.2 / 系统原生 Tab Bar / `nav-slide.gif` 说明（上一轮的 `nav-slide.gif` 引用已恢复有效）。
2. `nav-slide-transition-sheet.png` 仅在 `ios/artifacts/screenshots/`，`screenshots/ios/` 未同步（Lead 说明为中间帧原图，设计如此）。
3. 既有 Info 仍存在：行尾混用（部分文件 LF / 其余 CRLF）、RootView `horizontalSizeClass` 未使用；N4（真机辅助功能/帧率）、N5（iOS 17–25 回退视觉未实测）未变化。
4. QA 未发现新增 Blocker/Major；本轮所有产物均为最新构建，源码/截图/最终 IPA 在核验后未再变化。

### 15.8 最终产物 SHA256（Round 8 终版，2026-11-06 23:22 CST）

```
# 最终未签名 IPA
956,555 B
SHA256 = 335e3017a8891227fab01d29f7e1dbd56bf61f2bd95ae94791a394090e2f1962
（与 dist/BeanBook-1.0-unsigned.ipa.sha256 一致）

# iPhone 17 截图（ios/artifacts/screenshots/，与 screenshots/ios/ 同份；1206×2622）
a1b77ae4c34760ee36c3a500ef8ec29e9aefcbe0c76ac1edbe819289e6fd5a0e  beans.png
b9502ef34e73142ae07dd47b2b2a196b17b8770780023ffb2e9f06f7c3cd3bba  home.png
5f0a403974945f45be71f5405b40fc696efabe287e3c1bd072b493425bf7bef0  maker.png
5d7286239cb2f7e95ea83ae34ffc1fb61a3129c1122415a1c5bb9efd72693919  menu.png
2f1abd8beacba4d76c9ced8e0ab172c15f58ec0d2326836165ea13044dcd0774  route-bean.png
6d489a7e03a5a1ae64c4308f573d6a600c9300200d1b4f4336efd68bd1f292df  route-data.png
87fd4a3c36e219550dc4f39bbfb47bf94a542a0ac29c5c42063ef0af0cfd0bae  route-newbean.png
f7a4880245dfb53320f416a1c9e7404b5aa43bc9af15d393ef58a584790e9f6c  route-recipe.png
a0c177d4bcdf35d301a79d5fac49715f18d46e510add6c8c5d7ab1fb4387acc1  stats.png
1aff6664f44b41040c12f79a67bf0ca1cfc4c4bab7fdbe6f16aa37107731679f  build-info.txt

# 动画素材（两目录同份 + artifacts 独有转场图）
ab22775af53feff83ffef5633c3d378a560f10be2133df569518bcf131367b1f  nav-slide.gif
56866adf6c8d899ed757d53d37d9c545de23734c2d44820357d3a4d471424e1d  nav-slide-transition-sheet.png（仅 artifacts）

# 源码（本轮变化）
4400762d59a9e8e6672096af63319e5e6c18a5b897a1d416228858733ab8d784  ios/BeanBook/RootView.swift（M10-1 修复）
3c379ecd986ac71b36c633b705346aa65028ec7a2bb7ef7756aed0e391aa1c50  ios/BeanBook/MakerView.swift（窄屏布局）
0598030e65e9fcfdf319e0c67e5806e1da41841a300261c761ae153fba617d85  ios/BeanBook/Theme.swift（未变）
```

### 15.9 Round 8 结论

- **0 FAIL、0 Blocker、0 Major**；Info 4 条（`onDelete` 建议统一 owner、交互路径无 XCUITest、GIF 转场图仅 artifacts、既有行尾/未使用属性等 cosmetic）。
- **M10-1 修复正确**（详情页内后续 push 全部归属当前 Tab 栈；Debug 路由也压入当前 Tab）；**MakerView 窄屏布局修复正确**（杯子比例/面板宽度/留白/托盘边距均按设计，iPhone 17 实拍无裁切重叠）。
- **iPhone 17 最终截图 + 系统原生 Liquid Glass 底部 Tab Bar + 系统滑块动画**均已实测并留有证据（9 张截图、16 帧 GIF、16 格转场拼图）；最终 IPA（SHA `335e3017…`，arm64 / minos 17.0 / 未签名）SHA/结构/内容全部独立核验通过；静态四件套全绿；Release 无任何 `uiTest*` 字符串。
- QA 全流程（Round 1–8）结束，可以交付。

---

## 16. Round 10：双端 1.2 发行验收（v2 阶段核验；待 v3 最终素材复核 GIF 与发布包）

> 用户需求：① 菜单里的配方可修改（iOS + Android）；② Android 视觉向 iOS 1.2 对齐（悬浮玻璃 Tab Bar + 滑动玻璃滑块）；③ 版本 1.2 双端发行。
> 本轮为 1.2 v2 产物的独立验收。**验收过程中用户已将 Android 方向改为 v3「传统 Android 布局 + 澎湃 OS 4 风格」（task-9），iOS 同步缩小 Tab 图标（task-10）**；Lead 决定 v2 Android 的坏 GIF 不再修复，由 v3 重新生成截图/GIF 并重打 dist。因此本节记录 **v2 已通过项**与 **v2 素材问题**，GIF 颜色与新发布包留待 v3 增量复核（见 16.9）。

### 16.1 环境与发行产物

| 项 | 值 |
| --- | --- |
| Android | JDK 17（Temurin 17.0.21）、Android SDK 35（build-tools 34/35、platform-tools 35）、API 35 arm64 模拟器 `emulator-5554` |
| iOS | Xcode 27.2（27B52）/ iOS SDK 27.2 / Swift 6.4.2；iPhone 17 模拟器（UDID EE9792B5…，iOS 27.2） |
| APK | `dist/BeanBook-v1.2-arm64.apk` 与 `dist/忆杯手记-v1.2-arm64.apk`，31,088,104 B，SHA256 `fb0372cc8cf9e43695673f10b862781a65aef367ff77221585e09bde54526fab` |
| IPA | `dist/BeanBook-1.2-unsigned.ipa` 980,573 B，SHA256 `3df2eb2283d7d181c084acddc9ed521818aea0f72504274ba25f2f08c938e153`（`.sha256` 一致） |
| 源码包 | `dist/BeanBook-source-v1.2.zip` **4,762,575 B**，SHA256 `dd2d338f8ce23f75a63db36b02f53392c81579be94e5d27514d721824a1a2da0`（Lead 修复密钥泄漏/构建配置/体积后重建） |
| 校验清单 | `dist/SHA256.txt` 四项；QA 用 `awk` 转为标准格式后 `shasum -a 256 -c` **4/4 OK** |
| 历史归档 | `dist/archive/` 含 1.0/1.1 APK/IPA/源包与旧 SHA256.txt |

### 16.2 A. 双端「编辑配方」闭环代码路径核验（PASS）

**iOS（Store/RecipeDetailView/MakerView/RootView）**
- `Store`：新增 `@Published editingRecipeID`、`isEditingRecipe`、`editingRecipe`、`beginEditingRecipe`、`cancelEditingRecipe`、`updateRecipe`；`loadRecipeIntoDraft`（再调一杯）与删除/预览豆子会清理编辑态；`saveRecipe`（新建）逻辑保持不变。
- `RecipeDetailView`：顶部绿色铅笔 `onEdit` 入口（分享/更多旁），详情实时从 `store` 读取，保存后无需重进即可刷新。
- `MakerView`：编辑态横幅「正在修改配方 · 名称」+「取消编辑」+「保存后更新原配方…」；顶部按钮与 `SaveCupSheet` 标题/主按钮变「保存修改」；保存弹窗预填原配方字段；`save()` 在 `editingRecipe != nil` 时调用 `store.updateRecipe(id:…)`（**不新增记录**），否则 `saveRecipe`。
- `Store.updateRecipe`：`data.recipes` 中按 id 找到原记录后原地覆盖 name/beanId/beanName/layers/rating/notes/mouthfeel/sweetness/beanGrams/stirred，**保留 id/createdAt**；编辑保存**不重复扣豆**；完成后 `editingRecipeID = nil`、draft 重置。
- **取消**：`cancelEditingRecipe()` 只清编辑态并重置 draft，**不写库**；`RootView` 记录 `editingReturnTab/editingReturnRecipeID`，保存/取消后回到原 Tab 并恢复/更新详情栈。
- 数据层证据（`ios/artifacts/verify-1.2/VERIFY-REPORT.md`）：编辑保存前后配方数量 **3 → 3**、id 集合一致、被编辑配方 id/createdAt 不变、`Colombia Lychee` 余量 146g 不变；取消编辑前后模拟器沙盒 `data.json` **逐字节一致（cmp 通过）**。
- 截图：`ios/artifacts/verify-1.2/` 7 张（菜单 / 详情编辑入口 / 编辑态 / 保存弹窗预填 / 取消后菜单 / 保存后菜单 / 保存后详情），QA 逐张核对编辑入口、编辑横幅、保存修改按钮与保存后的总量/评分更新均正确。

**Android（MainViewModel / RecipeDetailScreen / MakerScreen / BeanBookApp）**
- `MainViewModel`：`_editingRecipe` StateFlow、`draftBeforeEditing` 保存进入编辑前草稿；`beginEditRecipe` 载入配方 layers 且不重复覆盖已保存的 pre-edit 草稿；`cancelEditRecipe` 恢复 `draftBeforeEditing` 并清空编辑态；`saveEditedRecipe` 用 `original.copy(name/beanId/beanName/layers/rating/notes/mouthfeel/sweetness/beanGrams/stirred)` **保留 id/createdAt**，调 `updateRecipe` 用同一 id 覆盖（`map` 替换，不新增），随后清空编辑态并回调；编辑保存同样**不重复扣豆**；`deleteRecipe`/预览豆子会清理编辑态。
- `RecipeDetailScreen`：底部操作条新增「编辑」→ `beginEditRecipe(recipe)` + 切到 maker tab；`MakerScreen` 编辑态标题/按钮/横幅与 iOS 对齐（「保存修改」/「正在修改配方 · 名称」/「取消编辑」），保存面板文案说明「不新增一杯」「不会重复扣豆」。
- 证据（`app/artifacts/verify-1.2/NOTES.md` + 截图）：编辑保存后菜单仍 **3 杯**（未新增）、平均分同步、详情评分 4.0→5.0；取消后草稿恢复为 20g/1 层（`10-cancel-restores-draft.png`）；`adb` 独立安装最终 APK 后冷启动、编辑相关页面均无 FATAL/ANR（详见 16.3）。

> 结论：双端「编辑入口 → 编辑态 → 保存覆盖原配方（不新增）→ 取消不丢数据」代码路径与验证材料 **PASS**（无 XCUITest/Compose UI test，属代码走查 + 数据对比 + 截图证据；详情页/编辑态均使用与真实按钮相同的保存代码路径）。

### 16.3 B. 发行包核验（PASS）

**Android APK**
- 大小/SHA256：31,088,104 B / `fb0372cc…`（中英文两个文件名内容完全相同，`.apk` 无附加 .sha256 文件，SHA 以 `dist/SHA256.txt` 为准）；`app/build/outputs/apk/release/app-release.apk` 独立重建产物 SHA **同为 `fb0372cc…`**。
- `apksigner verify --verbose --print-certs`：**Verifies**，v2 方案通过（v1/v3 未启用，minSdk 26 下 v2 足够）；1 个 signer：`CN=BeanBook, OU=Coffee, O=BeanBook, L=Shanghai, ST=Shanghai, C=CN`，证书 SHA-256 `298dc0386dab1468e71feab3c33bb5c603000ff332ea020b0dce45334837078c`。
- `aapt2 dump badging`：`package=com.brewkin.beanbook`、`versionCode=3`、`versionName=1.2`、`minSdkVersion=26`、`targetSdkVersion=35`、`compileSdkVersion=35`、label=忆杯手记；`application-debuggable` 不存在（release 未开启 debug）。
- 结构：zip 134 项，含 `classes.dex`/`classes2.dex`、`lib/arm64-v8a/*`（onnxruntime 等，arm64 only，与文件名一致）、`assets/u2netp.onnx`、`resources.arsc`（`DebugProbesKt.bin` 为 kotlinx-coroutines 标准资源，非 debug 开关）。
- 独立安装/启动：`adb install -r` Success；`dumpsys package` 显示 versionCode=3/versionName=1.2；`am start -W` COLD 启动 665ms，`topResumedActivity=com.brewkin.beanbook/.MainActivity`，进程存活；清空 logcat 后完整操作/启动日志 **FATAL EXCEPTION=0、ANR=0、E/AndroidRuntime=0**（QA 在 `emulator-5554` 上独立复核，模拟器与 Lead 截图所用 AVD 不同但 APK 相同）。

**iOS IPA**
- 980,573 B / SHA256 `3df2eb22…`（与 `.sha256` 一致）；Payload 8 项结构合法。
- 二进制：arm64、`LC_BUILD_VERSION platform 2`（iOS）、minos 17.0、sdk 27.2、**未签名**（`code object is not signed at all`，无 `_CodeSignature`）；玻璃相关 undefined symbols 6 个。
- Info.plist：`CFBundleIdentifier=com.brewkin.beanbook.ios`、`CFBundleShortVersionString=1.2`、`CFBundleVersion=3`、`MinimumOSVersion=17.0`、`CFBundleDisplayName=忆杯手记`；pbxproj `MARKETING_VERSION=1.2`/`CURRENT_PROJECT_VERSION=3`（Debug/Release 两处）。
- Release 无调试字符串：`uiTestTab/uiTestRoute/uiTestAutoCycle/uiTestEditRecipe/uiTestEditShowSaveSheet/uiTestEditAutoSave/uiTestEditCancelAfter` 均为 **0** 次。
- 独立重建：Xcode 27.2 `build-device-unsigned.sh` → BUILD SUCCEEDED（18s、0 error、1 条无害 appintents 警告）；新构建 app 的 Info.plist/Assets.car/AppIcon 与 IPA payload **逐字节相同**，主二进制仅 LC_UUID 差异。

**源码包（Lead 修复后重建版）**
- 4,762,575 B / SHA256 `dd2d338f…`，非 `dist/SHA256.txt` 中旧的 26.9MB 包；**0 个敏感文件**：无 `keystore.properties`、`signing/`、`*.jks/*.keystore/*.p12/*.mobileprovision`、无密码文本。
- 105 个文件，含 `app/build.gradle.kts`、`app/proguard-rules.pro`、`.gitignore`、`.github/workflows/ios-unsigned.yml`、`gradlew`/`gradle-wrapper.jar`、iOS 工程/源码、docs、tools；**不含** `screenshots/`、`app/build`、`ios/build`、`dist`、`.gradle`、`node_modules` 等构建产物/本地目录。
- 完整性实测：解压到 `/tmp` 后 ① Android `./gradlew :app:assembleRelease --offline` → **BUILD SUCCESSFUL**（5s；因 zip 内不含签名材料，release 回退 Android Debug 证书，符合预期，不可用于正式发行）；② iOS `xcodebuild -project ios/BeanBook.xcodeproj -scheme BeanBook -configuration Release -sdk iphoneos …` → **BUILD SUCCEEDED**（27s，1 warning/0 error），产物 Info.plist 1.2/3；③ zip 内 `README.md`/`docs/RELEASE-1.2.md`/`docs/DELIVERY-REPORT.md`/`docs/qa/qa-report.md`/`ios/README-IOS.md` 与 workspace 当时版本 **SHA256 全同**。
- 历史安全提示：`dist/archive/BeanBook-source-v1.1.zip`（本地历史归档）仍含 `signing/beanbook-release.jks` 与 `keystore.properties`；如该 1.1 源包曾对外分发，应轮换发布 keystore 并重签 APK（Lead 将在交付说明提示；本机 dist 尚未外发）。

### 16.4 C. Android 1.2 玻璃视觉 / 截图 / GIF 核验（静态图 PASS；GIF 坏，v3 重制）

- **静态截图**（`app/artifacts/verify-1.2/` 14 张 PNG + GIF + NOTES.md；`screenshots/android-1.2/` 10 张主图 + GIF + VERIFY-NOTES.md，公共文件 SHA256 全同）人工核对：
  - `00-final-home.png` / `14-tab-selected-compare.png`：底部为**悬浮胶囊毛玻璃 Tab Bar**（透明、圆角、内容可透出），滑块为大号透明玻璃胶囊（含白色高光、边缘 rim、轻微色散）；两图选中态分别在「首页」/「调一杯」/「豆子」，位置正确移动 → **透明 + 磨砂 + 边缘折射/高光效果可见** ✅。
  - `04-recipe-detail.png` / `15-bean-detail-glass-bar.png`：详情页底部操作条为悬浮圆角玻璃条（分享/编辑/再调一杯、编辑/调一杯），透明高光可见 ✅。
  - 编辑流程静态图（05/06/07/08/09/10）核对：编辑态横幅/保存修改按钮/保存面板预填、「保存后仍 3 杯未新增（详情评分 5.0）」「取消后草稿恢复 20g/1 层」均符合预期 ✅。
- **GIF（v2）存在 MAJOR 质量问题**：`app/artifacts/verify-1.2/12-tab-slider-slowmo.gif` 与 `screenshots/android-1.2/12-tab-slider-slowmo.gif`（同 SHA `ff0e1e24…`，540×170、6 帧、140ms/帧、相邻帧差异均 >0）解码后画面呈**粉/青/淡紫霓虹色**（sips/QuickLook/PIL 三种解码结果一致；首帧简单平均 RGB≈230/228/226 正常，但玻璃条区域颜色严重错误），并非真实屏幕颜色；`README.md` 第 43–45 行直接嵌入该 GIF。已确认不是查看器问题，是 GIF 调色板/编码生成管线问题。
- 处理决定（Lead）：v2 GIF 不再修复，Android 方向改为 v3「传统布局 + 澎湃 OS 4 风格」，由 v3 重新录屏生成 GIF（Pillow RGB 白底合成 + 统一调色板 + 首/中帧自检）并替换 README 引用；故 **v2 GIF 问题不计入最终发行阻塞**，待 v3 素材回归（见 16.9）。
- 其他 API 35 行为：`13-stats-content-under-bar.png` 可见内容从悬浮 Bar 下方经过（overlay 方案生效）；`15-bean-detail-glass-bar.png` 验证详情底部玻璃条。

### 16.5 D. iOS 1.2 截图 / 验证材料核验（PASS，含文档 Info）

- `ios/artifacts/verify-1.2/`：7 张 PNG（1206×2622，iPhone 17 模拟器）+ `VERIFY-REPORT.md`（含改动文件、构建、数据层 data.json 前后对比、临时 IPA 校验、回归冒烟、库存口径与剩余风险），QA 逐张核对内容正确。
- `screenshots/ios/`：9 张主图已用 **1.2 Debug 重拍**（build-info 2026-11-07 14:27，iPhone 17 / iOS 27.2；Debug app Info.plist 确为 1.2/3），尺寸均为 1206×2622；其中 `home/beans/maker/menu/stats/route-*` 均为更新版。`nav-slide.gif` 仍是 11-06 录制（系统 TabView 动画，1.2 未重录，属 Info）。
- **Info 级不一致**：`ios/artifacts/screenshots/`（DELIVERY/README 称为“源文件”）目前仍是 **11-06 的 1.0 期图片与 build-info**，未同步 1.2 重拍结果；`ios/README-IOS.md` 仍有 5 处 1.0 IPA 文件名引用（第 96/207/209/302/303 行）；`docs/RELEASE-1.2.md` 写 Android“12 张截图”，实际 artifacts 为 14 PNG + GIF。Lead 已确认会在 v3 一并修正（见 16.9）。

### 16.6 E. 构建与静态校验结果

| 检查 | 结果 |
| --- | --- |
| iOS `swiftc -parse` 17 个 .swift | ✅ 17/17，0 失败 |
| iOS 独立 Debug/Release 构建 | ✅（Debug 构建由任务产物/截图佐证；Release `build-device-unsigned.sh` BUILD SUCCEEDED 18s、0 error、1 无害警告） |
| Android 独立 `./gradlew :app:assembleRelease` | ✅ BUILD SUCCESSFUL；产物 SHA 与 dist APK 相同（`fb0372cc…`） |
| 从 source zip 解压重建双端 | ✅ Android BUILD SUCCESSFUL（debug 签名回退，预期）；iOS BUILD SUCCEEDED（1.2/3） |
| `dist/SHA256.txt` 形式化校验 | ✅ `shasum -a 256 -c` 4/4 OK |
| iOS 数据层回归 `tools/model-tests/run-tests.sh` | ✅ PASS 211 / FAIL 0 / exit 0 |
| iOS glass API 审计 `check-glass-api.sh` | ✅ PASS 6 / FAIL 0（SELFTEST 5/5；GATING 3；NO_LEAK） |
| `project-check.sh` | ⚠️ **工具自身 bug**（Info，非工程问题）：脚本硬编码期望 `CFBundleShortVersionString=1.0/CFBundleVersion=1`，1.2 触发 fail 分支时 `fail "... $actual（期望 ...）"` 缺 `${actual}` 花括号导致 `unbound variable` 退出；工程本身 plutil/版本/Info.plist 键均手工复核 PASS。Lead 已确认将把断言更新为 1.2 并修该 bug，修好后 QA 复跑（见 16.9）。 |

### 16.7 F. 0 Blocker / Major 结论（v2 阶段）

- **App/代码层：0 Blocker / 0 Major**。双端编辑闭环代码路径与数据证据 PASS；iOS/Android 构建成功；发行 APK/IPA 的版本、签名/未签名、架构、部署目标、Info.plist、SHA256 全部核验通过；源码包两项严重问题（密钥泄漏、缺构建配置）**已修复并独立验证**（含从源码包解压重建双端）。
- **v2 Android 素材层：1 Major（GIF 颜色损坏）**，已定位为 GIF 编码/调色板问题、静态截图正常；因用户已改 Android 方向为 v3，该 GIF 不再修复，由 v3 重新生成 → **不作为最终发行阻塞**，但 v2 GIF 不能直接用于发布（README 已嵌入，需等 v3 替换）。
- **Info（待 Lead 处理/已确认将修）**：`ios/artifacts/screenshots` 旧图、`ios/README` 1.0 引用、RELEASE-1.2 截图数量、`project-check.sh` 版本断言/bug、`screenshots/ios/nav-slide.gif` 未重录、archive 1.1 源包含历史签名材料（若曾外发需轮换 keystore）。

### 16.8 关键 SHA256（v2 dist，2026-11-07 14:39 CST）

```
# dist/SHA256.txt 四项（shasum -a 256 -c 全部 OK）
fb0372cc8cf9e43695673f10b862781a65aef367ff77221585e09bde54526fab  BeanBook-v1.2-arm64.apk  (31088104 B)
fb0372cc8cf9e43695673f10b862781a65aef367ff77221585e09bde54526fab  忆杯手记-v1.2-arm64.apk  (31088104 B)
3df2eb2283d7d181c084acddc9ed521818aea0f72504274ba25f2f08c938e153  BeanBook-1.2-unsigned.ipa  (980573 B)
dd2d338f8ce23f75a63db36b02f53392c81579be94e5d27514d721824a1a2da0  BeanBook-source-v1.2.zip  (4762575 B)

# APK 签名证书 SHA-256
298dc0386dab1468e71feab3c33bb5c603000ff332ea020b0dce45334837078c   CN=BeanBook, OU=Coffee, O=BeanBook, L=Shanghai, ST=Shanghai, C=CN

# v2 Android GIF（有问题，v3 将替换）
ff0e1e24b7c1fa7b1fb0499445691f7edc8f7b36bbb02d5beae6d0b602db42b1  12-tab-slider-slowmo.gif（540×170，6 帧，140ms/帧）
```

### 16.9 待 v3 最终增量核验清单（Lead 已确认后续提供）

1) 新 Android GIF 颜色：第一帧/中间帧应为米白底 + 绿色高亮（不应再出现粉/青/霓虹色），并复核帧间差异 >0（真实滑动）；
2) 新 `dist` APK/IPA/源码包 SHA256 与 `dist/SHA256.txt`；APK 版本/签名（v3 传统导航版本号仍应为 1.2/3 或按 Lead 决定）、IPA 1.2/3 / arm64 / minos 17 / 未签名；
3) v3 传统导航 + 澎湃 OS 4 风格截图（贴底导航条 + 选中圆角高亮块）与 iOS Tab 图标缩小后的 9 张截图；
4) Lead 修好 `tools/model-tests/project-check.sh`（1.2 断言 + `$actual` bug）后 QA 复跑 17 文件 parse / model / project / glass 并出最终 0 Blocker/Major 结论；
5) 文档 Info 项修正确认（ios/artifacts/screenshots、ios/README 1.0 引用、RELEASE 截图数量、README GIF 替换）。

---

## 17. 最终定版复核（Android 澎湃 OS 4 导航 v5 + iOS Tab 图标缩小 + 最终 dist）

> 本轮为最终定版增量核验：Android 导航按澎湃 OS 4 参考重构为「悬浮暖白胶囊 + 4 tab + 右侧绿色 FAB + 同心圆角选中块 + 整块毛玻璃」；iOS Tab 图标缩小（系统原生 TabView 不变）；重建最终 APK/IPA/源码包。QA 只写 `docs/qa/`，未改任何代码与 dist。
> 结论：**App 与发行产物全部 PASS（0 Blocker / 0 Major）**；但**发行文档/源码包内容仍有一致性问题（1 个 Major，纯文档+source zip 重打，无需重打 APK/IPA）**，详见 §17.7，Lead 修复后需 5 分钟增量复核。

### 17.1 最终 dist 与被测版本

| 项 | 值 |
| --- | --- |
| Android APK | `dist/BeanBook-v1.2-arm64.apk` / `忆杯手记-v1.2-arm64.apk`，31,071,720 B，SHA256 `c74b9c2dfc36050d19a71856b17fa8e58f40dc30593dd255b14d666744e2b59d` |
| iOS IPA | `dist/BeanBook-1.2-unsigned.ipa`，980,354 B，SHA256 `95868d52a1518f7657dd0966760cb313cfef5ddc100ee66db0d8c52e10ef1cfd` |
| 源码包 | `dist/BeanBook-source-v1.2.zip`，6,425,270 B，SHA256 `2eb98830c3757460e6a0c1df85afe7062b5f492930815541a80eeafaeadbc3c9` |
| 校验清单 | `dist/SHA256.txt` 四项；`awk '{print $1"  "$2}'` 后 `shasum -a 256 -c` **4/4 OK** |
| 工程版本 | Android `versionCode=3`/`versionName=1.2`；iOS `CFBundleShortVersionString=1.2`/`CFBundleVersion=3`（pbxproj 两处 MARKETING_VERSION 1.2 / CURRENT_PROJECT_VERSION 3） |

### 17.2 发行包独立核验（PASS）

**Android APK**
- 独立 `shasum` 与 `.sha256` 清单一致；`app/build/outputs/apk/release/app-release.apk`（15:46 构建）SHA256 与 dist APK **完全相同**；`app/src` 下无任何文件晚于构建时间 → dist 为最终源码构建产物。
- `apksigner verify --verbose --print-certs`：Verifies，v2 方案通过，1 signer，证书 `CN=BeanBook, OU=Coffee, O=BeanBook, L=Shanghai, ST=Shanghai, C=CN`，证书 SHA-256 `298dc0386dab1468e71feab3c33bb5c603000ff332ea020b0dce45334837078c`。
- `aapt2 dump badging`：`com.brewkin.beanbook`、versionCode=3、versionName=1.2、minSdk=26、targetSdk=35；manifest 无 `debuggable`；`lib/arm64-v8a` 单 ABI。
- 独立 `adb install -r` Success；`am start -W` COLD 631ms；`dumpsys package` versionCode=3/versionName=1.2；完整操作日志 **FATAL=0 / ANR=0 / E/AndroidRuntime=0**，进程存活、App 前台。

**iOS IPA**
- Payload 8 项结构合法；二进制 **arm64、platform iOS、minos 17.0、sdk 27.2、未签名**（无 `_CodeSignature`）；Info.plist `1.2 / 3`、`MinimumOSVersion=17.0`、bundle id `com.brewkin.beanbook.ios`。
- **IPA 内 payload 与 `ios/build/.../Release-iphoneos/BeanBook.app`（14:44 构建）逐字节相同**（含 `BeanBook` 主二进制 SHA 相同），即 IPA 确由最终构建打包；IPA 时间 14:45，所有 iOS 源文件均早于该时间。
- Release 调试字符串：`uiTestTab/uiTestRoute/uiTestAutoCycle/uiTestEdit` 均 **0** 次。

### 17.3 Android 导航 v5（澎湃 OS 4）代码与视觉核验（PASS）

- 代码 `ui/components/HyperTabBar.kt`（15:46 最终版）与需求一致：
  - 外胶囊 `CapsuleHeight=62.dp` → `R=31dp`；选中高亮 `HighlightInset=4.dp`、高 `62-8=54dp`、圆角 `HighlightRadius=CapsuleRadius-HighlightInset=27dp` → 与外胶囊**严格同心**、端点不越界；
  - 胶囊底 `CapsuleFillAlpha=0.80f` 暖白半透明 + 4 个径向色斑整层 `Modifier.blur(22.dp)`（API<31 自动降级）+ 整块暖白磨砂雾 + `List(200)` 预生成噪点 + 1dp 白色高光边 + elevation 4dp 轻阴影；
  - 4 个 tab（首页/豆子/菜单/统计）+ 右侧独立 FAB 58dp、实心品牌绿 `#35D06A`、1dp 白色内高光、选中放大 1.06 + 柔光；选中高亮 `#E6E6E3` 半透明 + 1dp 浅色 rim + spring 滑动。
- 视觉证据：
  - `screenshots/android-1.2/00-home.png`：悬浮暖白胶囊 + 4 tab + 右侧绿色杯形 FAB，胶囊内可隐约透出背后「RECENT CUPS」内容，选中「首页」浅灰块；`04-maker-fab-selected.png` 验证 FAB 选中态放大。
  - `18-corner-alignment-closeup.png`（1244×844）：左右两端选中「首页」「统计」特写，高亮块与外胶囊圆弧同心、4dp 内缩、端点不越界。
  - `19-frost-glass-closeup.png`（2216×676）：胶囊整块毛玻璃特写，背景卡片文字/卡片边透过胶囊可见，1dp 顶亮边与颗粒可见。
- **GIF（重点复核项）PASS**：`screenshots/android-1.2/16-tab-switch.gif` 540×240、**45 帧**、1,469,631 B、SHA256 `0832a3d5f4f4becbae3ee19ca35ba40c35dfacda2cc6c330b75ab90fc6c1edb4`；逐帧 RGB 均值 ≈ (228,234,225)（米白偏暖，无霓虹色）；绿色 FAB 像素质心稳定在 x≈471–479（右侧 FAB 位置）；相邻帧差异 45 组均 >0（连续真实滑动）；抽帧拼图可见选中高亮块从「首页→豆子→菜单→统计」滑动。**上一轮 v2 GIF 的粉/青霓虹色问题已修复。**

### 17.4 iOS Tab 图标缩小核验（PASS）

- 代码：`AppTab.tabBarIcon` 使用 `UIImage.SymbolConfiguration(pointSize: 19, weight: .medium, scale: .medium)` 生成模板渲染 `Image`，`.tabItem { Label { Text(tab.label) } icon: { tab.tabBarIcon } }` —— 仍是系统原生 `TabView/UITabBar` 渲染，仅图片本身变小，文字/点击区域不变。
- 截图/动图：`screenshots/ios/` 9 张 1206×2622 已更新（build-info 2026-11-07 14:45/14:46，iPhone 17 / iOS 27.2），与 `ios/artifacts/screenshots/` 同名文件 **SHA256 全同**；人工核对首页系统 Tab Bar 图标明显小于上一版、文字不变；`nav-slide.gif` 已用新图标重录（720×187、13 帧、SHA256 `27c927a02ed87dea294b46793e31eddf4bffd896ab1930b2c8d433b0298447cc`）。

### 17.5 源码包解压重建（PASS）

- 108 个文件；**0 敏感文件**（无 keystore.properties/signing/*.jks/*.keystore/*.p12/*.mobileprovision/密码）；含 `app/build.gradle.kts`、`app/proguard-rules.pro`、`.gitignore`、`.github/workflows/ios-unsigned.yml`、gradle wrapper、iOS 工程、docs、tools；不含 screenshots/构建产物/dist。
- 解压后独立重建：Android `./gradlew :app:assembleRelease --offline` → **BUILD SUCCESSFUL（5s）**，产物 31,071,720 B（因源包不含签名材料，回退 Android Debug 证书属预期，不能用于正式发行）；iOS `xcodebuild ... -sdk iphoneos` → **BUILD SUCCEEDED（27s、1 warning/0 error）**，产物 Info.plist 1.2/3。
- **但源码包内文档不是最新版**（见 §17.7-③）：zip 中 `docs/RELEASE-1.2.md`/`docs/DELIVERY-REPORT.md` 仍是旧 SHA（`fb0372cc…`/`3df2eb22…`）与旧大小/旧磨砂描述，README 内 APK SHA 仍是中间值 `02d543bd…`；workspace 文档 15:51:35 更新后**没有重新打包 zip**。修好文档后需要重打 source zip（SHA 会变）并更新 `dist/SHA256.txt`。

### 17.6 构建/静态/工具复跑（PASS）

| 检查 | 结果 |
| --- | --- |
| Android 独立 `./gradlew :app:assembleRelease` | ✅ BUILD SUCCESSFUL；产物 SHA = dist APK `c74b9c2d…` |
| 源码包解压重建双端 | ✅ Android BUILD SUCCESSFUL / iOS BUILD SUCCEEDED |
| iOS `swiftc -parse` 17 个 .swift | ✅ 17/17 |
| `tools/model-tests/run-tests.sh` | ✅ PASS 211 / FAIL 0 |
| `tools/model-tests/glass-typecheck/check-glass-api.sh` | ✅ PASS 6 / FAIL 0（SELFTEST 5/5、GATING 3、NO_LEAK） |
| `tools/model-tests/project-check.sh`（Lead 已修版本断言+`$actual` bug） | ✅ **PASS 24 / FAIL 0**（含 `CFBundleShortVersionString=1.2`、`CFBundleVersion=3`） |

### 17.7 ❌ 未通过项：发行文档/源码包内容一致性（MAJOR，纯文档，需重打 source zip）

1. **README APK SHA 错误**：`README.md:9` 仍写 Android APK SHA256 `02d543bd…`（中间构建值），实际最终 APK 为 `c74b9c2d…`；大小 29.65 MiB 实为 31,071,720 B ≈ 29.63 MiB。
2. **RELEASE 发行表大小/截图引用未更新**：`docs/RELEASE-1.2.md:32-33` 大小仍为旧值 Android 31,088,104 B / iOS IPA 980,573 B（实际 31,071,720 / 980,354）；3.2 节仍描述 `app/artifacts/verify-1.2/` 的 12 张 + 旧 `12-tab-slider-slowmo.gif`（旧 v2、其中 GIF 颜色损坏），未改为最终 v5 的 `screenshots/android-1.2/`（13 PNG + `16-tab-switch.gif`）。
3. **源码包内文档是旧版**：`dist/BeanBook-source-v1.2.zip` 里的 RELEASE/DELIVERY 仍是 `fb0372cc…/3df2eb22…` 与旧大小、`blur(18–20dp)` 旧描述；README 的 APK SHA 也是 `02d543bd…`。修文档后必须**重新生成 source zip → 新 SHA**（APK/IPA 不用重打），并同步 `dist/SHA256.txt`。
4. **`screenshots/android-1.2/VERIFY-NOTES.md` 仍是 v4 记录**：写 `alpha 0.84 / blur 18dp / 140 噪点 / build SHA 02d543bd…`，与最终代码/APK（0.80 / blur22 / 200 噪点 / `c74b9c2d…`）不一致。
5. **截图混版**：`screenshots/android-1.2` 中 `00/01/02/03/04/16/18/19` 为 15:51（v5），但 `06/07/09/13/14/17` 仍是 15:01（早于 15:46 最终构建，疑似 v4 影像，README 正嵌入 06/07/09）；`app/artifacts/verify-1.2/` 仍是旧 v2 整套素材（RELEASE 仍引用）。
6. Minor：`HyperTabBar.kt` 注释仍称 “v4”（cosmetic）；README 的 29.65 MiB 建议改 29.63 MiB。

> 上述均为**文档/验证材料层面**问题，不改变 APK/IPA 二进制与 App 行为；修复方式：更新 README/RELEASE/DELIVERY/VERIFY-NOTES、重拍 06/07/09 或确认可接受、重打 source zip 并更新 SHA256.txt。

### 17.8 最终结论

- **App/发行产物：0 Blocker / 0 Major，PASS** —— 最终 APK（`c74b9c2d…`，签名 CN=BeanBook，安装启动 0 FATAL/0 ANR）、IPA（`95868d52…`，arm64/minos17/未签名，payload 与构建产物逐字节相同）、v5 Android 导航与 GIF（颜色正常、45 帧真实滑动）、iOS 图标缩小、源码包重建能力、构建与工具复跑全部通过。
- **发行材料：1 Major 待修** —— §17.7 的文档/源码包内容不一致（README APK SHA、RELEASE 大小与旧截图/GIF 引用、source zip 内旧文档、VERIFY-NOTES v4、部分截图混版）。修复 + 重打 source zip + 同步 `dist/SHA256.txt` 后，QA 将做最后一轮 5 分钟增量复核（新 zip SHA/文档、清单不变确认），届时可给最终 0 Major 交付结论。

### 17.9 最终增量（v10：更深灰滑块 + 重打 source zip，2026-11-07 16:06 冻结）

> 本节为 16:06 最终冻结状态的增量复核，**取代 §17.7/§17.8 的待修项**。用户最终要求：滑块颜色比上一版稍深（#E9E9E6 → #DEDED9），其余逻辑不动；文档/打包问题全部修复后重打 source zip。
> **结论：0 Blocker / 0 Major，可交付。**

**最终 dist（16:06，工作区已冻结）**

| 项 | 值 |
| --- | --- |
| Android APK | `dist/BeanBook-v1.2-arm64.apk` / `忆杯手记-v1.2-arm64.apk`，31,071,720 B，SHA256 `aab04f123b4fc2dc25a44ccce77a76a17a6277e36dad5d299059b2b5f6e3f533` |
| iOS IPA | `dist/BeanBook-1.2-unsigned.ipa`，980,354 B，SHA256 `95868d52a1518f7657dd0966760cb313cfef5ddc100ee66db0d8c52e10ef1cfd`（未变） |
| 源码包 | `dist/BeanBook-source-v1.2.zip`，6,429,380 B，SHA256 `1b0181ce8cda513d56787a90f76569465686694748927ba91cfd0258521f3ed9` |
| 清单 | `dist/SHA256.txt` 四项；`shasum -a 256 -c` **4/4 OK** |

**A. 发行包/构建（PASS）**
- APK：`apksigner` v2 通过，1 signer，`CN=BeanBook…`，证书 SHA-256 `298dc038…078c`；`versionCode=3`/`versionName=1.2`/minSdk 26/targetSdk 35/com.brewkin.beanbook；`app/build/outputs/.../app-release.apk` SHA 与 dist **完全相同**；`adb install -r` Success、冷启动 633ms、日志 **0 FATAL/0 ANR/0 AndroidRuntime**；`app/src`/`ios/BeanBook` 无文件晚于 dist APK（工作区冻结）。
- IPA：SHA/大小与上一轮一致，payload 与 `ios/build/.../Release-iphoneos/BeanBook.app` 逐字节相同（沿用 §17.2 证据），arm64/minos 17.0/未签名/Info 1.2/3 不变。

**B. 滑块/按压/宽度（PASS）**
- 代码最终版：`HyperHighlight = #DEDED9`（填充 alpha 0.92/0.84/0.74 + 顶部白高光 + 1dp 浅色 rim）；滑块高 `CapsuleHeight-2×4dp=54dp`、圆角 `31-4=27dp`、统一内缩 4dp 与外胶囊同心；tab/FAB `clickable(indication = null)` → **无水波纹/无整块灰底按压效果**。
- FAB 外层容器固定 `FabSize+16dp = 74dp`，选中放大 1.06/光环仅作用于内层绘制；按 1080px/2.625 density、Row 左右 16dp、间隔 12dp、FAB 容器 74dp 计算胶囊宽 ≈ **770.2px**（与 Lead 实测 769px 一致），布局不随 FAB 选中变化。
- 截图核验：`00-home/01-beans/02-menu/03-stats/04-maker-fab-selected` 与 `18/19` 特写中滑块为**更深浅灰玻璃片**（可见其下图标/文字，非灰色实心块），18 特写内外圆弧同心、端点不越界；04 与 00 胶囊宽度一致。
- GIF（重点复核）：`16-tab-switch.gif` 540×240、**25 帧**、816,684 B、SHA256 `d24ed54c80308e30face5e1c5f5feb5ab9d140af4c9e579b4da764b7d5af80af`；逐帧平均 RGB≈(229,235,225)（米白/暖白底），24 组相邻帧差异 **全部 >0（min 294）**，无霓虹色/无偏色，帧序列可见玻璃滑块在 4 tab 间滑动、FAB 选中放大。
  - 备注：Lead 消息中写“65 帧”，以文件元数据为准实际为 **25 帧**（GIF 成品帧数；采集源帧可更多）；不影响验收。

**C. 源码包（PASS）**
- 108 个文件、6,429,380 B；**0 敏感文件**（无 keystore.properties/signing/*.jks/*.keystore/*.p12/*.mobileprovision/密码）；含 `app/build.gradle.kts`、`app/proguard-rules.pro`、`.gitignore`、`.github/workflows/ios-unsigned.yml`、iOS 工程/源码、docs、tools；不含 screenshots/构建产物/dist。
- **zip 内文档与 workspace 完全一致**（SAME：README.md、docs/RELEASE-1.2.md、docs/DELIVERY-REPORT.md、docs/qa/qa-report.md、ios/README-IOS.md）：APK `aab04f12…`、IPA 980,354 B、source zip 行已改为“见 dist/SHA256.txt”（解决自引用哈希循环）、v6 导航描述（0.90 毛玻璃/#DEDED9 滑块/无按压/FAB 固定容器）；`HyperTabBar.kt` 与 workspace SHA 相同（#DEDED9 版）。
- 解压重建：`./gradlew :app:assembleRelease --offline` → **BUILD SUCCESSFUL（4s）**，产物 31,071,720 B（源包无签名材料、回退 debug 签名属预期）。

**D. 非阻塞 Info（不影响交付，可选清理）**
1) `screenshots/android-1.2/` 实际为 **18 PNG + 1 GIF**（RELEASE 文字写“13 张 PNG”，属计数口径差异；其中 `09/13/14/17` mtime 15:01 为早前补拍，页面不含最终导航滑块或为对比图，最终导航关键图 00-04/06/07/08/10-12/15/16/18/19 均为 16:05-16:06 新图）。
2) README 第 5 行仍写“改回传统 Android 布局…+ 浅灰玻璃滑动块”，与最终“悬浮毛玻璃胶囊 + 深灰玻璃滑块”措辞略有历史痕迹（内容不矛盾到影响使用，建议后续统一）。
3) source zip 含 `docs/reference/hyperos4-nav/hyperos4-contacts-nav.mp4` 与 2 张参考 PNG（用户提供的小米澎湃 OS 4 参考素材）；若 source 包公开分发，建议确认/排除第三方视频版权素材。
4) `screenshots/` 目录被 source 包排除（符合“不含截图”约定），zip 内文档对 `screenshots/android-1.2/VERIFY-NOTES.md` 的链接在包内不可达（属已知设计，不影响仓库/发行目录阅读）。

**最终结论：0 Blocker / 0 Major，可交付。**（APK `aab04f12…`、IPA `95868d52…`、source zip `1b0181ce…`；`dist/SHA256.txt` 4/4 OK；Android 安装启动 0 FATAL；GIF 颜色/帧差、浅灰滑块、无按压、胶囊宽度、source zip 文档/敏感项全部核验通过。）

---

## 18. 1.2 功能包验收（目录改名 / 设置页 / 黑暗模式 / 材料栏圆角 / 宣传卡片 AI+导出）

- 任务：task-13；验收时间：2026-11-07 16:44–16:56（Asia/Shanghai）；版本按要求保持 **1.2 / Android versionCode 3 / iOS build 3**。
- 环境：Xcode 27.2 + iPhone 17 模拟器（iOS 27.2，UDID EE9792B5…）；Android SDK 35 + API 35 arm64 模拟器（emulator-5554）；Lead 提供的 OpenAI 兼容 mock：`http://127.0.0.1:8765/v1`（iOS）/ `http://10.0.2.2:8765/v1`（Android），模型 `mock-card`。
- 结论：**0 Blocker / 0 Major，可交付**。

### 18.1 最终 dist（16:44，源码已冻结）

| 产物 | 大小 | SHA256 |
| --- | --- | --- |
| `dist/BeanBook-v1.2-arm64.apk` / `忆杯手记-v1.2-arm64.apk` | 31,137,368 B | `28152e622c1057d323587b6b9392daf8fd5f18d110ca5d9fdf343a8e7056aa96` |
| `dist/BeanBook-1.2-unsigned.ipa` | 1,327,798 B | `0afc2f915157d5898144d50f5bf38a76221f4341df7cfe17930edf5e7bfe31ad` |
| `dist/BeanBook-source-v1.2.zip` | 6,482,382 B | `dc98ff84b5053405dc47768bda4ede7483a234ba351fe89c302f1c1f37709417` |

`dist/SHA256.txt` 四项经 `awk` 标准化后 `shasum -a 256 -c` → **4/4 OK**；source zip 与 Lead 最后更正 SHA 一致（此前 cf48c10c 作废）。

### 18.2 A. 「别册 → 目录」全部用户可见文案（PASS）

- 源码残留：`grep -rl 别册 ios/BeanBook/` = **0 文件**；`grep -rl 别册 app/src/` = **0 文件**（含 res/xml）。
- 最终二进制残留：APK `classes*.dex` strings 中「别册」= **0**；IPA 主二进制 strings 中「别册」= **0**。
- 截图：iOS `01-menu-directory.png`、Android `22-menu-rename-light.png` 均显示「配方目录 / 设置与数据」；Android 深色菜单截图「配方目录」可读。

### 18.3 B. Android 调一杯材料栏全圆角卡片（PASS）

- 代码：`MakerScreen.kt` 中材料栏为 `Surface(shape = RoundedCornerShape(30.dp), border = 1dp LineSoft)`，外层 `padding(start=16.dp, end=16.dp, bottom=10.dp)`，不再贴底平切；暗/亮均使用 `BrewColors.Card`。
- 截图：浅色 `20-maker-tray-light.png`、深色 `08-maker-tray-dark.png` 可见材料栏为离底悬浮圆角卡片（左右/底部留白），符合要求。

### 18.4 C. 双端设置页（PASS）

- **入口**：iOS `StatsView` 最底部 `SettingsEntryCard`（截图 `07-stats-settings-entry.png`）；Android `StatsScreen` 底部 `SettingsEntryCard`（截图 `01-stats-settings-entry.png`）。QA 独立在模拟器用 UI 自动化从「统计」滚到底 → 点击「设置」成功进入设置页。
- **iOS SettingsView**：`@AppStorage` 持久化外观（跟随系统/浅色/深色）、AI 配置（Base URL/API Key SecureField/模型名，保存、测试连接、恢复默认）；数据备份与迁移（整库导出/合并导入/覆盖恢复/导入离线配方）从原 DataView 迁入（DataView 已删除）；关于含版本 1.2(3)、隐私、相册说明；单杯分享仍在 RecipeDetailView「分享文件」。
- **Android SettingsScreen**：SharedPreferences `SettingsStore` 持久化 AI 配置与外观三档；AI 保存/测试连接/恢复默认；原 DataScreen 的整库导出/合并导入/覆盖恢复/单配方导入迁入设置；关于显示 `BuildConfig.VERSION_NAME/VERSION_CODE`；单杯分享仍在 RecipeDetail。
- **AI 配置与连接（mock）独立复核**：QA 直接用 adb/UI 自动化在最终 APK 中执行「测试连接」，界面显示 **「连接成功（1 个可用模型）」**（App 已配置 mock base `http://10.0.2.2:8765/v1`、模型 `mock-card`）；主机 `curl` mock `GET /v1/models`→200 `mock-card`、`POST /v1/chat/completions`→200 返回 title/subtitle/tags/theme/template JSON。iOS 侧 mock 联调证据见 `VERIFY-REPORT.md` §3 与 `04-settings-ai-test.png`。

### 18.5 D. 黑暗模式（PASS）

- iOS：Info.plist **无** `UIUserInterfaceStyle`（Release IPA 同样确认无该键）；`Theme.swift` 动态色板 + `RootView.preferredColorScheme(AppAppearance…)`；截图 `05-dark-home.png`、`06-dark-settings.png`、`12-dark-recipe-detail.png`、`13-dark-menu.png` 暗色可读。
- Android：`Theme.kt` 双调色板（Light/Dark）+ `darkColorScheme`；`MainActivity` 同步状态栏/手势条图标；截图 `03-settings-dark/06-stats-dark/07-home-dark/08-maker-tray-dark/09-promo-preview-dark` 可读。
- **QA 独立实测**：在最终 APK 设置中切换「深色」→ 打开菜单/配方详情均正常暗色可读；`am force-stop` 后重启 App，首页仍为深色（截图均值 RGB≈(67,67,62)，左上角≈(38,37,39)）→ **持久化生效**。

### 18.6 E. 横版宣传卡片 + AI + 导出（PASS）

- 功能：双端模板（iOS 3、Android 3：奶油白/深烘黑/青柠绿）、主题色、封面（杯图/豆插画/相册图）、大标题/副标题/标签编辑、实时预览；入口在配方详情 + 菜单「卡片」；iOS 另有顶部菜单；卡片配置写入 `Recipe.promoCard`（iOS 可选 Codable）/ `Recipe.card`（Android 可空字段），旧 JSON 无字段时默认 nil/默认配置，兼容旧数据；导出/备份随配方一起带走。
- **AI 生成独立复核**：QA 在最终 APK 宣传卡片页输入描述「fresh summer lychee soda」→ 点击「AI 生成文案」（mock）→ 提示 **「AI 文案已套用到预览」**，标题/副标题/标签随 JSON 更新；代码 `AiCardService.kt` 使用 `HttpURLConnection` parse `chat/completions` 并映射 theme/template；iOS `AIClient.swift` 同格式，mock 证据见 `10-promo-ai-result.png`、`15-promo-ai-applied.png`。
- **导出相册独立复核**：
  - iOS：`CardExporter.swift` `ImageRenderer` 2x → 16:9 **2400×1350**；模拟器相册 `DCIM/100APPLE/IMG_0007~0009.PNG` 实测 **2400×1350**；Info.plist `NSPhotoLibraryAddUsageDescription` 存在；`11-export-success.png`、`16-export-permission-denied.png`（权限拒绝提示）齐全。
  - Android：`GallerySaver` MediaStore 写入 `Pictures/BeanBook/`；QA 在最终 APK 点击「导出 PNG」→ 界面提示 **已保存到相册：Pictures/BeanBook/beanbook_card_1794041355498.png**；`content query` MediaStore 查得新增文件 **1200×675**（App 导出的 beanbook_card_*.png 共 3 个）；`CardRenderer` 常量 `WIDTH=1200/HEIGHT=675`；截图 `13-promo-export.png`、`18-promo-export-ai.png`、导出成品 `24/25-exported-card-*.png` 均为 1200×675。
- 持久化：iOS `VERIFY-REPORT` 记录了保存后重新进入编辑器读回；Android `23-promo-card-persistence.png` 重启后配置仍在。

### 18.7 F. 发行包 / 版本 / 构建（PASS）

- APK：`apksigner` v2 通过，1 signer CN=BeanBook（证书 SHA 298dc038…）；versionCode=3/versionName=1.2/minSdk26/targetSdk35/com.brewkin.beanbook；manifest 含 `INTERNET`/`usesCleartextTraffic`（用于自建 http 兼容，已知限制）；`app/build/outputs/.../app-release.apk` SHA 与 dist **完全相同**；`adb install -r` Success、冷启动 640ms、**0 FATAL/0 ANR/0 AndroidRuntime**。
- IPA：1,327,798 B / `0afc2f91…`，arm64/minos 17.0、未签名、Info 1.2/3、`NSPhotoLibraryAddUsageDescription` 存在、无 `UIUserInterfaceStyle`；payload 与 `ios/build/.../Release-iphoneos/BeanBook.app` 的 `Info.plist`/`Assets.car`/图标/主二进制 **逐字节相同**；Release 无 `uiTest*` 调试字符串。
- 源码包：**120 个文件**、0 敏感文件（无 keystore/signing/*.jks/*.p12/mobileprovision/密码）；含 `app/build.gradle.kts`、`proguard-rules.pro`、`.gitignore`、`.github/workflows/ios-unsigned.yml`、新功能源码（SettingsView/AIClient/PromoCard*/CardExporter、SettingsScreen/PromoCardScreen/AiCardService/GallerySaver/CardRenderer 等）与文档；`README/RELEASE/DELIVERY/qa-report/ios README` 与 workspace **SHA 全同**；README 30 个图片引用**全部存在（missing: none）**。解压独立重建：Android `assembleRelease` **BUILD SUCCESSFUL（5s）**；iOS Release **BUILD SUCCEEDED（27s，1 warning/0 error）**，产物 Info 1.2/3 + NSPhoto 权限存在。
- 版本：Android versionCode=3/versionName=1.2；iOS Info 1.2/build 3；pbxproj 两处 1.2/3。

### 18.8 G. 静态与回归（PASS）

| 检查 | 结果 |
| --- | --- |
| `swiftc -parse ios/BeanBook/*.swift` | ✅ **22/22**（0 失败） |
| `tools/model-tests/run-tests.sh` | ✅ PASS 211 / FAIL 0 |
| `tools/model-tests/project-check.sh`（含暗色移除 UIUserInterfaceStyle 适配） | ✅ PASS 24 / FAIL 0 |
| `glass-typecheck/check-glass-api.sh` | ✅ PASS 6 / FAIL 0（SELFTEST 5/5、GATING 3、NO_LEAK） |
| 1.2 核心回归 | iOS 编辑保存/取消 data.json 逐字节一致、豆仓不重复扣豆（见 iOS VERIFY-REPORT §6）；Android 功能版 NOTES 记录编辑闭环保持；构建产物 SHA 与 dist 一致 |

### 18.9 测试材料核对

- iOS：`ios/artifacts/verify-1.2-features/` **16 张 PNG（1206×2622）+ VERIFY-REPORT.md**，覆盖设置、AI 测试、暗色首页/设置/菜单/详情、卡片预览/设计工具/AI/导出/权限拒绝/持久化。
- Android：`app/artifacts/verify-1.2-features/` **22 张 PNG（其中 2 张为 1200×675 导出成品）+ NOTES.md**；深色设置/统计/首页/材料栏/卡片预览/设计工具/AI 生成/导出/持久化齐全。`screenshots/features-1.2/{ios,android}` 抽查与 artifacts SHA256 相同。
- GIF/截图：上一轮 v10 导航截图与 GIF 未受本轮功能影响（本轮仅功能新增，UI 风格未改）；`screenshots/android-1.2/` 与 `screenshots/ios/` 保留不变。

### 18.10 非阻塞 Info / 建议（不影响交付）

1) **文档中的 IPA 字节数旧值**：`docs/RELEASE-1.2.md:54` 仍写 `1,328,201 B`（实际 dist IPA `1,327,798 B`；SHA 正确）；`docs/DELIVERY-REPORT.md` 仍写「958 KB」（旧 IPA）。属文字数值误差，建议后续随手修；若修需重新打包 source zip（文档在包内，SHA 会变），本轮不阻塞交付。
2) Android 截图目录实际为 **22 张 PNG 总计**（20 张 UI 截图 + 2 张导出成品），与 Lead 消息「22 张 + 2 张导出」口径略有差异；iOS 16 张一致。
3) 安全强化项：AI API Key 双端均以 UserDefaults/SharedPreferences 明文保存在本机（任务要求 @AppStorage/SharedPreferences，未用 Keychain/Keystore）；Android `usesCleartextTraffic=true` 以兼容自建 http mock。建议后续版本迁 Keychain/EncryptedSharedPreferences 并用 networkSecurityConfig 收紧。
4) Android 卡片本轮按 16:9 / 1200×675 交付（3:2 预留常量未启用）；iOS 3:2 功能存在但验收截图以 16:9 为主。与需求给定的导出尺寸一致。
5) 未做真机/iPad 验证（沿用已知限制）。

### 18.11 结论

- **0 Blocker / 0 Major，可交付。** 双端目录改名（源码/二进制均 0 残留）、Android 材料栏圆角卡片、双端设置页（统计底部入口/AI 配置/测试连接 mock 成功/暗色三档持久化/数据迁移/关于）、暗色可读性、宣传卡片全流程（模板/主题/封面/编辑/实时预览/AI JSON/导出 2400×1350 与 1200×675 到相册/持久化）、APK/IPA/源码包 SHA 与版本签名、源码包无敏感文件且文档一致、静态与构建校验全部通过。

---

## 19. 随杯卡 v2 验收（双端：社交平台版式 / A6 打印 / GLM-Image 插画 / 导入抠图 / 价格）

- 任务：task-16；验收时间：2026-11-07 17:32–17:45（Asia/Shanghai）；版本保持 **1.2 / Android versionCode 3 / iOS build 3**。
- 环境：Xcode 27.2 + iPhone 17 模拟器（iOS 27.2）；Android API 35 arm64 模拟器（emulator-5554）；Lead mock：images b64 `http://127.0.0.1:8765/v1`（Android `10.0.2.2:8765`）、images url-stub `127.0.0.1:8766`（Android `10.0.2.2:8766`）。
- 结论：**0 Blocker / 0 Major，可交付**。

### 19.1 最终 dist（17:32，源码冻结）

| 产物 | 大小 | SHA256 |
| --- | --- | --- |
| `dist/BeanBook-v1.2-arm64.apk` / `忆杯手记-v1.2-arm64.apk` | 31,186,520 B | `4ba02845bc00acb8f4079c703473932c614c6c62aa7e58c64181cf7783d3a063` |
| `dist/BeanBook-1.2-unsigned.ipa` | 1,492,530 B | `41b54cb9f8acad5681063b7b8a5ecad3c8da71c8beeaba335c4612350d13db42` |
| `dist/BeanBook-source-v1.2.zip` | 8,003,520 B | `7ee236f0b529d3875ecf9806778d4d4f977a19099fcc2420733ffc4992ed7438` |

`dist/SHA256.txt` 四项经 `shasum -a 256 -c` → **4/4 OK**。

### 19.2 A. 卡片版式与尺寸（PASS）

- **版式**（对照 `docs/reference/coffee-cards/ref-1~4.jpg` 与 `docs/design/promo-card-v2.md`）：奶油纸底 `#F5F1E6` + 纸纹颗粒；顶部左分类/杯型、右侧烘焙度/处理法 + `¥36` 价格小圆点；1px 细线；大号衬线英文名 + 中文名；中英配料行；风味参考；中部无边框插画；底部 2–3 个风味关键词。横版左文右图（插画右 45–55%）、竖版上文下画。
- **无 App 名称/宣传语**：导出成品 1240×1748 / 1748×1240 与 iOS 模拟器相册导出卡逐张核对，卡面只有单杯内容，无「忆杯手记/BREWKIN/宣传语」；`CardRenderer`/`PromoCardView` 渲染代码无品牌文本（仅遗留注释/未使用 `brand` 字段，Info）。
- **尺寸**：Android 代码常量 `1240×1748`（A6 竖）/`1748×1240`（A6 横）/`1200×1600`（社交竖）/`1200×675`（社交横）；Android 实际导出 `20-exported-a6-portrait-cutout.png` **1240×1748**、`21-exported-a6-landscape.png` **1748×1240**；QA 在最终 APK 再次导出 A6，MediaStore 新增 `beanbook_card_1794044141883.png` **1240×1748**。iOS 模拟器相册 `IMG_0013~0022` 独立核对到 **1240×1748、1748×1240、1200×1600、1200×675** 四种尺寸均存在。
- 1.2 卡片编辑器 UI 提供「横版 16:9 / 竖版 3:4」社交比例与「A6 打印」选项；竖版 A6 105:148、横版 A6 148:105 与需求一致。

### 19.3 B. AI 插画（GLM-Image，PASS；真实 Key 未测属已知限制）

- 设置页「插画生成 API」：默认 Provider **智谱 BigModel · GLM-Image**（Base `https://open.bigmodel.cn/api/paas/v4`、model `glm-image`、约 0.1 元/次提示）；Android `ImageProvider.ZHIPU`/iOS `AIClient` 默认值一致；另有硅基流动预设 + 自定义；尺寸预设 **1024×1440 / 1440×1024 / 1280×1280 / 1728×960** + 自定义（校验 512–2048 且 32 的倍数）。
- 请求：`POST {base}/images/generations`，`Authorization: Bearer <Key>`，body `{model,prompt,size}`；响应支持 `data[0].url` 下载到私有目录 + `data[0].b64_json` 兼容（iOS `AIClient`/Android `ImageGenService` 代码核对）。
- Prompt：按配方动态拼（名称/分类/冷热杯型/配料/豆名/风味/层色），固定含 `hand-painted watercolor`、`cream paper`、`warm tone`、`centered` 与 **no text/no letters/no words/no watermark/no logo**（iOS 明确含；Android `ImageGenService.kt` 含 `NO text, NO letters, NO words, NO watermark, NO logo`）。
- **mock 双分支**：`curl POST 127.0.0.1:8765/v1/images/generations` → HTTP 200 + 合法 PNG `b64_json`（PNG 签名校验通过）；`curl POST 127.0.0.1:8766/v1/images/generations` → HTTP 200 + `data[0].url`（`http://10.0.2.2:8766/img.png`）。
- **最终 APK 实测**：设置页保持 mock 网关 `http://10.0.2.2:8766/v1` + `mock-image`，点击「测试出图」→ 界面显示 **「出图成功：512×512」**（URL 分支真实请求+下载）；AI 插画在卡片编辑器可套用/重新生成/回退（iOS 01/02/05/06，Android 05/06/15/17 截图；iOS 报告另记 b64 分支 mock 与 url 分支 mock 均成功）。

### 19.4 C. 相册导入 + 自动抠图（PASS）

- 入口：iOS PhotosPicker / Android PhotoPicker；导入后复用现有抠图（iOS `ImageCutout` Vision 前景蒙版，模拟器不可用时降级本地颜色分离；Android 内置 U²-Netp `BackgroundRemover`）。
- 输出：透明 PNG 存 App 私有目录，卡片渲染直接叠在奶油纸纹上（无白底硬边）；失败弹「自动抠图没有成功」+「使用原图/换一张」，可回退杯图/豆插画/AI 插画。
- **独立证据**：iOS 模拟器 App 容器 `Library/Application Support/BeanBook/bean_images/` 中多个图片 PNG 的 alpha 实测存在透明像素（如 92.8%、71.8%、66.0% 透明），证明抠图产物为透明 PNG；iOS 截图 `13/14/15`（处理中/透明叠纸/失败提示）与 Android `12/13/14` 均符合。
- 持久化：`importedImagePath`、`importedOriginalImagePath`、`importedCutout`、`illustrationSource` 等均为可选字段，旧 JSON 缺失时为默认/null（代码核对；iOS `data.json` 记录见报告）。

### 19.5 D. 价格字段（PASS）

- 双端 `Recipe.price: Int?`（0/空=未设置，旧 JSON 兼容）；保存/编辑一杯弹窗可填「菜单价格 ¥」；菜单列表与配方详情显示 `¥36`；卡片右上角 + 编辑器可改价并随「保存到配方/导出」持久化。
- 截图：Android `16-menu-price.png` 菜单卡显示 ¥36（暗色）；iOS `09-menu-price.png`；卡片预览/导出卡均显示 ¥36；QA 最终 APK 打开卡片编辑器确认价格字段为 36。

### 19.6 E. 导出 / 分享 / 打印（PASS）

- Android：`导出 PNG` 写入 MediaStore `Pictures/BeanBook/`；`A6 打印图` 在最终 APK 实跑 → 提示「A6 300dpi 打印图 已保存到相册：Pictures/BeanBook/beanbook_card_1794044141883.png」+ MediaStore **1240×1748**；`分享` 打开系统分享面板（`09-share-sheet.png`，QA 实跑）；`打印` 打开 **PrintManager**，实测显示 `Paper size: ISO A6`、`Page 1 of 1` 且 A6 预览中英文名完整不截断（QA 实跑截图 `/tmp/qa-r16-print-live.png`）。
- iOS：`导出到相册` 成功（`07/11/12` 截图）；`分享/打印` 用系统分享面板，QA/演示截图 `08-share-print.png` 可见**「打印」**选项；模拟器相册实测四种尺寸 PNG 均存在。
- 权限：iOS `NSPhotoLibraryAddUsageDescription` 存在（拒绝路径见 `16-export-permission-denied.png` 系列，info 键已核对）；Android API 29+ MediaStore 无需额外权限，API 26–28 走 maxSdk28 写权限分支（代码）。

### 19.7 F. 构建 / 静态 / 安装 / 发行包（PASS）

| 检查 | 结果 |
| --- | --- |
| Android `assembleRelease` / dist 自校验 | ✅ BUILD SUCCESSFUL；`app/build/.../app-release.apk` SHA 与 dist **完全相同**（`4ba02845…a063`） |
| Android 安装启动 | ✅ `adb install -r` Success；冷启动 701ms；**0 FATAL / 0 ANR / 0 AndroidRuntime**；versionCode=3/versionName=1.2/minSdk26/targetSdk35；签名 v2 CN=BeanBook（证书 298dc038…） |
| iOS 构建/静态 | ✅ `swiftc -parse` 22/22；`model-tests` PASS 211；`project-check` PASS 24；`glass-api` PASS 6；Release 构建产物与 IPA payload **逐字节相同**（Info.plist/Assets/图标/主二进制） |
| IPA | ✅ 1,492,530 B / `41b54cb9…`；arm64 / minos 17.0 / 未签名；Info 1.2/3、`NSPhotoLibraryAddUsageDescription` 存在、无 `UIUserInterfaceStyle`；Release `uiTest*` 字符串 **0** |
| 源码包 | ✅ 8,003,520 B / `7ee236f0…`；**127 文件**、0 敏感文件/`.DS_Store`；含 `app/build.gradle.kts`、`proguard-rules.pro`、`.gitignore`、`.github`、`docs/design/promo-card-v2.md`、新功能源码；zip 内 README/RELEASE/DELIVERY/qa-report/ios README/design spec 与 workspace **SHA 全同**；README **33 个图片引用全部存在（missing none）** |
| 源码包重建 | ✅ 解压后 Android `assembleRelease` BUILD SUCCESSFUL（4s，31,186,520 B；源包无签名材料，debug 签名回退属预期）；iOS Release BUILD SUCCEEDED（1 warning/0 error；Info 1.2/3 + NSPhoto 存在） |
| 版本 | ✅ Android versionCode=3/versionName=1.2；iOS Info 1.2/build 3；pbxproj MARKETING_VERSION=1.2 / CURRENT_PROJECT_VERSION=3 |

### 19.8 测试材料

- iOS：`ios/artifacts/verify-1.2-cards-v2/` **16 张 PNG（1206×2622）+ VERIFY-REPORT.md**（设置/插画 API/测试出图/A6 竖横卡/AI 插画/导出四尺寸/分享打印/菜单价格/导入抠图成功失败等）。
- Android：`app/artifacts/verify-1.2-cards-v2/` **14 张 PNG（其中 2 张 1240×1748/1748×1240 导出成品）+ NOTES.md**（横竖卡/导出/分享/打印/抠图/菜单价格/GLM-Image 设置）。
- 汇总副本 `screenshots/features-1.2/cards-v2-ios|android/` 抽查与 artifacts SHA 相同。

### 19.9 非阻塞 Info / 已知限制（不影响 0 Blocker/Major 结论）

1) **设计规格文档有旧值**：`docs/design/promo-card-v2.md` 仍写默认 **CogView-3-Flash**、尺寸 1024×1024、底部 `BREWKIN · 忆杯手记` 品牌落款；与最终 requirement/实现（**GLM-Image**、无 App 名称）不一致，建议更新（当前 README/RELEASE 已是 GLM-Image/无品牌口径）。
2) Android 设置页「测试出图」下方说明仍有一句「智谱 CogView-3-Flash 有免费额度」（`SettingsScreen.kt:403`）；主预设/恢复默认已是 GLM-Image，属旧文案残留，建议后续修正。
3) Android 验证材料中 `22-settings-glm-image.png`（17:12）与旧版恢复默认文案可能早于 17:21 最终构建；最终 APK 代码恢复默认已为 GLM-Image，验收以最终 APK 实测为准。
4) 卡片配置 `RecipeCardConfig.brand` 仍被写为「忆杯手记」但 v2 渲染未使用（卡面无品牌）；`CardRenderer` 注释仍有「品牌落款」旧描述，代码无对应绘制。
5) 已知限制（Lead 已确认/文档记录）：本机无真实智谱 Key，线上 GLM-Image 未实测（官方格式 + mock b64/url 双分支已验）；iOS 模拟器 Vision 前景蒙版不可用 → 本地降级颜色分离；截图中的插画为 mock 占位图（部分 mock 图可能自带水印/文字，但 App 卡面本身无 App 名称，真实 GLM prompt 明确 no text/no logo）；未做真机/iPad/真实打印实测。
6) 源码包包含 `docs/reference/` 下用户提供的参考图/视频（约 3.1MB，含社交平台 4 张 ref 与澎湃参考视频）；若公开分发 source 包，建议确认第三方素材版权/是否需要排除。
7) 仓库内 `app/artifacts/.DS_Store`、`screenshots/features-1.2/.DS_Store` 为本地垃圾文件（source zip 已排除，不影响发布）。

### 19.10 结论

**0 Blocker / 0 Major，可交付。** 卡片 v2 版式/尺寸/无 App 名称、AI 插画 GLM-Image 配置与 url/b64 双分支、导入抠图透明 PNG、价格字段与持久化、导出相册/分享/系统打印（A6 1240×1748 / 1748×1240 / 社交 1200×1600 / 1200×675）、双端构建安装 0 FATAL、dist APK/IPA/源码包 SHA 与版本签名/文档一致性全部核验通过；剩余为 Info 级文案/文档旧值与环境限制。

---

## 20. 最终增量验收（平台品牌字样清理后的最终 dist 定版）

- 任务：task-19；验收时间：2026-11-07 17:43–17:48（Asia/Shanghai）；版本保持 **1.2 / Android versionCode 3 / iOS build 3**。
- 结论：**0 Blocker / 0 Major，可交付。**

### 20.1 最终 dist（17:42–17:43，源码冻结）

| 产物 | 大小 | SHA256 |
| --- | --- | --- |
| `dist/BeanBook-v1.2-arm64.apk` / `忆杯手记-v1.2-arm64.apk` | 31,186,520 B | `b4c48ff8d784ca8b7adf253e69bfc436fc5331ab91514fd5bcc64844677ff30b` |
| `dist/BeanBook-1.2-unsigned.ipa` | 1,492,524 B | `01251ae9b22b79224a10bcca04560eb11073d5d49b5fb70ed19d9863d05a69b9` |
| `dist/BeanBook-source-v1.2.zip` | 8,007,544 B | `2a048b340a23d7879bab7aa147d28867e99ecc0a03e8e79a53f37d1b9999eb28` |

`dist/SHA256.txt` 四项经 `awk` 标准化后 `shasum -a 256 -c` → **4/4 OK**（source zip 以 Lead 最后更正的 `2a048b34…` 为准；此前 `2b0be402…` 作废）。

### 20.2 A. 平台品牌字样清理（PASS）

- 文本 grep：`ios/BeanBook`、`app/src`、`README.md`、`docs/`、源码包解压内容中目标品牌字样 = **0 文件/0 行**；不区分大小写的短标识 grep 在源码/文档 = **0**。
- Release 二进制：APK `classes*.dex` strings 精确目标字样 = **0**、整词/边界匹配 = **0**；IPA 主二进制 strings 精确目标字样 = **0**、整词/边界匹配 = **0**（dex 中仅有一处大小写不敏感的子串命中来自生成式标识符片段，不是该品牌词，也无用户可见含义）。
- 新截图/动图（`ios/artifacts/verify-1.2-cards-v2/16-ai-copy-sheet.png`、`17-recipe-detail-promo-entry.png`、覆盖的 `07/11`；`app/artifacts/verify-1.2-cards-v2/23-card-editor-final.png`、`24-share-sheet-final.png`）逐张核对为中性表述：AI 文案入口写「适合社交封面的宣传文案」、配方详情入口写「做一张宣传卡片 / 随杯卡 · 可 AI 生成文案」、导出成功弹窗写「可以直接分享或打印」、分享面板为系统「Sharing image」；截图文件中无该字样。
- 参考素材目录已改名为 `docs/reference/coffee-cards/`（source zip 内 4 张 ref 均在新路径）；README/RELEASE/DELIVERY/design spec/qa report 已同步中性表述，源码包文本 grep 目标字样 = **0**。
- **Info**：`ios/artifacts/verify-1.2-cards-v2/VERIFY-REPORT.md:7` 仍有一处旧参考目录路径名（未随目录改名更新为 `coffee-cards`）；该文件是测试材料、不在 source zip/用户发行目录中，建议后续清理，不阻塞交付。

### 20.3 B. 发行包 / 版本 / 签名 / 安装（PASS）

- APK：`apksigner` v2 通过，1 signer **CN=BeanBook**（证书 SHA-256 `298dc038…078c`）；`versionCode=3`/`versionName=1.2`/minSdk 26/targetSdk 35/com.brewkin.beanbook；`app/build/outputs/.../app-release.apk` SHA 与 dist **完全相同**（`b4c48ff8…30b`）；`adb install -r` Success、冷启动 638ms、**0 FATAL / 0 ANR / 0 AndroidRuntime**。
- IPA：1,492,524 B / `01251ae9…69b9`；arm64、minos 17.0、未签名；Info **1.2/3**、`NSPhotoLibraryAddUsageDescription` 存在；payload 与 `ios/build/.../Release-iphoneos/BeanBook.app` 的 Info.plist/Assets.car/图标/主二进制 **逐字节相同**。
- Source zip：**8,007,544 B**、127 文件、**0 敏感文件/`.DS_Store`**；含 `README/docs/design/promo-card-v2.md` 与最新参考目录；zip 内 README/RELEASE/DELIVERY/qa-report/ios README/design spec 与 workspace **SHA 全同**；README **33 个图片引用全部存在（missing none）**；解压独立重建 Android **BUILD SUCCESSFUL（4s）**、iOS Release **BUILD SUCCEEDED（1 warning/0 error，Info 1.2/3 + NSPhoto 存在）**。
- 文档：README/RELEASE/DELIVERY 的 APK/IPA SHA 与字节数均与最终 dist 一致（APK 31,186,520 B、IPA 1,492,524 B）；source zip 行统一为「见 dist/SHA256.txt」。

### 20.4 C. 卡片 v2 功能不回退（PASS）

- 沿用并复核 §19 的完整验收结论：卡片版式（奶油纸底/分类/烘焙处理法/¥36/细线/衬线英文+中文/配料/风味/插画/关键词、横竖版、无 App 名称）、A6 300dpi 导出（1240×1748 / 1748×1240）、社交尺寸（1200×1600 / 1200×675）、AI 插画 GLM-Image 预设与 url/b64 双分支、导入抠图透明 PNG、价格字段与持久化、导出相册 + 分享 + 系统打印（Android PrintManager / iOS 分享面板含打印）均未改动；本轮差异为文案/注释清理与重打包。
- 校验：源码包代码与 workspace 关键文件 SHA 相同（`PromoCardView.swift`/`AIClient.swift`/`RecipeDetailView.swift`/`PromoCardScreen.kt`/`ImageGenService.kt`/`SettingsScreen.kt`）；`swiftc -parse` **22/22**、model **211 PASS**、project-check **24 PASS**、glass **6 PASS**；最终 APK 安装启动 0 FATAL。

### 20.5 D. 非阻塞 Info / 已知限制

1) `ios/artifacts/verify-1.2-cards-v2/VERIFY-REPORT.md` 仅剩一处旧参考目录路径（见 20.2），属测试材料、不随 source zip/发行目录发布。
2) 沿用已知限制：本机无真实智谱 Key（GLM-Image 线上未实测，mock b64/url 双分支已验）、iOS 模拟器 Vision 前景蒙版不可用（本地降级颜色分离）、截图插画为 mock 占位图、未做真机/iPad/真实打印机实测。
3) source zip 含用户提供的参考图/视频（`docs/reference/` 约 3.1MB）；若公开分发 source 包，建议确认第三方素材版权。
4) 仓库内 `app/artifacts/.DS_Store`、`screenshots/features-1.2/.DS_Store` 为本地垃圾文件（source zip 已排除）。
5) 本节（§20）在本轮 source zip 打包后追加，故 source zip 内 `qa-report.md` 为打包时快照（不含本节）；不影响 source zip 的 SHA/内容一致性声明。

### 20.6 结论

**0 Blocker / 0 Major，可交付。** 平台品牌字样清理在源码/文档/参考目录/source zip 文本/APK dex/IPA 二进制/新截图层面全部核验通过；最终 APK/IPA/source zip 的 SHA、大小、版本、签名/未签名、安装启动、源码包无敏感文件与文档一致性、卡片 v2 核心功能与静态/重建校验均通过。

---

## 21. 卡片编辑器 v3 最终验收（全元素编辑 / 拖拽 / 8–72pt 字号 / 防遮挡 / 双端对齐）

- 任务：task-22；验收时间：2026-11-07 18:56–19:05（Asia/Shanghai）；版本保持 **1.2 / Android versionCode 3 / iOS build 3**。
- 结论：**0 Blocker / 0 Major，可交付。**

### 21.1 最终 dist（19:00 前冻结）

| 产物 | 大小 | SHA256 |
| --- | --- | --- |
| `dist/BeanBook-v1.2-arm64.apk` / `忆杯手记-v1.2-arm64.apk` | 31,317,592 B | `372252b8e0d8d10c127378a16e934786925b1df5a93ecf9d8dfe94ff91c6b926` |
| `dist/BeanBook-1.2-unsigned.ipa` | 1,636,253 B | `97c42db470e99af2bb8a059e9bec0d878de3035c2a01f7649806c09e868c0f54` |
| `dist/BeanBook-source-v1.2.zip` | 4,916,950 B | `3d0dc3bc4116d12e67f43c013cda9e32a143937dfd97fc4e2328982a60f13b10` |

`dist/SHA256.txt` 四项经 `shasum -a 256 -c` → **4/4 OK**（source zip 以 Lead 最后更正的 `3d0dc3bc…` 为准）。

### 21.2 A. APK / IPA / 安装（PASS）

- APK：`apksigner` v2 通过，1 signer **CN=BeanBook**（证书 SHA-256 `298dc038…078c`）；`versionCode=3`/`versionName=1.2`/minSdk 26/targetSdk 35；`app/build/outputs/.../app-release.apk` SHA 与 dist **完全相同**（`372252b8…b926`）；`adb install -r` Success、冷启动 655ms、**0 FATAL / 0 ANR / 0 AndroidRuntime**。
- IPA：1,636,253 B / `97c42db4…c0f54`；arm64、minos 17.0、未签名；Info **1.2/3**、`NSPhotoLibraryAddUsageDescription` 存在；payload 与 `ios/build/.../Release-iphoneos/BeanBook.app` 的 Info.plist/Assets.car/图标/主二进制 **逐字节相同**。

### 21.3 B. Android 卡面字体与 iOS 对齐（PASS）

- 代码（`CardLayout.typefaceFor`）：**价格 / 英文名 / 中文名 → serif**；英文名 regular，价格/中文名 medium（API 28+ `Typeface.create(serif, 500/400)`，低版本 bold 近似）；分类/烘焙处理法/配料/风味参考/关键词 → **sans**（medium/regular 按 iOS 规则）；tracking 按 iOS 设计点换算、英文名 lineSpacing −1u、默认字号按 iOS `promoDefaultFontSize` 比例。
- 实际渲染：新截图 `01-default-auto-layout.png`、`11-font-size-panel.png` 中价格「¥36」、`Lychee White Grape Cold Brew`、`荔枝气泡冷萃` 均为衬线体；其余元素为无衬线；中文衬线回退 **NotoSerifCJK** 显示正常、**无 tofu**、无截断；与 iOS 截图对照层级/字重/比例一致（字形本身 New York/Songti vs Noto 的系统级差异见 §21.7）。

### 21.4 C. 全元素编辑 / 字号 / 拖拽 / 防遮挡（PASS）

- 全元素可编辑：中文名、英文名、价格、副标题、分类、烘焙处理法、配料中/英、风味参考中/英、关键词、标签；留空自动按配方推导；隐藏元素不渲染/不参与碰撞；插画来源 AI/相册抠图/杯图/豆插画/相册原图（含抠图管理）。
- 布局编辑：虚线框（未选灰/选中 lime/碰撞红）；点选、拖动、卡面内限制；碰撞检测红提示 + 松手回退；保存/导出/分享/打印前按当前导出尺寸做重叠拦截（iOS `guardBeforeOutput`、Android `hasConflict` 均覆盖四处出口）；「恢复自动排版」清空当前方向手动布局并重排。
- 字号/对齐/缩放：每文字元素独立 Slider **8–72pt step 1**（截图 46pt 实测）；左/中/右对齐；图片缩放 **50–200%**；横/竖版分别持久化。
- 自动排版：默认按真实文本高度流式堆叠（截图 01 无重叠/不越界/A6 与社交不截断）；模板/横竖版切换自动清空手动布局并重排（提示条文案）。
- 状态截图：Android `app/artifacts/verify-1.2-card-editor/` **17 张（17 个唯一 SHA，无重复）**：12 个 iOS 对应状态 + 横版默认 + 4 张实际导出 PNG；iOS 12 张，互不重复。UI 结构逐项对齐设计规范：顶部栏（返回/PROMO CARD·宣传卡片/保存）→提示条→LIVE PREVIEW→预览卡→A6 说明→两行工具栏（设计工具/AI 插画/导入图片/AI 文案；编辑布局/导出到相册/分享打印）→导出尺寸胶囊→保存到配方→「怎么用」卡；设计工具/AI 文案/AI 插画为底部 sheet。
- 导出尺寸实测：竖版 A6 **1240×1748**、横版 A6 **1748×1240**、社交竖 **1200×1600**、社交横 **1200×675**（四张实际导出 PNG 文件名/像素均核对）；导出/分享/打印使用同一排版引擎（WYSIWYG）。

### 21.5 D. 持久化 / 旧 JSON 兼容（PASS）

- iOS 沙盒 `data.json` 实测：`recipes[0].price=36`、`promoCard.manualLayout.portrait/landscape`（归一化 centerX/centerY/width/height/scale）、`fontSizes.portrait`（englishName 46、chineseName 34）等；重进编辑器保留（截图 08/12）。
- Android 对应 `RecipeCardConfig` 字段（`manualLayout/fontSizes/hidden/copyOverrides/illustrationPath/importedImagePath/exportSize/...`）全部可空/默认；`BeanRepository` JSON `ignoreUnknownKeys=true`，旧数据缺字段走默认自动排版；截图 08/12 验证重进保留。
- 设计风格未变（奶油纸底/细纸纹/层级/细线/衬线排版），默认卡与 v2 视觉一致；本轮仅字体与编辑器 UI 对齐。

### 21.6 E. 构建 / 静态 / source zip（PASS）

| 检查 | 结果 |
| --- | --- |
| `swiftc -parse` | ✅ 22/22 |
| model-tests / project-check / glass | ✅ PASS 211 / PASS 24 / PASS 6 |
| source zip | ✅ 4,916,950 B / `3d0dc3bc…`；122 文件、0 敏感文件/`.DS_Store`；按约定排除 `docs/reference/`（0 条）；README/RELEASE/DELIVERY/qa-report/design spec 与 workspace **SAME**；README **42 个图片引用 missing none** |
| source zip 独立重建 | ✅ Android `assembleRelease` BUILD SUCCESSFUL（4s，31,317,592 B，源包无签名材料 debug 签名回退属预期）；iOS Release BUILD SUCCEEDED（1 warning/0 error，Info 1.2/3） |
| 文档一致性 | ✅ README/RELEASE/DELIVERY 的 APK/IPA SHA 与字节数均为最终值（31,317,592 / 1,636,253） |

### 21.7 非阻塞 Info / 已知差异

1) 字体字形差异：Android serif 为 Noto Serif（中文回退 NotoSerifCJK），iOS 为 New York/Songti，字形细节不同；medium 在 API<28 用 bold 近似（验收机 API 35 用 weight 500）。
2) 卡片几何仍为 Android v3 原设计：横竖版版式、分类下产地行、价格后主题色圆点等与 iOS 参考存在小幅差异（用户要求不改卡片视觉）。
3) 编辑器 Compose 复刻圆角/间距/自绘图标与 iOS 有 1–2dp 级差异；换行/字距 Android Paint 与 SwiftUI 有 1–2px 差异。
4) source zip 按 Lead 要求排除 `docs/reference/`，zip 内 RELEASE/design spec 文本仍引用该路径（仅文本，包内不可达）；`docs/reference/card-editor-ios/` 参考截图未随 source 包分发。
5) 其余沿用已知限制：无真实智谱 Key、iOS 模拟器 Vision 抠图降级、mock 插画、未真机打印；仓库 `.DS_Store` 为本地垃圾文件（source zip 已排除）。
6) 本节（§21）在本轮 source zip 打包后追加，source zip 内 `qa-report.md` 为打包时快照（不含本节）；不影响 source zip SHA/内容声明。

### 21.8 结论

**0 Blocker / 0 Major，可交付。** 最终 APK/IPA/source zip 的 SHA、大小、版本、签名/未签名、安装启动；Android 卡面字体（价格/英文名/中文名 serif + 其余 sans、NotoSerifCJK 无 tofu）、编辑器 UI 与 iOS 结构对齐；12 状态截图与 17 张唯一 Android 截图/4 尺寸导出；全元素编辑/8–72pt 字号/拖拽/碰撞回退/恢复自动排版/双尺寸遮挡拦截/持久化旧 JSON 兼容；source zip 无敏感且文档一致、双端独立重建成功，全部核验通过。

---

## 22. 忆杯手记品牌 / 深色导航 / 图标 / 关于页 / GitHub 发布包最终验收

- 任务：task-28；验收时间：2026-11-07 20:09–20:16（Asia/Shanghai）；版本保持 **1.2 / Android versionCode 3 / iOS build 3**。
- 结论：**0 Blocker / 0 Major，可交付。**

### 22.1 最终 dist（20:12 冻结）

| 产物 | 大小 | SHA256 |
| --- | --- | --- |
| `dist/BeanBook-v1.2-arm64.apk` / `忆杯手记-v1.2-arm64.apk` | 31,293,248 B | `13c76113b3c56665419c27f8738a449c5dbd0dc202f5f880b018e748f66bb519` |
| `dist/BeanBook-1.2-unsigned.ipa` / `忆杯手记-1.2-unsigned.ipa` | 1,736,378 B | `506314ed485a8ef31a0e39f32fb5872cf667d2e7c2d5e7dfd0657e3869b9ef5d` |
| `dist/BeanBook-source-v1.2.zip` | 5,002,836 B | `65e98a51f46c32f34ebe8be2ebfb8e3ac37941e5060599a71aaf0ae09bffc522` |

`dist/SHA256.txt` **五项**经 `shasum -a 256 -c` → **5/5 OK**（source zip 以 Lead 最后更正的 `65e98a51…` 为准）。

### 22.2 A. APK / IPA 安装与品牌（PASS）

- APK：`apksigner` v2 通过，1 signer **CN=BeanBook**；`versionCode=3`/`versionName=1.2`/minSdk 26/targetSdk 35；`application-label=忆杯手记`；build 产物 SHA 与 dist 完全一致；独立 `adb install -r` Success、冷启动 565ms、**0 FATAL / 0 ANR / 0 AndroidRuntime**。
- IPA：1,736,378 B、arm64/minos 17.0/未签名、**CFBundleDisplayName=忆杯手记**、Info 1.2/3；payload 与 Release build 逐字节相同。
- 品牌：`ios/BeanBook` 与 `app/src` 中旧品牌名 **grep=0**；APK dex / IPA 主二进制旧品牌=0；可见名称/首页/关于/主页品牌行均为「忆杯手记 / YIBEI」；内部 applicationId/bundle id 仍为 BeanBook 系（有意兼容，Info）。

### 22.3 B. Android 深色底部导航（PASS）

- 代码 `HyperTabBar` 增加 `isDark` 色板：深色栏 `#23241C/0.84`、深色滑块 `#3D3F31→#36382B→#2F3126`（0.96→0.92）+ 白色高光/rim、选中文字 `#F6F3EA`、未选中白 64%；浅色分支保持原 `#DEDED9` 滑块/暖白栏完全不变。
- 截图：`01-light-home/02-light-menu/03-light-stats` 与既有浅色版本一致；`04-dark-home/05-dark-menu/06-dark-stats` 深色栏与深色滑块、浅色图标文字对比可读，结构与动效（选中/弹簧/渐变）一致，未出现割裂；`08-launcher-icon` 桌面图标为深橄榄底+白杯「忆杯手记」。

### 22.4 C. 关于页 / 开发者 / 版本（PASS）

- iOS `SettingsView` 与 Android `SettingsScreen` 的「关于」均含：**开发者 芝士鸡cheeseE**、可点击链接 `https://space.bilibili.com/397554088`（iOS `Link` / Android `ACTION_VIEW` Intention）、版本 **1.2（build 3）**、隐私与相册/分享说明；截图 `ios/artifacts/verify-1.2-brand/02-settings-about.png`、`03-dark-about.png` 与 Android `09-about-developer-bilibili.png` 确认版式/深色可读，链接行可见可点区域。

### 22.5 D. 新 App 图标（PASS）

- iOS：`AppIcon.png` 1024×1024 RGB 已替换（深橄榄底+白杯），`Assets.xcassets/AppIcon.appiconset/Contents.json` 正常引用；模拟器桌面截图 `04-app-icon.png` 显示新图标与「忆杯手记」。
- Android：`mipmap-*` 全套 `ic_launcher/ic_launcher_round` + `adaptive icon` 前景/背景更新；`AndroidManifest` icon/roundIcon 指向正确；桌面截图 `08-launcher-icon.png` 实测新图标。

### 22.6 E. GitHub 发布工程文件夹（PASS）

- `dist/忆杯手记-v1.2-github/`：**131 文件、7.1MB**；结构含 `app/`（Android 源码+gradle wrapper）、`ios/`（SwiftUI 源码/xcodeproj/scripts）、`docs/`（RELEASE-1.2、card-editor-ui-spec、promo-card-v2）、`screenshots/preview/`（14 张压缩预览图）、README、THIRD_PARTY_NOTICES、`.gitignore`、`忆杯手记-v1.2-发行说明.md`。
- README 为发布版专用：**6 个图片引用全部存在（missing none）**、本地链接无缺失；发行说明含开发者「芝士鸡cheeseE」、B 站链接、使用说明/更新日志；全文平台品牌旧词 **0**、旧品牌名 **0**。
- 安全/构建：无 keystore/.jks/keystore.properties/local.properties/build 产物/参考素材；复制到 /tmp 补临时 local.properties 后 **Android BUILD SUCCESSFUL（31,293,248 B）+ iOS BUILD SUCCEEDED（CFBundleDisplayName=忆杯手记/1.2/3）**，双端源码可重建。

### 22.7 F. source zip / 文档 / 静态（PASS）

| 检查 | 结果 |
| --- | --- |
| source zip | 5,002,836 B / `65e98a51…`；131 文件、**0 敏感文件/.DS_Store**；旧品牌名 0、平台旧词 0；主文档 README/RELEASE/DELIVERY/qa-report/design spec/ios README 与 workspace **SAME**；README 在 workspace 的 42 个图片引用 missing none |
| 静态 | `swiftc -parse` 22/22；model 211 PASS；project-check 24 PASS（含显示名断言）；glass 6 PASS |
| 构建 | GitHub 文件夹 Android assembleRelease / iOS Release BUILD SUCCEEDED；source zip 内代码与 GitHub 文件夹关键文件 SHA 相同 |
| 版本/签名 | Android vc=3/vn=1.2、签名 CN=BeanBook；iOS 1.2/build 3；内部包名/Bundle ID 保留（有意） |

### 22.8 非阻塞 Info

1) source zip 未包含 GitHub 文件夹专用的 `忆杯手记-v1.2-发行说明.md`（该 md 仅随 GitHub 发布文件夹分发；source zip 主文档与 workspace 一致，不影响）。
2) source zip 按约定不含 screenshots/docs/reference（README 中依赖截图的链接在 source zip 内不可达，属既有打包设计取舍）。
3) 仓库内 `app/artifacts/verify-1.2-brand/NOTES.md`、`dist/archive/SHA256.txt` 作为验证/历史归档仍含旧品牌名（非用户发布目录；source zip/GitHub 文件夹内均为 0）。
4) 沿用已知限制：Android serif 为 Noto Serif/NotoSerifCJK（与 iOS New York/Songti 字形有系统差异）、内部 BeanBook 标识有意保留、无真实智谱 Key/iOS 模拟器抠图降级等。
5) 本节（§22）在 source zip 打包后追加，zip 内 `qa-report.md` 为打包时快照（不含本节）。

### 22.9 结论

**0 Blocker / 0 Major，可交付。** 最终五件发行物 SHA/大小/版本/签名/未签名/安装；品牌更名与可见文案、内部 ID 兼容；Android 深色导航/浅色回归；关于页开发者/B 站链接/版本；双端新图标；GitHub 发布文件夹 README 图片、发行说明、源码可重建、无敏感与构建产物；source zip 无敏感/文档一致；静态与构建校验全部通过。

---

## 23. AI 插画透明抠图 / 去水印 / 保存相册 + 透明 PNG 导入最终验收

- 任务：task-31；验收时间：2026-11-07 21:17–21:25（Asia/Shanghai）；版本保持 **1.2 / Android versionCode 3 / iOS build 3**。
- 结论：**0 Blocker / 0 Major，可交付。**

### 23.1 最终 dist（21:16 冻结）

| 产物 | 大小 | SHA256 |
| --- | --- | --- |
| `dist/BeanBook-v1.2-arm64.apk` / `忆杯手记-v1.2-arm64.apk` | 31,309,632 B | `9e7c74a1ad8c246471de33d87c9f0f0ac62f0b92cf023a733df3b16cf96b03c1` |
| `dist/BeanBook-1.2-unsigned.ipa` / `忆杯手记-1.2-unsigned.ipa` | 1,781,434 B | `23024f61dfe965d000b3248d0d199fe5f7e41398b48ea1c5ccacf073e3895d9f` |
| `dist/BeanBook-source-v1.2.zip` | 5,021,471 B | `ee5a65e8a09eccdb7c53475465256d2a25d043d9ba4a7d50fa99e68bcf38acda` |

`dist/SHA256.txt` **五项**经 `shasum -a 256 -c` → **5/5 OK**。

### 23.2 A. APK / IPA 安装与版本（PASS）

- APK：`apksigner` v2 通过，1 signer **CN=BeanBook**；versionCode=3/versionName=1.2/minSdk 26/targetSdk 35；`application-label=忆杯手记`；build 产物 SHA 与 dist 完全一致；独立 `adb install -r` Success、冷启动 647ms、**0 FATAL / 0 ANR / 0 AndroidRuntime**。
- IPA：1,781,434 B、arm64/minos 17.0/未签名、**CFBundleDisplayName=忆杯手记**、Info 1.2/3；payload 与 Release build 逐字节相同。
- source zip：5,021,471 B、**133 文件**、**0 敏感文件/.DS_Store**；包含新增 `AIIllustrationProcessor.swift` / `AiIllustrationProcessor.kt`；README/RELEASE/DELIVERY/qa-report/design spec/ios README 与 workspace **SAME**；无敏感/第三方参考素材。

### 23.3 B. AI 插画纯色背景抠图（PASS）

- iOS `AIIllustrationProcessor.swift`：四边 **2% 环带**中位色估背景 → RGB 距离颜色键控（near 16 / soft 48 + smoothstep）→ 半透明像素反混合 despill → 背景不均匀时回退原图并提示；不使用 Vision 前景分割。
- Android `AiIllustrationProcessor.kt`：四边 2% 环带中位色；**只清除与图像边框连通、颜色接近背景的像素**（避免误抠主体内部白瓷/奶油色）；46–70 软过渡 + despill；背景不纯回退；1.5% padding。
- **透明 alpha 独立验证**：
  - iOS `processed-ai-cutout.png` / `saved-album-illustration.png`：**863×771 RGBA**，透明 46.4% / 不透明 53.6%，alpha 唯一值 `{0,255}`；模拟器相册最新 `IMG_0030.PNG` **863×771 RGBA 透明 46.4%**；
  - Android `04-processed-transparent.png`：**855×763 RGBA**，透明 36.9% / 不透明 63.1%；相册 `Pictures/忆杯手记/AI插画/yibei-ai-1794056813219.png` 拉回实测 **855×763 RGBA 透明 36.9%**；
  - 卡片截图 03/05 中透明插画直接叠奶油纸，无白底；不均匀背景回退截图 05（iOS）确认。
- 透明 PNG 相册导入：iOS `bbHasSignificantTransparency` / Android `ImageUtils.hasSignificantTransparency` 检测 alpha<250 占比（iOS ≥1%、Android >2% 或边缘透明）→ 直接保留 alpha、裁透明边距+padding，**不调用 Vision/U²-Net**；卡片提示「已使用透明背景导入…未触发抠图」；不透明图仍走原抠图流程（截图 06/07 对比、`app/artifacts/verify-1.2-transparent-import`）。

### 23.4 C. 去 AI 水印（PASS）

- 请求体增加 `"watermark_enabled": false`；4xx/免责相关错误自动回退 `true` 重试（iOS `AIClient`、Android `ImageGenService`）。
- mock 实测日志 `mock-watermark-retry.log`：`attempt=2 watermark_enabled=False` → 403 → `attempt=3 watermark_enabled=True` → 成功；客户端回退逻辑生效。
- 本地清理（双端）：外圈（底部/右侧）低饱和、小面积、与主体 alpha 连通块不相连的独立块删除并膨胀 3px 清 AA；mock 原图底部 BREWKIN 小字 + 右下角标，处理后清除；`alpha-check.txt` 记录外圈低饱和块占比 **29.995% → 0.374%**；`watermark-before-after.png` 对比可见水印/角标消失，杯体/碟/蒸汽保留。

### 23.5 D. 保存 AI 插画到相册（PASS）

- iOS：AI 插画面板「保存透明图到相册」→ `PHPhotoLibrary` addOnly；成功弹窗标注 863×771 PNG/alpha；模拟器相册最新 PNG 实测 RGBA 透明 46.4%。
- Android：`GallerySaver.saveAiIllustration` → MediaStore `Pictures/忆杯手记/AI插画/yibei-ai-*.png`；成功提示；实际文件 855×763 RGBA 透明 36.9%。
- 处理后版 `illustrationImagePath` 用于卡片，raw 原图单独 `illustrationRawImagePath` 可重新处理；字段可选、旧 JSON 兼容。

### 23.6 E. GitHub 发布文件夹 / 文档 / 构建（PASS）

- `dist/忆杯手记-v1.2-github/`：**137 文件 / 7.5MB**；README 发布版专用，**6/6 图片引用存在**、本地链接无缺失；`忆杯手记-v1.2-发行说明.md` 已更新 AI 透明抠图/去水印/保存相册/透明导入说明，开发者/ B 站链接存在；平台旧词/旧品牌名 grep **0**；无 keystore/.jks/local.properties/build 产物/第三方参考素材。
- GitHub 文件夹独立重建：**Android BUILD SUCCESSFUL（31,309,632 B）+ iOS BUILD SUCCEEDED（CFBundleDisplayName=忆杯手记/1.2/3）**。
- 静态：`swiftc -parse` **23/23**（新增 `AIIllustrationProcessor.swift`）、model 211 PASS、project-check 24 PASS、glass 6 PASS；版本/签名同 §23.2。

### 23.7 非阻塞 Info

1) 本地去水印为启发式：仅处理外圈低饱和、小面积、与主体不相连的独立块；水印与主体重叠/面积过大时可能保留，需服务端去水印或重新生成；真实智谱账号未签免责时依赖自动回退 + 本地清理。
2) 透明导入判定基于 alpha<250 占比阈值（iOS ≥1%、Android >2%/边缘），极小透明区域（如仅圆角）会走自动抠图，属预期。
3) 旧卡片若保存的是旧不透明插画，不会自动重处理；需重新生成或对 raw 重新处理（新流程）。
4) source zip 不含 GitHub 文件夹专用的发行说明 md，且按约定不含 screenshots/reference；README 图片链接在 source zip 内不可达，属既有打包取舍。
5) `dist/.DS_Store` 为系统垃圾文件，不参与五项校验；发布物 SHA 不受影响。
6) 本节（§23）在 source zip 打包后追加，zip 内 `qa-report.md` 为打包时快照（不含本节）。

### 23.8 结论

**0 Blocker / 0 Major，可交付。** 新 APK/IPA/source zip 五项 SHA/大小/版本/签名/安装；AI 插画纯色背景颜色抠图透明 alpha（双端 PNG 实测）、去水印请求回退 + 本地清理（before/after 与低饱和块占比验证）、保存透明 PNG 到相册（iOS/Android 实测）、透明 PNG 导入跳过抠图、卡片/导出无白底水印；GitHub 发布文件夹 README/发行说明更新、无敏感、双端源码可重建；静态与构建全部通过。

---

## 24. AI 插画透明底 prompt / 实物图→插画 / 图片理解 API + 相机隐私键修复 最终验收

- 任务：task-35；验收时间：2026-11-07 21:39–21:50（Asia/Shanghai）；版本保持 **1.2 / Android versionCode 3 / iOS build 3**。
- 结论：**0 Blocker / 0 Major，可交付。**

### 24.1 最终 dist（21:41 冻结）

| 产物 | 大小 | SHA256 |
| --- | --- | --- |
| `dist/BeanBook-v1.2-arm64.apk` / `忆杯手记-v1.2-arm64.apk` | 31,326,016 B | `04ec1af9602684916aa97ddba4b544fbfb529cc8f12cffa80714d79f56cff03c` |
| `dist/BeanBook-1.2-unsigned.ipa` / `忆杯手记-1.2-unsigned.ipa` | 1,856,135 B | `2503dab3cf16b1a474416ece05ba4c11136451085f7ea2ba3266738d0628d83e` |
| `dist/BeanBook-source-v1.2.zip` | 5,038,699 B | `719abbf8618a8cf0e32cafcd8eea6b7c57cd24b1e5be3c72534d18039a84a9a3` |

`dist/SHA256.txt` **五项**经 `shasum -a 256 -c` → **5/5 OK**；APK 与上轮相同；IPA/source zip 为相机键修复后新构建。

### 24.2 A. 相机隐私键修复（本轮 MAJOR 已关闭）

- `ios/BeanBook/Info.plist` 已增加 `NSCameraUsageDescription` =「用于拍摄实物照片并生成随杯卡插画。」；IPA payload 与 source zip 内 Info.plist 均实测含该键。
- IPA：1,856,135 B / `2503dab3…d83e`；`CFBundleDisplayName=忆杯手记`、Info 1.2/3、相机/相册权限键齐全；payload 与 Release build 逐字节相同。
- `project-check.sh` 独立复跑：**PASS=25 / FAIL=0**（「有相机代码且含 NSCameraUsageDescription」通过）；parse 23/23、model 211、glass 6。
- GitHub 发布文件夹 `ios/BeanBook/Info.plist` 同样含相机键；复制后 Android BUILD SUCCESSFUL + iOS BUILD SUCCEEDED（DisplayName=忆杯手记/1.2/3 + 相机键存在）。

### 24.3 B. AI 插画 prompt 改透明底（PASS）

- 双端均已去掉「奶油纸底」固定词，尾部统一要求：`isolated illustration on transparent background, PNG with alpha, no background scene, no paper texture, no shadow, no text/letters/words, no watermark/logo/UI`；iOS `AIClient.illustrationTransparentSuffix`、Android `ImageGenService.buildIllustrationPrompt` 均确认。
- 处理器分支：真 alpha（≥1%）直接保留 → 纯色底颜色键控 + despill → 棋盘格透明底检测/移除 → 背景不纯回退提示；处理方式在面板/banner 展示。
- 证据：`processor-check.txt`、`evidence-alpha-*`、`evidence-checker-*` 实测——alpha 直出 517×537 RGBA 透明 57.8%、纯色 863×771 RGBA 透明 46.4%、棋盘 469×557 RGBA 透明 52.2%；卡片/导出截图无白底。

### 24.4 C. 实物图 → 同风格插画（PASS）

- AI 插画面板新增「从实物图生成」：选图/拍照（真机）；优先图片理解 API（OpenAI 兼容 chat/completions + `image_url`，默认 `https://open.bigmodel.cn/api/paas/v4`、`glm-4v-flash`、Key 可复用文案 Key）→ prompt（≤200 字，追加透明底要求）→ 可编辑 → 图片 API 生成 → 透明化/去水印 → 套用卡片。
- `vision-request.log` 实测 `model=glm-4v-flash image_url=True text_len=286`；`generated-photo-prompt.txt` 含透明背景完整后缀；未配置/失败走本地降级（照片主色/亮度+配方），UI 明确提示，截图 04 验证。
- 设置页「图片理解 API」配置卡（Base/Key/Model/保存/测试/恢复默认，默认 `glm-4v-flash`）代码与截图 `07-settings-vision-api.png` / Android `01-settings-vision-api.png` 齐全。
- 持久化：实物图路径/prompt/来源（vision/local）为可选字段，旧 JSON 缺字段兼容；卡片 raw 保留可重新处理。

### 24.5 D. 发行包 / GitHub / 文档 / 构建（PASS）

- source zip：5,038,699 B / `719abbf8…a9a3`；134 文件、**0 敏感文件/.DS_Store**；主文档 README/RELEASE/DELIVERY/qa-report/ios README 与 workspace **SAME**；含 `AiVisionService.kt`/`AIIllustrationProcessor.swift`；相机键齐全。
- GitHub 发布文件夹：7.9MB；README 6 个图片引用全部存在（`screenshots/preview/` 实际 23 张预览图均在）、发行说明已更新「透明底 PNG prompt」「从实物图生成同风格插画」、平台旧词/旧品牌名 0；无 keystore/local.properties/build 产物/第三方参考素材；复制后双端重建成功。
- APK 未变（31,326,016 B），签名 CN=BeanBook/label=忆杯手记/versionCode 3/versionName 1.2；安装启动 0 FATAL；IPA/zip 新 SHA 如 §24.1。

### 24.6 非阻塞 Info

1) 真实智谱视觉 Key 未实测（视觉链路用本地 OpenAI 兼容 mock 验证请求格式与 UI；建议交付后 QA 用真实 Key 点一次「测试图片理解」）。
2) 相机仅在真机出现（模拟器无相机），已通过 Info.plist 权限键、project-check 与代码路径验证；未真机实际拍照。
3) 棋盘格透明底检测为启发式；对真实模型各种棋盘纹理可能需继续调参。
4) README 实际 6 个图片引用、`screenshots/preview/` 共 23 张预览图（Lead 所述「23 张 preview 引用」口径以文件数计；图片引用均有对应文件）。
5) source zip 按约定不含 screenshots/reference/GitHub 专用发行说明 md；`dist/.DS_Store` 为系统垃圾文件不参与五项校验。
6) 本节（§24）在 source zip 打包后追加，zip 内 `qa-report.md` 为打包时快照（不含本节）。

### 24.7 结论

**0 Blocker / 0 Major，可交付。** 相机隐私键 MAJOR 已修复并独立验证（IPA/source zip/GitHub 均含 `NSCameraUsageDescription`，project-check 25/25）；最终五项 SHA/大小/版本/签名/安装；AI 插画透明底 prompt、真 alpha/纯色/棋盘格/回退四分支；实物图→视觉 prompt/本地降级→透明插画→卡片无白底；图片理解 API 设置；GitHub 文件夹 README/发行说明/无敏感/双端可重建；静态与构建全部通过。
