# 忆杯手记 iOS · 交付报告（最终版）

> 目标：编译 iOS 工程、把底部组件改成 Liquid Glass 液态玻璃、打包 IPA、用 Xcode 测试 UI 与功能，最终产出能在 iPhone/iPad 上运行的 App。
>
> 交付日期：2026-11-06 · 工程路径：`beans-app/` · iOS 工程：`ios/BeanBook.xcodeproj`

## 0. 1.2 版本（当前发行版，2026-11-07）

- **双端 1.2 已发行**：Android 已签名 APK `dist/BeanBook-v1.2-arm64.apk`（versionCode 3 / versionName 1.2，SHA256 `cf44a987…`）+
  iOS 未签名 IPA `dist/BeanBook-1.2-unsigned.ipa`（1.6 MB，arm64，SHA256 `d03008e8…`）+ 源码包 `dist/BeanBook-source-v1.2.zip`。
- **1.2 更新内容**：① 菜单里已保存的配方可编辑（双端，更新原配方不新增、取消不丢数据）；
  ② Android 视觉改为传统 Android 布局 + 澎湃 OS 4 风格导航（悬浮毛玻璃胶囊 + 4 tab + 绿色「调一杯」FAB，内外圆角同心）；iOS Tab 图标缩小约 17%；
  ③ 双端版本号 1.2；④ 追加 1.2 功能包：配方目录改名、设置页（AI API/黑暗模式/整库导入导出）、双端黑暗模式、
  每配方横版宣传卡片（设计工具 + AI 文案生成）、导出相册、Android 材料栏圆角化；
  ⑤ 二次追加「随杯卡 v2」：手绘咖啡卡版式（横版+竖版/A6 打印）、GLM-Image AI 插画、相册导入自动抠图透明背景、菜单价格字段。
- **双端验证**：iOS 在 iPhone 17 模拟器（iOS 27.2）跑通编辑闭环（保存后 3 杯不变、id/createdAt 保留、取消后 data.json 逐字节一致）、
  Debug/Release 构建成功、截图 7 张 + 缩小图标前后对比；Android 在 API 35 arm64 模拟器跑通编辑闭环、Release APK 签名校验通过、
  截图 20 张 + 胶囊导航切换 GIF。
- 完整发行说明见 [`docs/RELEASE-1.2.md`](RELEASE-1.2.md)；下文为 1.0 首次交付的完整记录（历史保留）。

## 0. 结论

- ✅ **已用真实 Xcode 27.2 编译成功**：模拟器 Debug 构建 + 真机 Release 无签名构建均 `BUILD SUCCEEDED`。
- ✅ **已产出未签名 IPA**：`dist/BeanBook-1.2-unsigned.ipa`（1.6 MB，arm64，iOS 平台，minos 17.0，版本 1.2）
  - SHA256：`d03008e85a37374bee1d31101c7cc74df86c889e1c15305fa181d9d7c0cb972d`
- ✅ **已在 iOS 27.2 模拟器实际运行并逐页截图 9 张**（五个主页面 + 豆子详情 / 配方详情 / 数据与分享 / 添加豆子），
  期间未出现崩溃日志；截图见 `screenshots/ios/`（源文件 `ios/artifacts/screenshots/`）。
- ✅ **底部导航改为系统原生 `TabView`**（不再自绘）：iOS 26/27 上由系统自动提供标准 Liquid Glass Tab Bar
  与点击时在入口之间滑动/弹出的大号透明玻璃选中滑块（与 Apple Music / News 等系统 App 的实现一致，
  动画、材质、可访问性全部由系统保证）。详情页隐藏系统 Tab Bar，改用悬浮圆角玻璃操作条 `BottomActionBar`。
  iOS 17–25 自动使用系统经典 Tab Bar；iPad 使用系统自适应侧栏。
  已在 **iPhone 17 模拟器（iOS 27.2）** 上实测：系统 TabView 呈现为底部 Liquid Glass Tab Bar，
  选中项由系统绘制玻璃滑块并在切换时原生滑动/变形（录屏逐帧 GIF：`screenshots/ios/nav-slide.gif`）。
- ⚠️ **唯一剩余步骤：装到真机需要 Apple ID 签名**（免费账号 7 天，Sideloadly/AltStore/Xcode 均可）。
  **打包 IPA 本身不需要 Apple ID**，签名只在安装时发生，这是 iOS 平台强制要求。
- ✅ **独立评审最终结论：0 Blocker / 0 Major，可交付**；最终 IPA 的 SHA256 已由 QA 与评审分别独立核验一致。
- ℹ️ 本轮模拟器为 iPhone Duo（折叠屏）单机型；常规 iPhone、iPad、iOS 17–18 回退渲染、Reduce Transparency/Increase Contrast、
  FAB 状态切换录屏等视觉项，建议后续在真机/对应模拟器上抽检（见 §4）。

## 1. 环境核验

初始环境只有 Command Line Tools、无 Xcode、无 sudo；用户随后通过 App Store 安装了 **Xcode 27.2（27B52）**，
完成 License 接受与 first-launch 组件安装后：

```text
xcodebuild -version  → Xcode 27.2 / Build version 27B52
iPhoneOS SDK         → iPhoneOS27.2.sdk
Simulator Runtime    → iOS 27.2 (24B91014)，约 8.05 GB（已下载安装）
```

从 App Store 下载 Xcode 需要 Apple ID 登录，但**之后编译、模拟器运行、打包未签名 IPA 都不需要 Apple ID**。

## 2. 交付内容

### 2.1 iOS 26 Liquid Glass 底部组件

| 文件 | 改动 |
| --- | --- |
| `ios/BeanBook/Theme.swift` | 新增 `liquidGlassStyle(...)`、`LiquidGlassSurface` 修饰器（iOS 26 系统玻璃 / iOS 17–25 毛玻璃回退）、共享 `BottomActionBar`（iOS 26 悬浮圆角玻璃条 / 旧系统全宽 material） |
| `ios/BeanBook/RootView.swift` | 根视图改为**系统原生 `TabView`**（5 个 `.tabItem`，每个 Tab 各自 `NavigationStack` 保留页面状态）；iOS 26/27 自动获得系统 Liquid Glass Tab Bar + 原生选中玻璃滑块动画；详情页 `.toolbar(.hidden, for: .tabBar)` 隐藏系统 Tab Bar；Debug 保留 `-uiTestTab` / `-uiTestRoute` / `-uiTestAutoCycle` 截图辅助参数（Release 已剔除） |
| `ios/BeanBook/BeanDetailView.swift`、`BeanEditorView.swift`、`RecipeDetailView.swift` | 底部操作条统一改用 `BottomActionBar`（实测渲染为悬浮圆角玻璃条） |
| `ios/BeanBook/Store.swift` | 修掉一个真实编译错误：`@Published data` 在 `draft` 初始化前被读取 → 改为局部常量 `initialData` 后分别赋值（语义等价） |

设计要点：部署目标保持 **iOS 17.0**；`#if compiler(>=6.2)` + `#available(iOS 26.0, *)` 双门禁，Xcode 16– 可编译但自动回退毛玻璃；
玻璃只用于控件层，不做大面积背景（iPad 侧栏保持 material）。

### 2.2 构建 / 截图 / 打包脚本（`ios/scripts/`）

| 脚本 | 作用 |
| --- | --- |
| `build-all.sh` | 一键：模拟器 Debug 构建 → 模拟器逐页/详情页截图 → 真机 Release 无签名构建 → IPA + SHA256 |
| `build-simulator.sh` | 模拟器构建，自动选可用 iPhone 模拟器（17/16 优先） |
| `run-simulator-screenshots.sh` | boot/bootstatus → 安装 → 冷启动预热 → `-uiTestTab` 逐页启动 → `simctl io screenshot`；支持 `--routes`（bean/recipe/data/newbean 详情页）、`--display`/`SIM_DISPLAY`（折叠屏双显示器自动检测） |
| `build-device-unsigned.sh` | Release/iphoneos，`CODE_SIGNING_ALLOWED=NO` 等完全跳过签名 |
| `package-ipa.sh` | `Payload/BeanBook.app` → `dist/BeanBook-<版本>-unsigned.ipa` + SHA256；可选 `--sign/--profile` 本机重签名 |

### 2.3 GitHub Actions 流水线

`.github/workflows/ios-unsigned.yml`（**Build unsigned iOS IPA & screenshots**）：`macos-26` runner、自动选最新 Xcode、
`require_liquid_glass`（默认 true，Xcode<26 硬失败）、模拟器构建 + 截图、真机 Release 无签名构建、IPA+SHA256、artifact + Job Summary。

### 2.4 本地 QA 工具（`tools/model-tests/`）

| 工具 | 作用 | 结果 |
| --- | --- | --- |
| `run-tests.sh` | 真实编译 `Models.swift`（+从 Store.swift 抽取 DemoData）成 macOS 可执行测试 | **211 PASS / 0 FAIL** |
| `glass-typecheck/check-glass-api.sh` | Liquid Glass API typecheck + `#if compiler`/`#available` 双门禁审计 + 旧 Xcode 回退审计 | **6 PASS / 0 FAIL**（9 处 API 全部双门禁，NO_LEAK） |
| `project-check.sh` | plist / pbxproj Sources / Info.plist / AppIcon / 权限键 | **24 PASS / 0 FAIL** |

## 3. 验证结果（全部真实执行）

### 3.1 真实 Xcode 27.2 构建（2026-11-06 21:40 起）

| 步骤 | 命令 | 结果 |
| --- | --- | --- |
| 模拟器 Debug | `xcodebuild … -sdk iphonesimulator -destination 'generic/platform=iOS Simulator'` | **BUILD SUCCEEDED**（0 error） |
| 真机 Release 无签名 | `bash ios/scripts/build-device-unsigned.sh` | **EXIT 0**，`BeanBook.app` arm64 / platform iOS / minos 17.0 |
| 打包 IPA | `bash ios/scripts/package-ipa.sh` | **`dist/BeanBook-1.2-unsigned.ipa`**（1.6 MB）+ `.sha256` |
| IPA 校验 | `unzip` / `file` / `codesign -dv` | arm64 Mach-O、platform 2(iOS)、minos 17.0、**未签名** |
| Liquid Glass 编入确认 | `nm` undefined symbols | iOS 26+ 系统 Tab Bar 的玻璃由系统实现；App 侧剩余 6 个 Glass 符号来自详情页悬浮操作条（`liquidGlassSurface`/`glassEffect`） |

编译期修复：`Store.swift` 初始化顺序错误（真实编译才会暴露）；打包脚本 SIGPIPE 误报 bug（`unzip -l | grep -q` 在 `pipefail` 下 50 次里 33 次失败 → 已改为先落清单再 grep，修复后 50/50 通过）。

### 3.2 模拟器 UI 实测（iOS 27.2 Simulator，iPhone Duo）

`bash ios/scripts/run-simulator-screenshots.sh --sim "iPhone Duo" --skip-build` 端到端跑通，产出 9 张截图：

| 截图 | 内容 |
| --- | --- |
| `screenshots/ios/home.png` | 首页（玻璃底栏 + 青柠玻璃「调一杯」未选中态） |
| `screenshots/ios/beans.png` | 豆仓（彩色豆卡从玻璃后透出） |
| `screenshots/ios/maker.png` | 调一杯（中央按钮选中态=实心墨黑圆，玻璃底栏在其下方） |
| `screenshots/ios/menu.png` | 菜单（选中态 tab pill） |
| `screenshots/ios/stats.png` | 统计（深色数据卡滑到玻璃底栏后面） |
| `screenshots/ios/route-bean.png` | 豆子详情 + 悬浮玻璃操作条「编辑 / 调一杯」 |
| `screenshots/ios/route-recipe.png` | 配方详情 + 悬浮玻璃操作条「分享文件 / 再调一杯」 |
| `screenshots/ios/route-data.png` | 数据与分享 |
| `screenshots/ios/route-newbean.png` | 添加豆子 + 悬浮玻璃操作条「收进豆仓」 |


- 运行期日志无 crash/fatal（仅 CoreFSCache/BoardServices 等无害系统日志）；App 多次启动/切换页面稳定。
- 截图脚本已加「冷启动预热」：刚安装后第一次启动可能先渲染白屏，脚本现在先预热再截图，
  用 `uninstall → 重新安装 → 截图` 复测 home.png 正常。
### 3.3 最终 UI 实拍（iPhone 17 模拟器，1206×2622）

- 截图为 **iPhone 17（iOS 27.2）**：系统底部 Tab Bar、五页内容与四个详情页全部正常渲染；详情页自动隐藏系统 Tab Bar，
  底部显示悬浮圆角玻璃操作条。
- 导航切换为**系统原生动画**：录屏逐帧显示选中玻璃滑块从「首页」平滑移动到「豆子」，无自绘滑块、无双影/跳变
  （`screenshots/ios/nav-slide.gif`，过渡帧原始图见 `ios/artifacts/screenshots/nav-slide-transition-sheet.png`）。
- 本轮同时修复：`RootView` 详情页导航归属 Bug（首页/调一杯进入的详情页之前被压进错误的 Tab 栈，导致「点不动」）；
  `MakerView` 窄屏布局（杯子固定 260pt 会横向溢出、底部原料托盘贴边、杯子被拉得过长）
  → 杯子改为自适应宽高比（约 1:1.55）、托盘左右留边 14pt、主区域左右留白 24pt、移除旧自绘底栏的 92pt 底部留白。
- 修复「原料托盘左右划不动」：原料卡片原来的 `LongPressGesture.sequenced(before: DragGesture(minimumDistance: 0))`
  会吞掉横向滑动手势 → 改为纯长按手势（长按成功开始倒入、松手停止；移动超过最大距离即失败，ScrollView 正常接管滑动）。
- 实测中发现并修复 2 个真实 UI 问题：
  1. 早期自绘底栏的选中按钮/文字对比度问题已随「改用系统原生 TabView」整体消除（系统保证材质、层级与可访问性）；
  2. 详情页底部操作条改为共享 `BottomActionBar`（iOS 26 悬浮圆角玻璃 / 旧系统全宽 material）。

### 3.4 静态与可执行测试（源码最终版）

| 检查 | 结果 |
| --- | --- |
| `swiftc -parse` 17 个 Swift 文件 | 17/17 PASS |
| 数据层可运行测试 | 211 PASS / 0 FAIL |
| 工程静态校验 | 24 PASS / 0 FAIL |
| Liquid Glass API + 双门禁 + 旧 Xcode 回退 | 6 PASS / 0 FAIL（GATING 9 处、NO_LEAK） |
| 5 个脚本 `bash -n`、workflow YAML、plist | 全部通过 |
| IPA 打包端到端 | 合法 `Payload/BeanBook.app`，SHA256 与 `.sha256` 一致 |

## 4. 剩余事项（需 Apple ID，非代码问题）

1. **真机安装签名**：用 Sideloadly/AltStore 对 `dist/BeanBook-1.2-unsigned.ipa` 自签（免费 Apple ID，7 天有效），
   或在 Xcode 登录 Apple ID 后直接 Run 到真机（免费账号同样 7 天）。
2. **视觉抽检（非阻塞）**：常规 iPhone（874pt 高、home indicator/状态栏垂直节奏）、iPad（侧栏 material 布局 + 宽屏详情条）、
   iOS 17–18 旧运行时回退渲染、系统「降低透明度 / 增强对比度」、FAB 选中/未选中切换录屏、深色豆袋照片滑过底栏时的可读性。
3. 若要上架 TestFlight / App Store：需要付费 Apple Developer 账号（99 美元/年）。

## 5. 产物与复现命令

```bash
cd beans-app
# 一键：模拟器构建 + 截图 + 真机无签名构建 + IPA
bash ios/scripts/build-all.sh
# 或分步：
bash ios/scripts/build-simulator.sh
bash ios/scripts/run-simulator-screenshots.sh --skip-build   # 可用 --routes "bean recipe data newbean"
bash ios/scripts/build-device-unsigned.sh
bash ios/scripts/package-ipa.sh
```

产物：

| 路径 | 说明 |
| --- | --- |
| `dist/BeanBook-1.2-unsigned.ipa` + `.sha256` | 未签名 IPA（arm64，SHA256 `72bc07d7…`） |
| `screenshots/ios/*.png` | 9 张模拟器 UI 实拍截图 |
| `ios/artifacts/screenshots/` | 截图原始输出 + `build-info.txt` |
| `ios/build/Build/Products/{Debug-iphonesimulator,Release-iphoneos}/BeanBook.app` | 构建产物 |
| `.github/workflows/ios-unsigned.yml` | 云端构建流水线（macos-26） |

## 6. 相关文档

- 构建/安装说明：[`ios/README-IOS.md`](../ios/README-IOS.md)
- QA 报告（含真实 Xcode 构建复核 + 模拟器 UI 实测）：[`docs/qa/qa-report.md`](qa/qa-report.md)
- Liquid Glass 独立评审：[`docs/reviews/liquid-glass-review.md`](reviews/liquid-glass-review.md)
