# Liquid Glass 实现独立评审

- **评审对象**：`beans-app` iOS App（`ios/BeanBook/`，`IPHONEOS_DEPLOYMENT_TARGET = 17.0`，`SWIFT_VERSION = 5.0`，`Info.plist` 强制 `UIUserInterfaceStyle = Light`）
- **评审范围**：`Theme.swift`、`RootView.swift`、`BeanDetailView.swift`、`BeanEditorView.swift`、`RecipeDetailView.swift`（`Components.swift` 未改动）
- **评审方式**：
  1. Apple 官方文档 JSON **原文**核对（2026-11-06 抓取，见附录 A）；
  2. 用本机 **macOS 26/27 SDK + Swift 6.4** 对「逐字抽取的最终代码」做 **真实 typecheck**（4 种变体，见第 2 节）；
  3. 全部 17 个 Swift 文件 `swiftc -parse`。
- **限制**：本机只有 Command Line Tools，**没有 iOS SDK / Xcode**，无法做 iOS 目标编译与真机渲染。编译结论来自 macOS 26 SDK（与 iOS 26 同一套 SwiftUI Glass API）以及 iOS 26↔macOS 26 availability 等价映射；视觉结论中凡不确定处均标注「需实机确认」。
- **评审时间**：2026-11-06 20:37 CST（文件时间戳：Theme/RootView 20:32–20:33，三个详情页 20:31，评审期间未再变动）

---

## 0. 结论摘要

| 级别 | 数量 | 说明 |
| :--- | :--- | :--- |
| **Blocker** | **0** | 未发现会导致编译失败或崩溃的写法。iOS 26 API 可用性包裹、`#if compiler(>=6.2)` 回退路径、ViewBuilder/泛型/`@Namespace` 类型均实测通过 |
| **Major** | **5** | 全部集中在 **iOS 26 真机视觉/可读性/大面积玻璃**，属于「合并前应处理或至少实机确认」的项 |
| **Minor** | **8** | 可维护性、无障碍、流程与冗余 |

> 一句话结论：**编译与 iOS 17 回退是干净的（可以放心交付构建）**；风险在 iOS 26 的观感——最需要处理的是「玻璃上的灰色小字对比度」和「iPad 侧栏整块玻璃」，其次是中央按钮选中态与详情页全宽直角玻璃条，最后是 bar 与 FAB 在同一容器内的常态融合观感（必须实机看一眼）。
>
> **第二轮复核（修正后，见 §7）**：原 5 条 Major 已全部落实修正，复核为 **0 Blocker / 0 Major / 2 个可选 Minor（需实机确认观感）→ 可以交付构建**。
>
> **第三轮真实截图评审（Xcode 27.2 + iOS 27.2 模拟器，见 §8）**：真实渲染确认 **M2/M4/M5 与玻璃质感通过**；但 **M1 实测仍未达 AA（未选中 tab 文字 2.87:1）**，是唯一 Major，给出一行修正（§8.3）。全局 **0 Blocker**。
>
> **第四轮（M1 修正后复测，见 §8.6）**：未选中 tab 文字实测 **6.00:1（干净玻璃）/ 5.28–6.14:1（彩色内容透出）**，AA 通过 → **M1 关闭**；其余部件无回归；IPA SHA256 与 15 个 Glass 符号均独立核验通过。最终：**0 Blocker、0 Major → 可以交付**。
>
> **第五轮（底部导航重设计：5 等分 + 滑动玻璃滑块，见 §9）**：真实截图/GIF 确认形态、几何、位置、可读性（AA 通过）、动画无跳变；**0 Blocker / 1 Major**（滑块是第二层 glassEffect 嵌套在底栏玻璃内，未用 GlassEffectContainer——规范/性能项，视觉不明显，给出一行式修正 A）/ 6 Minor。详情页未受影响（route-* MD5 与上轮一致）。
>
> **第六轮（改用系统原生 TabView，见 §10）**：App 不再自绘底栏/滑块 → §9 的 **M9-1 双层玻璃问题关闭**；详情页「隐藏 Tab Bar + 悬浮玻璃操作条」渲染无回归（route-* MD5 与上轮逐字节一致）；IPA/Release 清理核验通过。**0 Blocker / 1 Major**（新发现 **M10-1**：`destination()` 里硬编码目标 Tab，从 Home/Maker 打开的详情页再点「编辑/打开豆子」会被压进别的 Tab 栈、表现为点不动——10 行重构可修）/ 3 Minor / 5 Info（当前 dist IPA 已按 23:01 重建：`1e2b4439…` / 953,735 B）。
>
> **第七轮（最终复审，iPhone 17 真机形态 + M10-1/MakerView 修复，见 §11）**：iPhone 17 / iOS 27.2 截图确认**系统原生底部 Liquid Glass Tab Bar + 大号透明玻璃选中滑块**（transition sheet 16 帧显示系统滑块 morph/slide 动画）；M10-1 修复正确、MakerView 过长/拥挤修复；IPA 复核通过（956,555B / `335e3017…`）。最终：**0 Blocker、0 Major / 1 Minor → 可以交付**。

---

## 1. Apple 官方 API 权威清单（第一手核对）

来源为 Apple 文档站的结构化 JSON（`https://developer.apple.com/tutorials/data/documentation/swiftui/...`，抓取日期 2026-11-06；网页版 URL 列在下表「来源」列）。

### 1.1 `Glass` 结构体

| 项目 | 官方声明 / 结果 | 可用性 | 来源 |
| :--- | :--- | :--- | :--- |
| 类型 | `struct Glass`，遵循 `Equatable`、`Sendable`、`SendableMetatype` | **iOS 26.0+**（iPadOS/Mac Catalyst/macOS/tvOS/watchOS 26.0+） | [Glass](https://developer.apple.com/documentation/swiftui/glass) |
| 常规/通透/无效果变体 | `static var regular: Glass`、`static var clear: Glass`、`static var identity: Glass` | iOS 26.0+ | [Glass/regular](https://developer.apple.com/documentation/swiftui/glass/regular)、[clear](https://developer.apple.com/documentation/swiftui/glass/clear)、[identity](https://developer.apple.com/documentation/swiftui/glass/identity) |
| 着色 | `func tint(_ color: Color?) -> Glass`（**参数可空**，非链式可变） | iOS 26.0+ | [Glass/tint(_:)](https://developer.apple.com/documentation/swiftui/glass/tint(_:)) |
| 交互 | `func interactive(_ isEnabled: Bool = true) -> Glass`（**默认 true**） | iOS 26.0+ | [Glass/interactive(_:)](https://developer.apple.com/documentation/swiftui/glass/interactive(_:)) |
| 默认形状 | `struct DefaultGlassEffectShape`，抽象说明：**"The default shape applied by glass effects, a capsule."**（默认是胶囊形，不要直接使用该类型） | iOS 26.0+ | [DefaultGlassEffectShape](https://developer.apple.com/documentation/swiftui/defaultglasseffectshape) |

### 1.2 `View.glassEffect(_:in:)`

官方声明（原样，含默认值）：

```swift
nonisolated func glassEffect(
    _ glass: Glass = .regular,
    in shape: some Shape = DefaultGlassEffectShape()
) -> some View
```

- 可用性：**iOS 26.0+**（全平台 26.0+）。来源：[View/glassEffect(_:in:)](https://developer.apple.com/documentation/swiftui/view/glasseffect(_:in:))
- 苹果示例用法（同时确认了 `in:` 可省略第一个默认参数）：
  ```swift
  Text("Hello, World!").font(.title).padding().glassEffect()
  Text("Hello, World!").font(.title).padding().glassEffect(in: .rect(cornerRadius: 16.0))
  Text("Hello, World!").font(.title).padding().glassEffect(.regular.tint(.orange).interactive())
  ```

### 1.3 `GlassEffectContainer`

官方声明（原样）：

```swift
@MainActor @preconcurrency
struct GlassEffectContainer<Content> where Content : View

@MainActor @preconcurrency
init(spacing: CGFloat? = nil, @ContentBuilder content: () -> Content)
```

- 可用性：**iOS 26.0+**。来源：[GlassEffectContainer](https://developer.apple.com/documentation/swiftui/glasseffectcontainer)、[init(spacing:content:)](https://developer.apple.com/documentation/swiftui/glasseffectcontainer/init(spacing:content:))
- 注意 1：`spacing` 默认 **nil**；**越大越早融合**。
- 注意 2：content 参数用的是 **`@ContentBuilder`**（不是 `@ViewBuilder`），trailing closure 用法不受影响。

### 1.4 `View.glassEffectID(_:in:)`

官方声明（原样）：

```swift
nonisolated func glassEffectID(
    _ id: (some Hashable & Sendable)?,
    in namespace: Namespace.ID
) -> some View
```

- 可用性：**iOS 26.0+**。来源：[View/glassEffectID(_:in:)](https://developer.apple.com/documentation/swiftui/view/glasseffectid(_:in:))
- 注意：id 是 **Optional** 的 `some Hashable & Sendable`；与 `GlassEffectContainer`、`glassEffect(_:in:)` 配套，**只在视图层级变化/转场时生效**。
- 潜在坑（本项目未触发）：直接写 `.glassEffectID(nil, in: ns)` 时泛型无法从 `nil` 推断，会报 `generic parameter could not be inferred`；应写 `.glassEffectID(selectedID, in: ns)`（`selectedID: String?`）或显式 `Optional<String>.none`。当前代码只传 `String` 字面量，无此问题。

### 1.5 `GlassEffectTransition` 与 `View.glassEffectTransition(_:)`

```swift
struct GlassEffectTransition                     // iOS 26.0+
static var materialize: GlassEffectTransition    // 淡入 + 玻璃材质动画，不做几何匹配
static var matchedGeometry: GlassEffectTransition// 容器内就近形状几何匹配（容器 spacing 内默认）
static var identity: GlassEffectTransition       // 无过渡

@MainActor @preconcurrency
func glassEffectTransition(_ transition: GlassEffectTransition) -> some View   // iOS 26.0+
```

- 来源：[GlassEffectTransition](https://developer.apple.com/documentation/swiftui/glasseffecttransition)、[View/glassEffectTransition(_:)](https://developer.apple.com/documentation/swiftui/view/glasseffecttransition(_:))
- 苹果原文：`matchedGeometry` 适用于「容器 spacing 范围内」的出现/消失；`materialize` 适用于距离大于 spacing 的场景；两者都只在视图层级变化时生效。

### 1.6 按钮样式 `.buttonStyle(.glass)` / `.glassProminent`

| 项目 | 官方声明 | 可用性 | 来源 |
| :--- | :--- | :--- | :--- |
| `PrimitiveButtonStyle.glass` | `nonisolated static var glass: GlassButtonStyle { get }` | iOS 26.0+ | [primitivebuttonstyle/glass](https://developer.apple.com/documentation/swiftui/primitivebuttonstyle/glass) |
| `PrimitiveButtonStyle.glassProminent` | `@MainActor @preconcurrency static var glassProminent: GlassProminentButtonStyle { get }` | iOS 26.0+ | [primitivebuttonstyle/glassprominent](https://developer.apple.com/documentation/swiftui/primitivebuttonstyle/glassprominent) |
| 类型本体 | `nonisolated struct GlassButtonStyle` / `nonisolated struct GlassProminentButtonStyle` | iOS 26.0+ | [GlassButtonStyle](https://developer.apple.com/documentation/swiftui/glassbuttonstyle)、[GlassProminentButtonStyle](https://developer.apple.com/documentation/swiftui/glassprominentbuttonstyle) |

- 用法确认：`Button("A") {}.buttonStyle(.glass)` 合法（`.glass` 是 `PrimitiveButtonStyle` 扩展上的静态属性，`buttonStyle` 的泛型参数 `S: PrimitiveButtonStyle` 可推断）；项目已用 typecheck 实证（附录 B 变体 A）。
- `.glassProminent` 声明带 `@MainActor`，只能在主线程隔离上下文调用（`View.body` 内天然满足）。

### 1.7 补充 API（本次未用，但评审时值得知道）

- `View.glassEffectUnion(id: (some Hashable & Sendable)?, namespace: Namespace.ID)`（iOS 26.0+）：让多个玻璃几何合并成一个形状，适合动态生成/不在布局容器里的视图。
- 苹果《Applying Liquid Glass to custom views》明确要求：
  - **多个玻璃效果应放进 `GlassEffectContainer` 以获得最佳渲染性能**；
  - `glassEffect(_:in:)` 要**放在影响外观的其它修饰符之后**；
  - **限制同屏玻璃数量**；容器与效果过多会降低性能；
  - `.glassEffectID`/`.glassEffectTransition` 只在视图层级变化或动画时起作用。

> 第一手结论：任务里要求核对的 6 组 API **签名与可用性全部属实**，项目的调用写法（`.glassEffect(.regular, in: RoundedRectangle(...))`、`.glassEffect(liquidGlassStyle(...), in: Circle())`、`.glassEffectID("...", in: ns)`、`GlassEffectContainer(spacing: 18)`）与官方一致，没有用错版本。

---

## 2. 本机独立验证（无 Xcode 下能做到的最强证据）

### 2.1 方法与材料

1. 从**最终文件**逐字抽取：`Theme.swift` 的 Liquid Glass 段（`supportsLiquidGlass` 起）+ `RootView.swift` 的 `AppTab`、`SideRail`、`BottomBar`，补最小桩（`C` 颜色、`Font.mono`）→ `/tmp/glass-check/FinalCode.swift`（388 行）。
2. 用本机 SDK（`/Library/Developer/CommandLineTools/SDKs/MacOSX27.sdk`，Swift 6.4）对抽取代码做 `swiftc -typecheck -swift-version 5`（与工程 `SWIFT_VERSION = 5.0` 一致）。
3. 设计 4 个变体分别验证不同假设：

| 变体 | 目标平台 | 验证内容 | 结果 |
| :--- | :--- | :--- | :--- |
| **A** | `arm64-apple-macosx26.0` | iOS 26 API 的真实签名与封装写法（Glass/Container/ID/修饰器泛型/ViewBuilder） | ✅ **0 error 0 warning** |
| **B** | `arm64-apple-macosx17.0`，把源码中 `iOS 26.0` 机械替换为 `macOS 26.0` | 部署目标 17 时 `#available` 包裹是否**完整**（等价于 iOS 17 目标下的 availability 结构） | ✅ **0 error**（说明所有 26 API 都在 `#available` 内，iOS 17 回退分支无泄漏） |
| **C** | `arm64-apple-macosx17.0`，把 `#if compiler(>=6.2)` 替换为恒假条件 | **模拟 Xcode 16（Swift < 6.2）**：玻璃整段被剔除后，回退路径可否独立编译、是否还引用 iOS 26 符号 | ✅ **0 error**（`#if` 包属性声明、`#if` 在 `@ViewBuilder` 内均合法） |
| **D** | 本机 SDK | 全工程 17 个 `ios/BeanBook/*.swift` `swiftc -parse` | ✅ **17/17 通过** |

> 说明：变体 B/C 用 macOS 平台名替换，只是把 **iOS 16/17 的 availability 语义映射到 macOS**（两平台的 SwiftUI 版本门槛一致：Glass API 均 26.0+），不是对 iOS 编译结果的替代；但它能真实暴露「26 符号未包裹」「回退分支引用 26 符号」这两类错误。

### 2.2 `#if compiler(>=6.2)` 包裹审计（逐行）

| 检查 | 结果 |
| :--- | :--- |
| iOS 26 专有符号出现行数 | Theme.swift 3 行 / RootView.swift 6 行，**9/9 全部位于 `#if compiler(>=6.2)` 内** |
| `#if compiler` / `#else` / `#endif` 配对 | Theme 2 组、RootView 3 组，**全部配对且嵌套正确** |
| 旧编译器路径（变体 C）引用 iOS 26 符号 | **0 处**（玻璃分支、`glassBar`、`liquidGlassStyle`、`makerLabel` 玻璃分支已被整体剔除） |
| `#if DEBUG` + `@ViewBuilder` + `#if compiler` 组合 | **合法**；`#if compiler` 包住 `private var glassBar` 属性声明、`makerLabel` 内 `#if` 分支均通过变体 C 实测 |

### 2.3 结论

**编译层面：0 Blocker。** 只要用 **Xcode 26+ 编译**，iOS 26 分支可编译；用 **Xcode 16 及更早编译**，`#if compiler(>=6.2)` 会把玻璃整段剔除、编译回退路径（变体 C 实证）。任务清单里点名的几个风险点逐条结论见第 3 节。

---

## 3. 编译/可用性逐条核查（任务清单逐项）

| # | 检查项 | 结论 | 依据 |
| :--- | :--- | :--- | :--- |
| 1 | iOS 26 符号是否全部在 `#if compiler(>=6.2)` 内 | ✅ PASS | 逐行审计 9/9，见 2.2 |
| 2 | iOS 17 回退分支是否引用 iOS 26 符号 | ✅ PASS（无引用） | 变体 C 在目标 17 下编译通过且无 `Glass` 符号 |
| 3 | `#available(iOS 26.0, *)` 包裹是否完整 | ✅ PASS | 变体 B：目标 17 时只有 `#available` 分支内能用 26 API |
| 4 | `@Namespace` 类型 | ✅ PASS | `@Namespace private var glassNamespace` 得到 `Namespace.ID`，与 `glassEffectID(_:in:)` 第二参匹配（变体 A） |
| 5 | `@ViewBuilder` 分支返回类型 | ✅ PASS | `Group { if #available {...} else {...} }`、`glassBar`/`makerLabel` 的 `_ConditionalContent` 类型正确（A/C 变体） |
| 6 | 泛型 `Shape` 推断 | ✅ PASS | `LiquidGlassSurface<S: Shape>` 以 `Rectangle()`/`RoundedRectangle(...)`/`Circle()` 实例化，`in shape: some Shape` 传参无问题（A/B/C） |
| 7 | `@MainActor` 隔离 | ✅ PASS | `GlassEffectContainer` 为 `@MainActor @preconcurrency`，在 `View.body` 内构造合法；`glassEffect` 本身 `nonisolated`；工程无 strict concurrency，Swift 5 模式无告警 |
| 8 | 旧系统回退是否与原来一致 | ✅ **PASS（布局/视觉等价）** | 与改动前快照逐字 diff：SideRail、底栏、三页操作条的 fallback 仅「material→material」；差异只有新增 `.animation`、`accessibilityIdentifier/Label`、`contentShape`，见 m3 |
| 9 | `.animation(.snappy(duration:))` 的可用性 | ✅ PASS | `snappy` 为 iOS 17.0+，部署目标正好 17.0 |
| 10 | `#if DEBUG` 启动参数 | ✅ PASS | `#if DEBUG` 内读 `ProcessInfo`，Release 返回 nil；CI 需构建 Debug（截图脚本已如此） |
| 11 | 工程文件一致性 | ✅ PASS | 未新增 Swift 文件；17 个 `.swift` 全部在 `PBXSourcesBuildPhase` 中；`project.pbxproj`/`Info.plist` 无需改动 |
| 12 | 玻璃修饰符的调用顺序 | ✅ PASS | `glassEffect` 均放在 `frame`/`foregroundStyle`/`padding` 之后（符合苹果「放在影响外观的修饰符之后」） |

> 结论：**没有 Blocker**。`#if compiler(>=6.2)` 这个防御是有效的（Xcode 26.0 = Swift 6.2；Xcode 16.4 = Swift 6.1，门槛对应关系正确），配合 `#if DEBUG`、`@ViewBuilder` 没有引入编译问题。

---

## 4. 问题清单

### 4.1 Blocker（0）

无。

### 4.2 Major（5）

#### M1. 玻璃上的固定灰色小字对比度不足（`RootView.swift:381-401` 等）

- **现状**：底栏 tab 未选中文字/图标为 `C.muted`（`#8E897E`），9pt；侧栏未选中为 14pt `C.muted`。在 `ultraThinMaterial` 上已经是弱对比，在 **Liquid Glass 上会随身后滚动内容动态变色**，风险放大。
- **量化**（WCAG 2.1，`C.muted` = `#8E897E`）：

  | 前景/背景 | 对比度 | 9–14pt 正文要求 |
  | :--- | :--- | :--- |
  | muted / 纸底 `#EDECE7` | **2.94 : 1** | ❌ < 4.5 |
  | muted / 玻璃下纸底 `#F3F2EE` | **3.11 : 1** | ❌ < 4.5 |
  | muted / 卡片 `#FBFAF7` | 3.34 : 1 | ❌ < 4.5 |
  | inkSoft `#48433C` / 玻璃下纸底 | 8.75 : 1 | ✅ |
  | ink `#26231F` / 玻璃下纸底 | 13.96 : 1 | ✅ |

- **影响**：底栏覆盖在滚动内容上（Beans 页彩色豆袋图、Maker 页杯体、Stats 图表都会从玻璃下方滑过），固定灰字在深色/彩色内容经过时可能短暂不可读。苹果对玻璃上内容推荐用 **层级前景样式（`.primary`/`.secondary`）**获得系统 vibrancy，而不是写死低对比度品牌灰。
- **修正（可直接粘贴，已 typecheck 通过）**：

  ```swift
  // RootView.swift → BottomBar
  private func tabButton(_ tab: AppTab) -> some View {
      Button {
          onSelect(tab)
      } label: {
          tabLabel(tab)
      }
      .buttonStyle(.plain)
      .accessibilityLabel(tab.label)
      .accessibilityIdentifier("tab_\(tab.rawValue)")
      .accessibilityAddTraits(selected == tab ? .isSelected : [])   // 顺带修 m6
  }

  private func tabLabel(_ tab: AppTab) -> some View {
      VStack(spacing: 3) {
          ZStack {
              Circle()
                  .fill(selected == tab ? C.limeSoft : Color.clear)
                  .frame(width: 31, height: 31)
              Image(systemName: tab.symbol)
                  .font(.system(size: 17, weight: .medium))
          }
          Text(tab.label).font(.system(size: 9, weight: .medium))
      }
      .frame(maxWidth: .infinity, maxHeight: .infinity)
      .foregroundStyle(tabForeground(tab))
  }

  /// iOS 26 玻璃上交给系统 vibrancy；旧系统保持原来的品牌灰
  private func tabForeground(_ tab: AppTab) -> AnyShapeStyle {
      if #available(iOS 26.0, *) {
          return tab == selected
              ? AnyShapeStyle(C.ink)
              : AnyShapeStyle(HierarchicalShapeStyle.secondary)
      }
      return tab == selected ? AnyShapeStyle(C.ink) : AnyShapeStyle(C.muted)
  }
  ```

  同页侧栏（`SideRail`，`RootView.swift:218`）如保留玻璃也建议同样处理；若采纳 M3 回退 material，则侧栏可维持 `C.muted`（但 3.11:1 仍偏低，建议改 `C.inkSoft`）。

  > 备选（改动更小）：仅把玻璃分支的未选中前景改为 `C.inkSoft`（8.75:1），无需 vibrancy，但观感偏重。

#### M2. 中央「调一杯」选中态：lime 在 ink-tinted 玻璃上的对比度不可控（`RootView.swift:344-360`）

- **现状**：iOS 26 分支把按钮做成 `glassEffect(liquidGlassStyle(tint: selected ? C.ink : C.lime, interactive: true), in: Circle())`，选中时前景是 `C.lime`。
- **旧版实测**（实心底，有保证）：lime/ink = **8.45 : 1**，ink/lime = **8.45 : 1**，都达标。
- **iOS 26 风险**：Liquid Glass 的 `tint` 是「给材质着色」而非实心填充，**玻璃仍会透光/折射身后纸底**；`C.ink` 深色 tint 在浅色背景下最终呈现的是「偏灰的半透明玻璃」，`C.lime`（亮度高）在其上能否达到 3:1 取决于实际渲染（无法在本机渲染验证）。iOS 26 的真机效果必须确认，否则品牌选中态可能「发灰、文字发飘」。
- **修正方案 A（最稳，保留品牌 lime，已 typecheck）**：选中态继续用实心 ink 圆（对比度回到 8.45:1），未选中用玻璃，观感上「选中=实心、未选中=玻璃」也成立：

  ```swift
  @ViewBuilder
  private var makerLabel: some View {
      #if compiler(>=6.2)
      if #available(iOS 26.0, *) {
          if selected == .maker {
              // 选中：保留原实心 ink 圆 —— lime 图标 8.45:1，品牌色不丢
              legacyMakerLabel
          } else {
              makerContent
                  .glassEffect(.regular.tint(C.lime).interactive(), in: Circle())
                  .glassEffectID("beanbook-maker", in: glassNamespace)
          }
      } else {
          legacyMakerLabel
      }
      #else
      legacyMakerLabel
      #endif
  }
  ```

- **修正方案 B（更「系统原生」）**：用系统按钮玻璃样式，让系统保证前景/材质对比度（`.glassProminent` 在 iOS 26 上是以 tint 为主色的高不透明度玻璃）：

  ```swift
  // 选中：.buttonStyle(.glassProminent).tint(C.ink)，label 用 C.lime
  // 未选中：.buttonStyle(.glass).tint(C.lime)，label 用 C.ink
  // 注意：使用系统按钮样式后不要再叠加手写 .glassEffect；二者选其一。
  ```
  代价：会失去手写 `glassEffectID` 的形状 morph（当前两形状常驻、无层级切换，本来也用不上，见 m1）。

#### M3. iPad 侧栏整块玻璃不合适（`RootView.swift:248`）

- **现状**：`SideRail`（220pt 宽、全高）从 `.background(.ultraThinMaterial)` 改为 `.liquidGlassSurface(in: Rectangle())`，iOS 26 上就是**一整块 220×全高 的 Rectangle 玻璃**。
- **问题**：
  1. 侧栏与内容**并排**（`HStack`），玻璃后面只有静态 `PaperBackground()`，**没有可折射的内容** → 视觉收益接近 0，只剩一层偏色/镜面感；
  2. 玻璃面积大（iPad 竖屏约 220×1000pt），苹果明确要求「限制同屏玻璃数量/面积」，大面积实时玻璃是纯成本；
  3. 与侧栏的 1px 分隔线、纸质卡片体系不协调；直角贴窗口边缘，玻璃边缘高光会显得突兀。
- **修正（推荐直接回退侧栏 material；玻璃只留给浮动控件）**：

  ```swift
  // RootView.swift → SideRail（第 244-251 行）
  .padding(.horizontal, 14)
  .padding(.top, 22)
  .frame(width: 220)
  .frame(maxHeight: .infinity)
  .background(.ultraThinMaterial)        // ← 恢复：侧栏无内容可折射，玻璃无收益
  .overlay(alignment: .trailing) {
      Rectangle().fill(C.lineSoft).frame(width: 1)
  }
  ```
  > 若想保留 iOS 26 味道：只把**选中的导航行**做成玻璃 pill（更接近 iPadOS 26 系统侧栏的选中态），侧栏底板仍用 material。此时仅在选中行 label 上做 `#available` 分支，风险远小于整块玻璃。

#### M4. 三个详情页的底部操作条是全宽直角玻璃（`BeanDetailView.swift:48`、`BeanEditorView.swift:93`、`RecipeDetailView.swift:63`）

- **现状**：`.liquidGlassSurface(in: Rectangle())` 替换了原来的 `.background(.ultraThinMaterial)`，得到**贴屏幕左右边缘、直角、无外边距**的整条玻璃。
- **问题**：iOS 26 的系统玻璃工具条/按钮是「悬浮 + 圆角」形态；全宽直角玻璃在视觉上更像被裁切的材质板，左右边缘的玻璃边缘高光会被屏幕边界截断；iPad 上更宽（内容区全宽），更明显。三处代码还完全重复。
- **修正（抽成共享组件，改动集中；已 typecheck）**：在 `Components.swift` 增加：

  ```swift
  /// 底部主操作条：iOS 26 悬浮圆角 Liquid Glass；iOS 17–25 保持原全宽毛玻璃。
  struct BottomActionBar<Content: View>: View {
      @ViewBuilder var content: Content

      var body: some View {
          if #available(iOS 26.0, *) {
              content
                  .padding(.horizontal, 16)
                  .padding(.top, 10)
                  .padding(.bottom, 8)
                  .liquidGlassSurface(in: RoundedRectangle(cornerRadius: 30, style: .continuous))
                  .padding(.horizontal, 16)
                  .padding(.bottom, 8)
          } else {
              content
                  .padding(.horizontal, 20)
                  .padding(.top, 12)
                  .padding(.bottom, 10)
                  .background(.ultraThinMaterial)
          }
      }
  }
  ```

  三个页面统一改为（以 BeanDetailView 为例，其余同理）：

  ```swift
  .safeAreaInset(edge: .bottom, spacing: 0) {
      BottomActionBar {
          HStack(spacing: 10) {
              OutlineActionButton(title: "编辑", action: onEdit)
              PrimaryActionButton(title: "调一杯", action: onMake)
          }
      }
  }
  ```

  > 说明：这里用的是 `#available` 运行时分支（不含 iOS 26 符号，Xcode 16 也能编译）。极端组合「Xcode 16 编译 + iOS 26 设备」会因 `#if compiler` 而落到圆角 material（非玻璃），README 已说明此时无玻璃，可接受。
  > 若不想改布局，最低成本方案是接受现状（全宽 Rectangle），仅把 M4 记为已知视觉取舍。

#### M5. bar 与 FAB 在同一 `GlassEffectContainer` 内**几何重叠 54pt** → 常态融合（`RootView.swift:261-284`）

- **几何事实**：底栏玻璃 y = 14…78（`.padding(.top, 14)` + 64 高）；中央按钮 68×68，y = 0…68 → 两者**重叠 54pt**；容器 `spacing: 18`。
- **苹果文档原文**：「As shapes near one another, their paths start to blend into one another. The higher the spacing, the sooner blending begins…」「容器 spacing 大于内部布局间距时，玻璃效果在静止状态就会融合」。
- **结论**：当前两个玻璃形状**在静止状态必然融合**——视觉上不是「独立悬浮圆 + 底栏」，而是「底栏中央鼓出一个玻璃包」。把两者放进同一容器是处理重叠的**正确做法**（避免玻璃叠玻璃），所以不报编译/结构问题；但**必须实机确认**：融合后的形状 + 选中态 ink tint 可能在交界处产生混色/色带，破坏「调一杯」的视觉重心。
- **修正选项**（二选一，取决于想要哪种观感）：
  - **A. 接受融合**（推荐先实机看）：保持现状；把 `spacing` 从 18 调到 0–8（重叠本身已保证融合，spacing 只影响转场），并去掉选中态的深色 tint（见 M2 方案 A/B），避免融合区混色。
  - **B. 要独立圆**：FAB 也改为实心（`legacyMakerLabel`），只让底栏条用玻璃容器：

    ```swift
    if #available(iOS 26.0, *) {
        ZStack(alignment: .top) {
            GlassEffectContainer(spacing: 18) { glassBar }   // 只包玻璃条
            makerButton                                      // FAB 实心，不参与融合
        }
    }
    ```
    代价：FAB 与玻璃条重叠区会变成「实心压在玻璃上」，不再是系统融合效果（但对比度、形状可控）。

### 4.3 Minor（8）

| # | 位置 | 问题 | 建议 |
| :--- | :--- | :--- | :--- |
| m1 | `RootView.swift:312,353` | `.glassEffectID` 加在了**始终存在**的形状上；项目没有出现/消失的玻璃形状，ID 实际不产生 morph | 保留无害；真正需要转场时再配 `.glassEffectTransition(.matchedGeometry)` |
| m2 | `Theme.swift:152-155` | `supportsLiquidGlass` 全工程未使用 | 用它来切换 M1 的前景色/其它 iOS 26 专属视觉，或删除避免误解 |
| m3 | `RootView.swift:283` | 新增 `.animation(.snappy(duration: 0.28), value: selected)` 也作用于 iOS 17–25 回退路径，与改动前「瞬时切换」有细微行为差异（布局/颜色不变，只是变成动画） | 可接受；若要严格「旧系统与原来一致」，把该修饰符移进 iOS 26 分支内 |
| m4 | 三个详情页 | 同一句 `.liquidGlassSurface(in: Rectangle(), fallbackMaterial: .ultraThinMaterial)` 重复 3 次 | 见 M4，抽 `BottomActionBar` 到 `Components.swift` |
| m5 | `RootView.swift:305-318` | `glassBar` 内层又写了一遍 `if #available(iOS 26.0, *)`，其 `else legacyBar` 在 `body` 已判断的前提下不可达（冗余但无害） | 可简化为直接返回玻璃条；或保留作为防御（保留也行） |
| m6 | `RootView.swift:399-400` | tab 只有 `accessibilityLabel`/`Identifier`，没有选中态 trait | 加 `.accessibilityAddTraits(selected == tab ? .isSelected : [])`（已含在 M1 修正中） |
| m7 | 流程 | CI 的 `macos-15` runner 若未安装 Xcode 26，`#if compiler(>=6.2)` 会把玻璃整段剔除 → **CI 构建出的 IPA 不含 Liquid Glass**；CI 也无法编译验证 iOS 26 分支 | workflow 已「自动挑最新 Xcode」，条件允许时改用 `macos-26` runner（或在跑前断言 `xcodebuild -version` ≥ 26）以真正验证玻璃路径；README 已说明 Xcode 26 才生效，建议在 CI 日志里打印该判定 |
| m8 | `Theme.swift:159` 注释 | `#if compiler(>=6.2)` 是「有 iOS 26 SDK」的**实用近似**（Xcode 26.0 = Swift 6.2；Xcode 16.4 = Swift 6.1）；理论上「Swift 6.2 工具链 + 旧 SDK」的错配会让保护失效 | 概率极低，保持现状即可；README 已写明要求 |

### 4.4 提交前必须实机确认的清单（Xcode 26 + iOS 26 模拟器/真机）

1. 底栏玻璃在 **Beans（彩色豆袋图）/ Maker（杯体）/ Stats（图表）** 从下方滚过时的文字可读性（M1）。
2. 中央按钮选中/未选中两种状态的 **lime 对比度与 tint 观感**（M2）。
3. 底栏条与 FAB 融合后的形状、交界处是否出现色带/混色（M5）。
4. iPad 侧栏整块玻璃的实际观感与滚动/转场帧率（M3）。
5. 详情页全宽玻璃条左右边缘是否出现被截断的高光（M4）。
6. 系统辅助功能：**降低透明度（Reduce Transparency）/ 增强对比度** 下 `.glassEffect` 的自动降级是否仍可读（系统一般会自动适配，需确认）。
7. App 强制 Light（`Info.plist`），玻璃为浅色系；若未来放开深色模式需整体重评（当前不阻塞）。

---

## 5. 性能与 HIG 评估

| 维度 | 结论 |
| :--- | :--- |
| 同屏玻璃数量 | iPhone 根页面 **2 个**（底栏条 + FAB，同一容器内部共享渲染）；详情页 **1 个**；iPad 侧栏 **1 个（大面积）** + 详情操作条 **1 个（大面积）**。**数量合理**，没有「到处玻璃」 |
| 容器使用 | 底栏 2 个玻璃放进同一个 `GlassEffectContainer`，符合苹果「多个效果放进容器以获得最佳渲染性能」的建议 ✅ |
| 大面积玻璃 | iPad 侧栏（M3）与详情页全宽条（M4）是**面积成本**主要来源；实时玻璃的 GPU 成本随面积增长，建议按 M3/M4 收敛 |
| 双材质叠加 | iOS 26 分支**没有**同时在玻璃下再垫 `.ultraThinMaterial`（`legacyBar` 只在回退路径出现），避免了「material + glass」双重离屏合成 ✅ |
| 深浅色 | App 强制 Light，玻璃为浅色系；`C.ink`/`C.lime` 品牌色在浅色玻璃上的风险见 M1/M2。深色模式暂不涉及 |
| HIG 符合度 | 玻璃用于**导航层/浮动控件**（底栏、中央主按钮）符合 HIG；把玻璃用于**大面积背景/内容容器**（iPad 侧栏底板）偏离 HIG 的「Liquid Glass 用于控件层」定位（M3）；全宽直角玻璃条偏离系统「悬浮圆角」形态（M4） |

---

## 6. 附录

### A. 抓取的官方文档（本地缓存 `/tmp/apple-docs/`）

`glass.json`、`view/glasseffect(_:in:).json`、`glasseffectcontainer.json`、`glasseffectcontainer/init(spacing:content:).json`、`view/glasseffectid(_:in:).json`、`view/glasseffecttransition(_:).json`、`glasseffecttransition.json`、`glasseffecttransition/materialize.json`、`glasseffecttransition/matchedgeometry.json`、`glassinteractive…`、`primitivebuttonstyle/glass.json`、`primitivebuttonstyle/glassprominent.json`、`glassbuttonstyle.json`、`glassprominentbuttonstyle.json`、`defaultglasseffectshape.json`、`view/glasseffectunion(id:namespace:).json`、`applying-liquid-glass-to-custom-views.json`。

抓取命令示例：

```bash
curl -sL 'https://developer.apple.com/tutorials/data/documentation/swiftui/view/glasseffect(_:in:).json' -o glasseffect.json
```

### B. 本次 typecheck 材料与命令（可复现）

```bash
# 逐字抽取最终代码 + 最小桩 → /tmp/glass-check/FinalCode.swift
# 变体 A：验证 iOS 26 API 签名（macOS 26 SDK 与 iOS 26 同一套 SwiftUI）
swiftc -typecheck -swift-version 5 \
  -sdk /Library/Developer/CommandLineTools/SDKs/MacOSX27.sdk \
  -target arm64-apple-macosx26.0 /tmp/glass-check/FinalCode.swift

# 变体 B：验证 #available 包裹完整（把 iOS 26.0 替换为 macOS 26.0，目标 17）
sed 's/iOS 26\.0/macOS 26.0/g' FinalCode.swift > FinalCode_ios17sim.swift
swiftc -typecheck -swift-version 5 -sdk "$SDK" -target arm64-apple-macosx17.0 FinalCode_ios17sim.swift

# 变体 C：模拟 Xcode 16（compiler<6.2 恒假）
sed 's/#if compiler(>=6\.2)/#if compiler(>=999.0)/g' FinalCode.swift > FinalCode_oldcompiler.swift
swiftc -typecheck -swift-version 5 -sdk "$SDK" -target arm64-apple-macosx17.0 FinalCode_oldcompiler.swift

# 变体 D：全工程语法解析
for f in /Users/mac/Desktop/zlj/beans-app/ios/BeanBook/*.swift; do swiftc -parse "$f" || echo "FAIL $f"; done
```

结果：A ✅ 0 error / B ✅ 0 error / C ✅ 0 error / D ✅ 17/17。

补充：本报告中的修正代码片段也用同样方法 typecheck 过（`/tmp/glass-check/Fixes.swift`，macOS 26 与「iOS 17 等价」两个变体均 0 error）。

### C. 对比度计算说明

使用 WCAG 2.1 相对亮度公式（sRGB → 线性化 → 0.2126R + 0.7152G + 0.0722B）。品牌色取自 `Theme.swift` 的 `C`：ink `#26231F`、inkSoft `#48433C`、muted `#8E897E`、mutedLight `#B4AFA4`、lime `#A3CD39`、limeSoft `#EAF2CE`；纸底 `#EDECE7` / `#F3F2EE`。玻璃为半透明材质，表中用「玻璃下纸底」作为近似基准；真实玻璃会随身后内容变色，因此 M1/M2 的结论是「需实机确认下限」。

### D. 文件与行号索引（评审时点）

| 内容 | 位置 |
| :--- | :--- |
| `supportsLiquidGlass` | `ios/BeanBook/Theme.swift:152` |
| `liquidGlassStyle(tint:interactive:)`（`#if compiler(>=6.2)` 内） | `ios/BeanBook/Theme.swift:160-172` |
| `LiquidGlassSurface` + 回退 | `ios/BeanBook/Theme.swift:175-235`（分支 207-215） |
| `View.liquidGlassSurface(...)` | `ios/BeanBook/Theme.swift:238-266` |
| 启动参数 `-uiTestTab` | `ios/BeanBook/RootView.swift:41-52, 58` |
| SideRail 玻璃 | `ios/BeanBook/RootView.swift:248` |
| BottomBar `body` / 容器 | `ios/BeanBook/RootView.swift:261-284` |
| `glassBar` | `ios/BeanBook/RootView.swift:305-318` |
| `makerLabel` 玻璃分支 | `ios/BeanBook/RootView.swift:344-360` |
| `tabButton` | `ios/BeanBook/RootView.swift:381-401` |
| 三个详情页操作条 | `BeanDetailView.swift:48`、`BeanEditorView.swift:93`、`RecipeDetailView.swift:63` |

---

## 7. 第二轮：修正后复核（2026-11-06 20:44 CST）

> **复核对象**：Lead 按 §4 的 M1–M5 + Minor 修正后的最终代码（`Theme.swift` / `RootView.swift` / 三个详情页；文件时间戳 20:39–20:40，复核期间未再变动）。
> **方法**：与 §2 相同——把最终文件逐字抽取（`Theme.swift` Liquid Glass 段含新增 `BottomActionBar` + `RootView` 的 `AppTab`/`SideRail`/`BottomBar` + 详情页 `safeAreaInset` 用法 + 最小桩）组成 `FinalCode2.swift`（442 行）做 3 变体 typecheck；17 个文件 `swiftc -parse`；符号 guard 审计；CI YAML 校验。

### 7.1 复核结论

| 原问题 | 修正内容 | 复核结果 |
| :--- | :--- | :--- |
| **M1** 玻璃上 9pt 灰字 3.11:1 | `tabForeground(_:)`：iOS 26 选中 `C.ink`、未选中 `HierarchicalShapeStyle.secondary`；旧系统 `C.ink`/`C.muted` | ✅ **解决**。`.secondary` 在浅色环境约为 label 黑 60% 叠底 → 玻璃/纸底上 **5.48–5.74 : 1**（AA 通过，原 3.11）。可用性已核：`AnyShapeStyle` iOS 15.0+、`HierarchicalShapeStyle` 与 `.secondary` 均 iOS 15.0+（`foregroundStyle(_:)` iOS 15+），**iOS 17 部署目标完全可用** |
| **M2** FAB 选中态 lime/ink-tint 对比不可控 | 选中回退 `legacyMakerLabel` 实心 ink 圆；未选中 lime tint 玻璃圆 + `glassEffectID` | ✅ **对比度解决**（实心 ink 上 lime = 8.45 : 1；未选中 ink on lime-glass 维持高对比）。新引入的**状态切换过渡观感**见 7.3-①（需实机确认，非阻塞） |
| **M3** iPad 侧栏整块玻璃 | `SideRail` 恢复 `.background(.ultraThinMaterial)`；`Theme.swift` 注释明确「玻璃只用于控件层」 | ✅ **解决**（大面积模糊成本与 HIG 偏离均已消除） |
| **M4** 详情页全宽直角玻璃 | 新增 `BottomActionBar<Content>`（Theme.swift）：iOS 26 = `padding(h16,t10,b8)` + `RoundedRectangle(30)` 玻璃 + 外 `padding(h16,b8)` 悬浮；旧系统 = 原 `padding(h20,t12,b10)` + 全宽 material | ✅ **解决**。三页统一、无双重 padding（已 grep 确认旧 padding 已移除）。布局核算：玻璃条高 51+18 = **69**，悬浮距安全区底 8，总占位 **77**（旧 73，+4pt）；页面滚动底部留白 118/120/124 仍充足，不会遮挡内容 |
| **M5** 容器内 bar+FAB 重叠融合 | 保持同一 `GlassEffectContainer`（处理重叠的正确方式），`spacing` 18→8 并加注释；选中态已无深色 tint | ✅ **处理完成**。静止态融合由「几何重叠 54pt」决定（spacing 只影响转场手感），观感仍需实机确认（7.5-③） |
| Minor `supportsLiquidGlass` 未使用 | 已删除 | ✅ 无残留引用 |
| Minor 三处重复 | 合并为 `BottomActionBar` | ✅ |
| Minor 缺 `.isSelected` trait | 已加 `.accessibilityAddTraits(selected == tab ? .isSelected : [])` | ✅ |
| Minor CI 无玻璃产物 | `runs-on: macos-26` + `require_liquid_glass` 输入（默认 true）+ Xcode<26 时硬失败；`false` 时 warning 回退 | ✅（YAML 经 `ruby -ryaml` 校验通过） |
| Minor m1 `glassEffectID` 常驻 | 现在 FAB 的 ID 只在未选中态存在 | 说明：ID 无重复/冲突；选中态无玻璃形状，见 7.3-① |
| Minor m3 legacy 路径 `.animation` | 保留 | 维持 Minor，可接受（仅底栏切换有动画，布局/材质不变） |

### 7.2 独立验证记录（修正后代码）

| 变体 | 目标 | 结果 |
| :--- | :--- | :--- |
| A：`FinalCode2.swift`（最终代码逐字 + 桩） | `arm64-apple-macosx26.0` | ✅ **0 error 0 warning** |
| B：`iOS 26.0 → macOS 26.0`，模拟 iOS 17 availability | `arm64-apple-macosx17.0` | ✅ **0 error**（`#available` 包裹完整、回退分支无 26 API） |
| C：`#if compiler(>=6.2)` → 恒假，模拟 Xcode 16 | `arm64-apple-macosx17.0` | ✅ **0 error**（含新增 `BottomActionBar`；回退路径不引用任何 iOS 26 符号） |
| D：全工程 `swiftc -parse` | 本机 SDK | ✅ 17/17 |
| E：iOS 26 符号包裹审计 | Theme + RootView | ✅ **8/8**（Theme 3 + RootView 5）全部位于 `#if compiler(>=6.2)` 内 |
| F：可选修正代码片段 typecheck | macOS 26 / 17 等价 / 旧编译器 | ✅ 均 0 error（见 7.3 片段） |

### 7.3 新发现：2 个可选 Minor + 1 个 Info（**均不阻塞**）

**① [Minor · 需实机确认] M2 修正带来的「选中时玻璃形状消失」过渡**
- 事实：`makerLabel` 的 iOS 26 分支现在 `selected == .maker` → 实心 `legacyMakerLabel`（无玻璃）；否则 → 玻璃圆 + `glassEffectID`。即**选中状态下，FAB 的玻璃形状从 `GlassEffectContainer` 中移除**。
- 影响：苹果文档说明容器内形状出现/移除的默认过渡是 `matchedGeometry`（spacing 范围内就近形状）→ 点按时玻璃圆可能「融进底栏」；同时实心 ink 圆以默认 opacity 淡入。0.28s 内可能出现「绿色玻璃残影 + 实心圆淡入」叠加。**ID 无冲突**（同一时刻只有一个 "beanbook-maker"），最终态对比度 8.45:1 有保证。
- 判断：不是 Blocker/Major；**需实机确认**是否显得突兀。若跳变明显，两个可选补丁（均已 typecheck，按需二选一）：
  - 最小补丁——给玻璃圆的「添加/移除」改用 `materialize` 过渡（避免几何融入底栏）：
    ```swift
    // RootView.swift → makerLabel 未选中分支，链在 .glassEffectID 之后
    makerContent
        .glassEffect(liquidGlassStyle(tint: C.lime, interactive: true), in: Circle())
        .glassEffectID("beanbook-maker", in: glassNamespace)
        .glassEffectTransition(.materialize)   // iOS 26.0+
    ```
  - 连续性最好——两态都保留玻璃与 ID，只改内部底色（无形状插入/移除）：
    ```swift
    makerContent
        .background(Circle().fill(selected == .maker ? C.ink.opacity(0.9) : Color.clear))
        .glassEffect(liquidGlassStyle(tint: selected == .maker ? C.ink : C.lime, interactive: true), in: Circle())
        .glassEffectID("beanbook-maker", in: glassNamespace)
    ```
    （ink 90% 叠在浅玻璃上，lime 对比度 **6.32:1**；85% 时 5.40:1，均达标）

**② [Minor · 视觉打磨] 选中 tab 的 `limeSoft` 圆在玻璃上几乎不可见**
- 量化：`limeSoft #EAF2CE` vs 玻璃下纸底 ≈ **1.04 : 1**（原本就弱）；M1 把未选中色从 `muted #8E897E` 改深为 `.secondary`（≈`#61615F`）后，选中/未选中**文字颜色差**从 ink↔muted 的 4.49:1 收窄到 ink↔secondary 的 **2.52:1**，选中态辨识度略降。
- 建议（可选，任选其一）：给选中 pill 加 1px `C.limeDeep.opacity(0.35)` 描边（复用 `SmallChoiceButton` 的处理）；或选中 tab 文字/图标用 `.semibold`/`.medium` 字重区分（与 SideRail 选中行一致）：
  ```swift
  Text(tab.label).font(.system(size: 9, weight: selected == tab ? .semibold : .medium))
  ```
- 判断：非 Blocker/Major，属实机观感打磨项。

**③ [Info] `BottomActionBar` 的 iOS 26 分支没有 `#if compiler(>=6.2)` 包裹**
- 该分支只用自研 `liquidGlassSurface`（内部有 compiler 保护），所以 **Xcode 16 也能编译**；但在「Xcode 16 构建 + iOS 26 设备」这一少见组合下，运行时会进入 iOS 26 分支、内部回退为「圆角 material」而非玻璃（README 已声明 Xcode 16 构建没有玻璃效果）。不影响 Xcode 26 正常路径，可保留现状。

### 7.4 针对 Lead 四个重点问题的直接回答

1. **`AnyShapeStyle` + `HierarchicalShapeStyle.secondary` 用法/可用性**：✅ 用法正确（`.foregroundStyle(tabForeground(tab))`，typecheck 三变体全过）。可用性以官方文档 JSON 核准：`AnyShapeStyle` **iOS 15.0+**、`HierarchicalShapeStyle` **iOS 15.0+**、`.secondary`（`static let secondary: HierarchicalShapeStyle`）**iOS 15.0+**，对 iOS 17 部署目标完全安全。对比度：`.secondary` ≈ 黑 60% 叠底 → 玻璃/纸底 **5.48–5.74 : 1**，比原 3.11 明显改善。
2. **`BottomActionBar` 在 `safeAreaInset` 中的布局/padding**：✅ 合理。玻璃条高 69（按钮 51 + t10 + b8），外置 `h16 / b8` 形成「左右 16pt 留边 + 距安全区底 8pt」的悬浮条；旧系统分支与改动前逐字一致（h20/t12/b10 + 全宽 material）。总占位 77 vs 旧 73（+4pt），三页滚动底部留白充足，无遮挡。iPhone SE（无 home indicator）下距屏幕底 8pt、iPad 下同样悬浮，均正常。
3. **M2 选中/未选中切换的形状跳变或 ID 问题**：ID **无冲突**；存在**玻璃形状的插入/移除**（见 7.3-①），容器默认会用 `matchedGeometry` 动画，属「需实机确认」的观感项，非逻辑/编译问题；给出 `.glassEffectTransition(.materialize)` 最小补丁与「两态都保留玻璃」的连续性方案。
4. **M1 是否真正解决对比度**：✅ 是（浅色玻璃/纸底上 5.48–5.74:1，AA 通过）。唯一保留条件是「真实玻璃被深色/彩色内容染色时的极端情况」，列入实机确认清单。
   > **⚠️ 第三轮真实截图推翻了该理论估算**：`.secondary` 在 Liquid Glass 上被系统 vibrancy 提亮为 `#908F8A`，实测对比仅 **2.87:1**（见 §8.3），M1 实际未达成。

### 7.5 剩余需实机确认清单（更新版，Xcode 26 + iOS 26 模拟器/真机）

1. 底栏文字在彩色/深色内容滑过玻璃时的可读性（5.5:1 是浅色底估算，玻璃会随内容变色）。
2. 点按 FAB 进入/退出「调一杯」选中态时的过渡：玻璃圆是否「融进底栏」、有无残影/双圆叠加（7.3-①）。
3. 底栏条与未选中 FAB 在静止态的融合观感（54pt 重叠 + spacing 8）。
4. 选中 tab 的 `limeSoft` pill 在玻璃上的可辨识度（7.3-②）。
5. 详情页悬浮玻璃条的悬浮高度（8pt）与左右留边（16pt）观感；iPhone SE 与 iPad 各看一次。
6. 系统辅助功能：**降低透明度 / 增强对比度**下 `.glassEffect` 的自动降级是否仍可读。
7. iPhone 详情页（1 块玻璃）+ 根页面（2 块玻璃）滚动帧率；iPad 无底栏，重点看详情页操作条。

### 7.6 复核结论

**0 Blocker、0 Major、2 个可选 Minor（均需/建议实机确认观感）+ 1 个 Info。可以交付构建。**
构建要求不变：用 **Xcode 26+** 编译才会编入 Liquid Glass（CI 已改为 `macos-26` + `require_liquid_glass` 硬门槛）；iOS 17–25 回退路径与改动前逐字等价（仅保留已知的底栏切换 `.animation` 差异）。

---

## 8. 第三轮：真实截图评审（Xcode 27.2 + iOS 27.2 模拟器，2026-11-06 22:13 CST）

> **本轮性质**：Lead 装好 Xcode 27.2，真实编译并在 iOS 27.2 模拟器运行，产出 9 张运行截图。本节用**真实渲染像素**验证前两轮的静态分析结论（尤其 M1/M2/M4/M5）。
> **证据**：`screenshots/ios/{home,beans,maker,menu,stats,route-bean,route-recipe,route-data,route-newbean}.png` 与 `ios/artifacts/screenshots/` 下同名文件 **MD5 完全一致**；`build-info.txt`：`simulator=iPhone Duo, runtime=iOS 27.2, Debug-iphonesimulator, date=2026-11-06 22:12`。截图原始尺寸 1398×2034（@3x）。

### 8.1 渲染环境（重要前提）

- 画布 1398×2034px = **466×678pt**，但 App 是**窗口化**运行的：实测内容卡片 x=62..1083px（左右 20pt 边距）→ **App 有效窗口约 381×678pt**，右侧约 85pt 是系统区，状态栏图标画在 App 窗口**外**（所以截图里「09:41」出现在右侧偏中位置，这是环境现象，**不是 App 布局问题**）。
- 因此本轮可在 **compact width ≈ iPhone 宽度**下验证横向布局与玻璃观感，但**高度只有 678pt**（远矮于常规 iPhone），垂直节奏、home indicator、状态栏需要常规 iPhone 复核；**iPad 未在本轮**。
- **几何实测与代码约束完全吻合**（证明布局实现正确）：

  | 元素 | 代码约束 | 截图实测 |
  | :--- | :--- | :--- |
  | 底栏玻璃条 | 64pt 高、上下 16pt 边距 | 570–634pt（64pt），左右 16pt ✓ |
  | 中央 FAB | 68pt 圆、窗口水平中心 | 直径 **67.7pt**，中心 x=190.7pt = 窗口中心 ✓ |
  | 四个 tab 中心 | HStack 均分 | 50.6 / 119.9 / 261.4 / 331pt，与计算一致 ✓ |
  | 详情页 BottomActionBar | 69pt 高、内边距 16、外留边 16 | 567–636pt（69pt）、内部按钮 577–628pt（51pt）、左右 16pt ✓ |

### 8.2 逐项判定（真实渲染 vs 预期）

| 项 | 真实渲染实测 | 判定 |
| :--- | :--- | :--- |
| **M1** 未选中 tab 文字/图标 | 玻璃底 `#F2F1ED` 上文字实测 `#908F8A` → **2.87 : 1**（四个 tab 一致；maker 页干净玻璃上量得）。对照组：选中文字显式 `C.ink` 实测 `#26231F`（未被提亮） | ❌ **未达成（Major）**：`.secondary` 在玻璃上被系统 vibrancy 提亮成浅灰，与改前 `C.muted`≈3.1:1 基本持平，未达到 AA 4.5；图标同色，非文本 3:1 亦未达。修正见 8.3 |
| **M2** 未选中 FAB | lime 玻璃实测 `#9FC836`（高饱和、不发灰），墨色图标 `#28261F` → **7.78 : 1**；与底栏融合成「鼓包」 | ✅ 通过（绿色光晕见 Minor-②） |
| **M2** 选中 FAB | overlay 实心圆实测 `#26231F`（**纯净，未被玻璃盖灰**），lime 图标 `#A0C938` → **8.12 : 1** | ✅ **overlay 方案有效**，Lead 的修复成立 |
| **M2** 状态切换过渡 | 静态两态均正常；「玻璃形状移除（materialize）+ 实心 overlay 淡入」的过渡帧**未捕获** | ⚠️ **需录像确认**（Minor-③） |
| **M4** 详情页悬浮玻璃条 | 三页均正确渲染：悬浮圆角、16pt 留边、69pt 高、按钮清晰（brand lime 实测 `#A3CD3A`），玻璃后内容模糊可见 | ✅ **通过** |
| **M5** bar+FAB 融合 | 静止态融合成鼓包，自然；lime tint 外溢见 Minor-② | ✅ 可接受 |
| 玻璃是否「发灰」 | 玻璃空白条与纸底**同色**：route-newbean `#F8F7F4` vs 纸底 `#F8F7F3`（亮度比 1.003）；无冷/灰偏色，品牌 lime/ink 饱和度保持 | ✅ **不发灰** |
| 选中 tab 的 pill | pill 填充 vs 玻璃 ≈ **1.04 : 1**（几乎不可见），但 `limeDeep` 描边在截图中可见，叠加 semibold + ink 色后选中态可辨 | ✅ 可辨（前轮 Minor 已由描边缓解） |
| 品牌色对比 | 选中 FAB lime/ink **8.12:1**；未选中 FAB ink/lime **7.78:1**；lime 实测 `#A3CD3A`（品牌值 `#A3CD39`，无损） | ✅ |

### 8.3 Major（1 条）：M1 实测未达成，给出一行修正

- **数据**：未选中 tab 文字 `#908F8A` / 玻璃底 `#F2F1ED` = **2.87:1**（< 4.5 AA，9pt 小字）；四个 tab 一致，选中文字 `#26231F`（14:1）无问题。
- **原因**：`.secondary`（`HierarchicalShapeStyle.secondary`）在 Liquid Glass 上下文被系统 vibrancy 渲染成浅灰（≈40% 黑），而不是 §7 理论估算的 60% 黑（#61615F → 5.5:1）；显式 `C.ink` 不会被提亮（对照组 `#26231F` 原样渲染），因此**改用显式品牌色即可解决**。
- **修正（1 行，已 typecheck：macOS 26 与「iOS 17 等价」双变体均 0 error）**：

  ```swift
  // RootView.swift → tabForeground(_:)
  private func tabForeground(_ tab: AppTab) -> AnyShapeStyle {
      if #available(iOS 26.0, *) {
          return tab == selected
              ? AnyShapeStyle(C.ink)
              : AnyShapeStyle(C.ink.opacity(0.72))   // 在 #F2F1ED 底上 ≈ #5F5D59 → 5.81:1（AA 通过）
      }
      return tab == selected ? AnyShapeStyle(C.ink) : AnyShapeStyle(C.muted)
  }
  ```

  - 备选：`C.ink.opacity(0.75)` → 6.46:1；`C.inkSoft` → 8.67:1（更稳但更重）。保持现有 semibold + limeSoft pill + 描边，选中/未选中仍有区分度。
  - 改后建议只重截 `home.png` / `stats.png` 两张复核即可。

### 8.4 Minor / Info（均不阻塞）

- **Minor-②（可选打磨）未选中 FAB 的 lime tint 外溢**：FAB 周围约 50pt 范围内玻璃饱和度 +0.14（绿色 halo），截图上是柔和的绿色晕染。作为 Liquid Glass 融合属自然现象；若想更克制可试 `liquidGlassStyle(tint: C.lime.opacity(0.8), interactive: true)`（未实测），否则建议保留。
- **Minor-③（需录像）FAB 选中/未选中切换**：静态两态都正常（选中纯净墨黑、未选中 lime 玻璃），但过渡是「容器内玻璃形状移除（`.materialize`）+ overlay 实心圆淡入」，静态图无法判断是否有绿色残影/双圆。建议：
  ```bash
  xcrun simctl io <UDID> recordVideo /tmp/fab-transition.mov
  # 录制期间点按「调一杯」进出 2–3 次
  ```
  若出现残影：给 overlay 的 `makerButton` 加 `.transition(.opacity)` 控制交叉淡入，或调整 `.animation(.snappy(duration:))`。
- **Info 环境未覆盖项**（本轮无法判定，需补图/补跑）：
  1. 常规 iPhone（iPhone 17 等，874pt 高）的垂直节奏、home indicator、状态栏；
  2. **iPad**：M3 已回退 material 的 SideRail、详情页悬浮条在宽屏下的宽度/观感；
  3. **iOS 17/18 运行时回退渲染**（老系统画面是否与改动前一致）；
  4. **降低透明度 / 增强对比度** 辅助功能下的 glass 降级；
  5. 深色内容（深色豆袋照片）滑过底栏时，未选中灰色小字在深色玻璃上的可读性（与 M1 叠加风险）；
  6. FAB 状态切换录屏（Minor-③）。
- **Info**：`route-data.png` 无底部玻璃条（DataView 本身无 safeAreaInset），符合设计预期。
- **Info**：详情页「编辑」白描边胶囊在浅色玻璃上边框对比偏低（视觉可见，非问题）；如追求更强区分可把 stroke 从 `C.line` 提到 `C.mutedLight`。

### 8.5 第三轮结论

**0 Blocker。** 真实渲染确认：**M2（整体方案 + 选中态 overlay）、M4、M5、玻璃质感、品牌色、不发灰** 均通过；**M1 是唯一 Major**（实测 2.87:1，未达 AA），按 8.3 一行修正后重截 1–2 张即可收尾。其余为可选 Minor 与环境覆盖 Info。
发布前建议补齐：常规 iPhone + iPad 截图、iOS 17/18 回退渲染、Reduce Transparency、FAB 切换录屏共 4 项（见 8.4）。

---

### 8.6 最终复核：M1 修正后（2026-11-06 22:23 CST）

> **变更**：`RootView.swift:477-487` 的 `tabForeground` 已把 `HierarchicalShapeStyle.secondary` 改为 `AnyShapeStyle(C.ink.opacity(0.72))`（附注释说明 vibrancy 提亮问题）。源码 22:21:12 → 新构建 22:21:25 → 新截图 22:22:12（9 张全部重截，`screenshots/ios/` 与 `ios/artifacts/screenshots/` MD5 成对一致）。
> **静态复检**：17/17 `swiftc -parse` 通过；iOS 26 符号包裹审计 3/3（Theme）+ 5/5（RootView）仍全部位于 `#if compiler(>=6.2)` 内。

**1) M1 像素级复测（与上轮完全相同坐标/算法）**

| 页面（玻璃后内容） | 未选中文字实测 | 玻璃底实测 | 对比度 | AA |
| :--- | :--- | :--- | :--- | :--- |
| maker（干净玻璃，最可靠） | `#605D59`（四个 tab 一致） | `#F6F5F1` | **6.00 : 1** | ✅ |
| home（米/绿卡片） | `#5F5445`–`#60594B` | `#F3D6AA`–`#F6E9C3` | **5.28 – 5.99 : 1** | ✅ |
| stats（白卡 + 绿柱） | `#615F5B`–`#625F5B` | `#FBFBF7`–`#FCFBF8` | **6.12 – 6.14 : 1** | ✅ |
| beans（绿卡） | `#5F5F55`–`#605E59` | `#F6F7EF`–`#F8F7F0` | **6.00 – 6.05 : 1** | ✅ |
| menu（白卡） | `#605E5A`–`#615F5B` | `#FAF9F6`–`#FBFAF8` | **6.10 – 6.14 : 1** | ✅ |
| 选中态（对照） | `#26231F` | 同左 | **14.2 – 14.9 : 1** | ✅ |

- 与预期 `#5F5D59` / ≈5.8:1 吻合；最差场景（home「豆子」在米色卡片上）仍 **5.28:1 > 4.5**。放大目视确认：未选中文字由浅灰变为中灰、清晰可读，选中态与未选中态层次分明（选中仍 `C.ink` + semibold + limeSoft pill/描边）。
- **M1 关闭。**

**2) 回归检查（该行改动是否影响其它部件）**

| 检查项 | 结果 |
| :--- | :--- |
| 选中 tab 文字 | `#26231F` 不变（14.2:1） |
| FAB 未选中 | lime 玻璃 `#9FC836`、墨色图标 `#27241F` → **7.94:1**（上轮 7.78，等价） |
| FAB 选中 | 墨黑底 `#26231F`、lime 图标 `#A0C938` → **8.12:1**，overlay 仍纯净未被玻璃盖灰 |
| 详情页玻璃条 | `route-bean` / `route-newbean` / `route-data` 三张与上轮 **MD5 字节级一致**；`route-recipe` 哈希虽变，但底栏区域新旧逐像素对比**平均差 0.002 / 最大差 1/255**（渲染微差，无视觉差异）；route-bean 玻璃条左边缘 15.7pt≈16pt、lime 按钮实测 `#A3CD39`，与品牌值一致 |
| 底栏几何 | 与 8.1 实测一致（64pt 玻璃 / 16pt 边距 / FAB 68pt 居中），无位移 |
| 玻璃观感 | 仍不发灰（玻璃空白区≈纸底同色），品牌色饱和度保持 |

**3) 最终 IPA 独立校验**

- `dist/BeanBook-1.0-unsigned.ipa`：986,089 B（≈963K）；`shasum -a 256` = `639dcc1cbb22c1eb3be169bfd02dde5052e5bfbd8b10dbaa72f14032aae5a16b`，**与 Lead 提供值一致**。
- Payload 主二进制：`Mach-O 64-bit executable arm64`（未签名 arm64 符合预期）。
- `nm -u` 未定义符号中含 **15 个** SwiftUI Liquid Glass 符号（`GlassEffectContainer`、`GlassEffectTransition.materialize`、`glassEffect`、`glassEffectID`、`glassEffectTransition`、`Glass.regular`、`Glass.tint`、`Glass.interactive` 等）→ 证明该 IPA **真实编入了 Liquid Glass 代码路径**，不是回退构建（与 Lead 的「玻璃符号 15 个」说法吻合）。

**4) 最终判定**

**M1 关闭；0 Blocker、0 Major。最终结论：可以交付。**

剩余 Info（常规 iPhone / iPad / iOS 17–18 回退渲染 / Reduce Transparency / FAB 切换录屏）由 Lead 写入交付报告作为后续真机抽检项，不影响本次交付结论。

---

## 9. 底部导航重设计评审（5 等分 + 滑动玻璃滑块，2026-11-06 22:36 CST）

> **本轮对象**：`RootView.swift` 的 BottomBar 整体重写——移除「4 tab + 中央 FAB」，改为 5 个等分入口的悬浮玻璃胶囊条（68pt 高、左右 14pt、距底 8pt、`RoundedRectangle(34)`）+ 青柠 tint 玻璃滑块（`itemWidth×46pt`，弹簧滑动）+ 选中 ink/semibold/`.symbolEffect(.bounce)` + haptic；Debug 增加 `-uiTestAutoCycle` 自动轮播（Release 不含）。
> **证据**：9 张新截图（22:34）、`nav-slide.gif`（760×143，8 帧）、新 IPA（SHA256 `039d98…`）；评审方法沿用像素法 + GIF 帧差 + 独立 typecheck。

### 9.1 证据与独立验证

- 时间链：源码 22:32:37 → 构建 22:33:46 → 截图/GIF 22:34:27。`screenshots/ios/` 与 `ios/artifacts/screenshots/` 的 9 张 PNG **MD5 全部成对一致**；但 `nav-slide.gif` **只在 `screenshots/ios/`，artifacts 目录缺失**（Info-a）。
- **route-* 四张 MD5 与上一轮完全一致**（route-bean `729cbe77` / route-recipe `6c0cde30` / route-data `8a63ccd4` / route-newbean `e7cc1bfa`）→ 重设计只影响根页面底栏，**三个详情页/数据页操作条未受任何影响** ✓。
- 编译独立验证：17/17 `swiftc -parse`；把最终 BottomBar 逐字抽取（+ Theme 玻璃段 + 桩）做 3 变体 typecheck：**A**（macOS 26 真实 Glass API）、**B**（target 17 availability 等价）、**C**（模拟 Xcode16：`#if compiler(>=6.2)` 恒假）——**全部 0 error**；iOS 26 符号包裹 Theme 3/3、RootView 1/1（`glassEffect`+`liquidGlassStyle` 同行）全在 `#if compiler(>=6.2)` 内。
- 新 IPA：`039d98d229afedf2e8691b2863519b37718ac322ea067eff757a2f539c6a8b38` **与 Lead 提供值一致**；973,942 B（≈952K）；Payload `Mach-O 64-bit arm64`；Release 二进制中 `uiTestTab` / `uiTestRoute` / `uiTestAutoCycle` 字符串出现 **0 次**（Debug 能力确认未编入 Release）；`nm -u` 含 **6 个** SwiftUI Glass 符号（`glassEffect`、`Glass.regular/tint/interactive` 等）+ **7 个** `symbolEffect` 符号 → 玻璃路径真实编入（数量由 15→6 是移除 FAB/Container/ID/Transition 后的预期结果）。

### 9.2 实测几何 / 位置（与代码吻合）

| 项 | 代码约束 | 截图实测 |
| :--- | :--- | :--- |
| 底栏玻璃 | 高 68、左右留边 14、距安全区底 8、圆角 34 | 玻璃带 568–636pt（68pt）、左右 14/13pt、底部 8pt ✓ |
| 5 等分 | itemWidth =（381−28）/5 = 70.6pt | 每项约 70.6pt 均分 ✓ |
| 滑块尺寸 | 62.6×46pt（圆角 23），上下距条边 11pt | 实测 63.7×47pt（含抗锯齿）、垂直居中偏差 ±0.5pt ✓ |
| 滑块位置 | offset = itemWidth×index，中心 = item 中心 | maker 中心 190.8（期望 190.5）、menu 261.7（期望 261.1）✓ |
| 极端项安全 | 首页/统计滑块距条端 4pt；pill 顶端 23pt 圆角 vs 条 34pt 圆角内缩 9pt | **无越界/裁切**（数学余量 14pt），截图目视也正常 ✓ |

### 9.3 Liquid Glass 标准符合度

| 检查项 | 判定 |
| :--- | :--- |
| 悬浮胶囊玻璃条（iOS 26 tab bar 标准形态） | ✅ |
| 5 等分、SF Symbol + 9pt 文字、选中态用 accent tint 表达 | ✅ |
| 玻璃用于「导航层」且悬浮于内容之上，未做内容层背景 | ✅ 符合 HIG 分层 |
| 图层顺序：条玻璃 → 选中滑块 → 图标/文字（内容在玻璃之上） | ✅ |
| tint 使用：品牌 lime 0.32 提示选中，与参考 DCloud lime-liquid-glass 的「青柠胶囊」观感一致 | ✅ |
| **多个玻璃效果的组织方式** | ⚠️ **不符合苹果建议（Major-1）**：滑块自身是第二个 `glassEffect`，**嵌套在底栏玻璃内部**，且没有使用 `GlassEffectContainer`；官方文档建议「多个 Liquid Glass 效果使用 `GlassEffectContainer` 以获得最佳渲染性能，并允许形状融合」 |
| 自定义 1px `limeDeep` 描边 + 白色渐变高光 | ℹ️ 比系统「让材质自己做功」多一层装饰，但与参考 GIF 风格一致，属设计取舍 |
| 无障碍（Reduce Motion） | ⚠️ 未适配（Minor-①） |

### 9.4 可读性（像素法 + 合成模型）

未选中文字使用 `C.ink.opacity(0.68)`（半透明）→ 文字显示色 = 0.68×ink + 0.32×玻璃底。该模型在 maker 页干净玻璃上验证：预测 `#696662`、实测 `#696763` ✓。

| 位置 | 玻璃底 | 预测文字色 | 对比度 |
| :--- | :--- | :--- | :--- |
| maker（干净玻璃） | `#F6F5F1` | `#696763`（实测） | **5.17 : 1** |
| home「调一杯」 | `#FDF4D7` | `#716C5F` | 4.76 : 1 |
| home「豆子」（米色卡片透出） | `#F3D7AB` | `#685D4C` | **4.64 : 1（最低）** |
| home「统计」/ menu / beans / stats 各处 | — | — | 4.97–5.37 : 1 |

- **AA（4.5:1）通过，但最低余量仅 0.14**；玻璃后若为更深色内容（深色豆袋照片），半透明文字会进一步融入背景。建议 0.68 → **0.75**（预测 5.70–6.73:1）或改用不透明 `C.inkSoft`。图标同色，非文本 3:1 达标。
- 选中态：ink on pill（`#DDE8BA`）对比 >10:1 ✓；pill 描边（limeDeep 0.28）≈1.5:1，仅装饰，不要求 AA。
- 玻璃**不发灰**（材质/背景与上轮一致，未出现冷灰偏色）。

### 9.5 滑动动画（GIF 逐帧 + 帧差）

- GIF 结构：8 帧，首帧 600ms + 后续 7×100ms，总 1.3s，loop。
- 逐帧：frame0 滑块在「首页」；**frame1 滑块位于首页/豆子之间（约 46% 行程）**；frame2→7 相对末帧差异 4.09→1.48→1.16→0.84→0.39 **单调收敛**到「豆子」。
- ✅ **单一滑块，无双影/双 pill/跳变**；中间帧滑块跨两项边界、图标绘制在滑块之上，方向与落点正确，观感自然。
- ⚠ **证据强度**：只有 **1 个真实中间帧**，其余是弹簧收敛的小位移；不足以评估完整弹簧曲线/是否过冲（damping 0.72 理论上会有轻微回弹）。建议保留 60fps 原始录屏，或用 `-uiTestAutoCycle 0.6` 录更长/更多帧的 GIF 作为交付证据。
- 参数观感：response 0.46 / damping 0.72 比系统 tab bar（约 0.3–0.35s）略慢略弹；若追求系统手感可收紧到 0.34–0.38、damping 0.8；若要与参考 GIF 的「弹一下」一致则保留（设计取舍）。
- Minor：`.symbolEffect(.bounce, value: selected == tab)` 在**选中与取消选中**时都会触发值变化 → 每次切换**两个图标同时 bounce**（旧/新选中各一次）；系统 tab bar 无此行为，建议只对新选中触发或移除。

### 9.6 问题清单

| 级别 | 数量 | 内容 |
| :--- | :--- | :--- |
| **Blocker** | **0** | 编译（3 变体 + 17/17 parse）、布局、动画、构建/IPA 均通过 |
| **Major** | **1** | **M9-1 双层玻璃**：滑块是第二个 `glassEffect` 嵌套在底栏 `glassEffect` 内部、未使用 `GlassEffectContainer`。影响：① 滑动动画每帧需在外层玻璃之上重新合成内层玻璃（额外离屏合成/模糊，动画期成本更高）；② 选中胶囊观感比系统更「实」，玻璃透出感弱于条内其它区域，与系统「材质一体 + tint 区域」有差异；③ 与 HIG「少而精使用玻璃、避免堆叠玻璃元素」方向不完全一致。**视觉不明显、不阻塞功能**。修正见 9.7 |
| **Minor** | **6** | ① 未适配 Reduce Motion（spring + symbolEffect 应降级）；② 未选中文字最低 4.64:1、余量小（0.68→0.75 更稳）；③ 两个图标同时 bounce；④ 滑块 `.interactive()` 用在不可点击的指示器上（触摸由上层 Button 接收），意义不大且多一份交互玻璃成本；⑤ 弹簧参数略慢/略弹；⑥ 首页/统计极端位置滑块距条端仅 4pt（无越界，纯视觉略紧，可加 2–4pt 内缩）|
| **Info** | **4** | a) GIF 只有 1 个中间帧，建议 60fps 原始录屏/更多帧；b) `ios/artifacts/screenshots/` 缺 `nav-slide.gif`（两处截图目录其余文件已同步）；c) route-* 与上轮 MD5 完全一致（详情页未受影响，正向证据）；d) Release 测试参数已剔除、玻璃符号 6 个（预期变化）|

**M9-1 修正 A（推荐，最小改动、视觉几乎不变）**——把滑块从「第二层玻璃」改成条玻璃之上的 tint 填充 + 描边 + 高光（即把 iOS 26 分支里的 `.fill(Color.clear).glassEffect(...)` 换成 `.fill(C.lime.opacity(0.32))`）：

```swift
// RootView.swift → selectionIndicator 的 iOS 26 分支
Capsule()
    .fill(C.lime.opacity(0.32))              // ← 替代原来的 .fill(Color.clear) + .glassEffect(...)
    .overlay {
        Capsule().stroke(C.limeDeep.opacity(0.28), lineWidth: 1)
    }
    .overlay {
        Capsule().strokeBorder(
            LinearGradient(
                colors: [Color.white.opacity(0.75), Color.white.opacity(0.05)],
                startPoint: .top, endPoint: .bottom
            ),
            lineWidth: 0.8
        )
    }
    .frame(width: itemWidth - 8, height: barHeight - 22)
    .padding(.horizontal, 4)
    .frame(width: itemWidth)
```

**M9-1 修正 B（保留玻璃滑块、更「液态」）**——把「底栏玻璃形状 + 滑块玻璃形状」改为同一 `GlassEffectContainer` 内的**同级**玻璃层，HStack 内容覆盖其上，利用容器合并/融合（可能产生 lime 晕染，需实机确认）。

### 9.7 本轮结论

**0 Blocker / 1 Major（M9-1 双层玻璃，规范/性能，视觉不明显、不阻塞功能）/ 6 Minor / 4 Info。**

- 新导航在真实截图中**符合 iOS 26 Liquid Glass 悬浮 tab bar 的基本形态**：5 等分、悬浮玻璃胶囊、tint 选中滑块、层级正确、几何与代码完全吻合、滑块位置/极端项安全、可读性 AA 通过、动画有真实中间帧且无双影/跳变。
- 建议：按 **修正 A** 去掉滑块 glassEffect（视觉几乎一致、消除叠玻璃与动画期双重合成）后重截 `home.png`/`maker.png` 两张即可；若设计上接受现状也可交付。Reduce Motion 建议在交付报告记为后续项。
- 仍需其他环境确认：常规 iPhone、iPad（SideRail 未变）、iOS 17–25 回退滑块渲染、Reduce Transparency、60fps 原始动画。

---

## 10. 第六轮：改用系统原生 TabView（2026-11-06 22:58 CST）

> **本轮变更**：放弃自绘滑块，RootView 重写为系统原生 `TabView(selection:)` + 5 个 `.tabItem { Label }`；每个 Tab 独立 `NavigationStack`（`paths: [AppTab: [Route]]`）；`navigationDestination` 上 `.toolbar(.hidden, for: .tabBar)`；删除自绘 BottomBar/SideRail/滑块/GlassEffectContainer 相关代码；Theme 的 `liquidGlassSurface`/`BottomActionBar` 仅保留给详情页；内容底部留白 120→24；Debug 参数保留；`nav-slide.gif` 删除。

### 10.1 证据与独立验证

- 截图/GIF：9 张 PNG（22:56），`screenshots/ios/` 与 `ios/artifacts/screenshots/` **MD5 全部成对一致**；`nav-slide.gif` 两处均已删除。**注意**：Lead 发消息后源码又在 **23:01:24** 改过一次（仅删除 `RootView` 中未使用的 `@Environment(\.horizontalSizeClass)`，318→317 行）并重建（app 23:01:28 → IPA 23:01:38）；截图仍是 22:56 构建——该改动无渲染差异，但截图与当前 IPA 严格来说不同源（见 Info-⑤）。
- **route-* 四张 MD5 与上一版逐字节一致**（route-bean `729cbe77` / route-recipe `6c0cde30` / route-data `8a63ccd4` / route-newbean `e7cc1bfa`）→ 详情页 + 悬浮玻璃操作条渲染**无回归**，Tab Bar 隐藏生效。
- **IPA（以当前 dist 为准）**：Lead 消息里的 `0c43aac8…` / 955,184 B 是 22:56 构建；**当前** `dist/BeanBook-1.0-unsigned.ipa` = **953,735 B**、`shasum -a 256` = `1e2b4439e2cd63ccc5fef7088513f517e22e9e3c96dbdd3499345cbe04985afc`（23:01 重建）。Payload 主二进制 `Mach-O 64-bit executable arm64`、`LC_BUILD_VERSION minos 17.0 / sdk 27.2`、**未签名**；Bundle 内容完整（`Info.plist`、`Assets.car`、`AppIcon60x60@2x.png`、`AppIcon76x76@2x~ipad.png`、`PkgInfo`、主二进制）；`Info.plist`：`com.brewkin.beanbook.ios` / 忆杯手记 / `MinimumOSVersion 17.0` / `UIUserInterfaceStyle Light`。
- Release 清理：二进制中 `uiTestTab` / `uiTestRoute` / `uiTestAutoCycle` 字符串出现 **0 次**；`nm -u` 含 **6 个** SwiftUI Glass 符号（只剩详情页 `liquidGlassSurface → glassEffect` 路径，符合预期）。
- 静态：17/17 `swiftc -parse`；iOS 26 符号包裹 Theme 3/3、RootView **0/0**（已无玻璃代码）；`project.pbxproj` 未改动、17 个 Swift 文件全部在工程内；`#if compiler(>=6.2)` 回退机制保留在 Theme（详情页玻璃用）。
- 环境说明：本机是 **iPhone Duo 折叠屏**，iOS 27 把系统原生 `TabView` 渲染为**右侧竖向玻璃侧栏**（位于 App 内容区右侧的系统区域；内容宽度与上一版一致，route-* MD5 一致可证），这是系统自适应形态，**不是 App 代码绘制**。

### 10.2 逐问回答

1. **系统 TabView 是否解决 M9-1**：✅ **完全解决**。App 不再自绘底栏/滑块 → 没有 glass-on-glass、没有自绘滑块动画与双层合成；系统 TabView 自带标准 Liquid Glass Tab Bar 与大号玻璃选中滑块（本机侧栏形态中也能看到：竖向玻璃胶囊 + 选中项的大号玻璃滑块）；App 内剩余唯一自绘玻璃是详情页 `BottomActionBar`（单层玻璃，无叠玻璃）。**M9-1 关闭。**
   - ⚠ **证据缺口（Info-①）**：本机折叠屏把 TabView 渲染成右侧侧栏，**用户要求的“底部大玻璃滑块”形态本机没有截到**；系统控件行为可信，但建议在标准 iPhone 模拟器（iPhone 17/16）补 `home`/`beans` 两张 + 一段点击切换录屏，作为交付证据。
2. **详情页隐藏 Tab Bar + 悬浮玻璃条是否合理**：✅ 合理。`.toolbar(.hidden, for: .tabBar)` 生效（route-* 像素级无回归、无系统栏残留）；`BottomActionBar` 仍是 `safeAreaInset` 悬浮圆角玻璃条，与「全屏详情 + 底部主操作」模式一致；返回按钮正常（截图中可见）。进入/退出详情时系统栏的隐藏/显示动画建议真机确认（Info-②）。
3. **Release / IPA 是否正常**：✅ 通过（**以当前 dist 的 23:01 重建为准**：953,735 B / `1e2b4439…`；Lead 消息里的 `0c43aac8…` 是 22:56 旧构建）。arm64、minos 17.0、未签名、Bundle 元件完整、Release 无 Debug 参数、玻璃符号 6（详情页路径），`Info.plist` 关键键正常。
4. **新 Blocker / Major**：**0 Blocker；1 Major（M10-1，功能回归，见下）**。

### 10.3 M10-1（Major，功能回归）：`destination()` 里硬编码目标 Tab，跨 Tab 打开的详情页会“点不动”

- **位置**（`RootView.swift` 的 `destination(_:)`）：
  - `.bean` 分支：`onEdit: { push(.editBean(id), in: .beans) }`、`onOpenRecipe: { push(.recipe($0), in: .beans) }`
  - `.recipe` 分支：`onOpenBean: { push(.bean($0), in: .menu) }`
- **问题**：但 `homeRoot` / `makerRoot` 也会把详情压入 `.home` / `.maker` 栈。于是：
  - 首页 → 豆子详情 → 点「编辑」→ 路由被压进 `.beans` 栈（当前不可见）→ **用户看到什么也没发生**；之后切到「豆子」Tab 还会莫名出现编辑页。
  - 首页 / 调一杯 → 配方详情 → 点豆子 → 压进 `.menu` 栈（不可见）。
  - 豆子 Tab 的豆子详情 → 配方详情 → 点豆子 → 压进 `.menu` 栈（不可见）。
  - 只有「在 beans 打开 bean / 在 menu 打开 recipe」的主路径正常，`onDelete` 用 `paths[tab]` 正确但建议同步改为 owner。
- **级别**：Major（核心「编辑豆子 / 打开关联豆子」在 Home 等入口失效；非崩溃、非编译）。
- **修正（最小重构，约 10 行）**——把所属 Tab 传进 `destination`：

  ```swift
  // tabRoot 内
  .navigationDestination(for: Route.self) { route in
      destination(route, in: tab)          // tab = 该 NavigationStack 所属 Tab
          .toolbar(.hidden, for: .tabBar)
  }

  @ViewBuilder
  private func destination(_ route: Route, in owner: AppTab) -> some View {
      switch route {
      case .bean(let id):
          if let bean = store.bean(id) {
              BeanDetailView(
                  bean: bean,
                  onEdit: { push(.editBean(id), in: owner) },          // ← 原 .beans
                  onMake: {
                      store.draft.beanId = id
                      switchTab(.maker)
                  },
                  onOpenRecipe: { push(.recipe($0), in: owner) }       // ← 原 .beans
              )
          } else {
              MissingView()
          }
      case .recipe(let id):
          if let recipe = store.recipe(id) {
              RecipeDetailView(
                  recipe: recipe,
                  onRepeat: {
                      store.loadRecipeIntoDraft(recipe)
                      switchTab(.maker)
                  },
                  onOpenBean: { push(.bean($0), in: owner) },          // ← 原 .menu
                  onDelete: {
                      store.deleteRecipe(recipe)
                      if !(paths[owner] ?? []).isEmpty { paths[owner]?.removeLast() }
                  }
              )
          } else {
              MissingView()
          }
      // newBean / editBean / data 分支不变
      }
  }
  ```

  另建议把 Debug 的 `openLaunchRouteIfNeeded()` 里 `push(..., in: .beans/.menu)` 改为 `in: tab`（截图脚本的 tab 与 route 已匹配，当前不出错，但更稳）。

### 10.4 Minor / Info

| 级别 | 内容 |
| :--- | :--- |
| Minor-① | `MakerView` 仍保留旧自绘底栏的留白：`.padding(.bottom, isWide ? 20 : 92)`（MakerView.swift:35）。改用系统 Tab Bar 后，iPhone（compact）底部会多出约 92pt 空白；建议改为 `isWide ? 20 : 24`。本机折叠屏走 regular/20，所以本轮截图看不出——**需在常规 iPhone 验证** |
| Minor-② | Apple 文档显示 `toolbar(_:for:)` 自 **iOS 27.3** 起 deprecated（替代 `toolbarVisibility(_:for:)` 需 iOS 18+）。当前 SDK 27.2 编译无警告、部署目标 17 下建议保留现写法；未来可按 `#available(iOS 18)` 条件切换或忽略 |
| Minor-③ | `ios/README-IOS.md` 仍有旧描述：:30 / :54 提 `GlassEffectContainer`、「中央调一杯按钮」、自绘玻璃底栏；:175–178 提已删除的 `nav-slide.gif`。建议更新 |
| Info-① | 本机折叠屏把系统 TabView 渲染为右侧玻璃侧栏，**用户参考的「底部大号玻璃滑块」形态未在交付截图中验证**；建议标准 iPhone 模拟器（iPhone 17/16）补 2 张 + 点击切换录屏 |
| Info-② | 详情页进入/退出时系统 Tab Bar 的隐藏/显示动画（`.toolbar(.hidden, for: .tabBar)`）建议真机/录屏确认平滑 |
| Info-③ | iPad（系统自适应侧栏/顶部 Tab Bar 形态）、iOS 17–25 经典 Tab Bar 形态、Reduce Transparency 仍需其他环境确认 |
| Info-④ | `.toolbar(.hidden, for: .tabBar)` 在 iOS 26/27 隐藏系统栏；route-* 与上一版 MD5 完全一致，说明隐藏生效且页面渲染无回归（正向证据） |
| Info-⑤ | 构建时间线：截图 22:56（22:55 构建）→ 源码 23:01:24（仅删未使用属性）→ 重建 23:01:28 / 新 IPA 23:01:38。当前 `dist` IPA = **953,735 B / SHA256 `1e2b4439…`**，与 Lead 消息里的 22:56 版（955,184 B / `0c43aac8…`）不同；交付请以当前 `dist` 为准，建议重跑一次截图脚本保持截图与 IPA 严格同源 |

> 原 Minor-②（`RootView` 未使用的 `horizontalSizeClass`）已在 23:01 重建中删除 → **关闭**。

### 10.5 本轮结论

**0 Blocker / 1 Major（M10-1 跨 Tab 路由压栈错误，功能回归，建议合入前修）/ 3 Minor / 5 Info。**

- 方向正确：改用系统原生 `TabView` **完全消除了 §9 的 M9-1 双层玻璃/自绘滑块问题**，Liquid Glass Tab Bar 与滑动选中滑块由系统提供；详情页「隐藏 Tab Bar + 悬浮玻璃操作条」合理且像素级无回归。
- 唯一建议合入前修复的是 **M10-1**（约 10 行重构）；其余为常规 iPhone 布局细节（MakerView 留白）、文档同步（README）、系统 API 未来弃用提示与验证缺口。
- 交付前建议：修 M10-1 → 用标准 iPhone 模拟器补底部 Tab Bar 截图 + 点击切换录屏（用户核心视觉要求）→ 在交付报告标注 iPad / iOS 17–25 / Reduce Transparency 抽检项。

---

## 11. 第七轮：最终复审（iPhone 17 真机形态 + M10-1 / MakerView 修复，2026-11-06 23:21 CST）

### 11.1 证据与时间线

- 设备：**iPhone 17 / iOS 27.2**，截图 1206×2622（@3x = 402×874pt），`build-info.txt` date 23:17:54。
- 时间线：`RootView` 23:07:23（M10-1 修复）→ `MakerView` 23:17:33（布局修复）→ 构建 23:17:54 → 截图 23:18:34 → 新 GIF 23:19:51 → IPA 23:20:04；**所有源码均早于构建产物**（无 stale，find 验证 0 个新于 app 二进制的源文件）。
- 产物：9 张主/详情 PNG；`nav-slide.gif`（720×187，16 帧：450ms 首帧 + 12×30ms 动画帧 + 120/30/420ms 收尾）；`ios/artifacts/screenshots/nav-slide-transition-sheet.png`（2080×612，t=5.75→7.10s 的 16 帧过渡原图）；`screenshots/ios/` 与 `ios/artifacts/screenshots/` 的 9 张 PNG 与 GIF **MD5 成对一致**；transition sheet 仅 artifacts（符合说明）。
- IPA：`dist/BeanBook-1.0-unsigned.ipa` **956,555 B**，`shasum -a 256` = `335e3017a8891227fab01d29f7e1dbd56bf61f2bd95ae94791a394090e2f1962`，**与 Lead 提供值一致**；`Mach-O 64-bit arm64`、`LC_BUILD_VERSION minos 17.0 / sdk 27.2`、**未签名**；Bundle 完整（`Info.plist` / `Assets.car` / `AppIcon60x60@2x.png` / `AppIcon76x76@2x~ipad.png` / `PkgInfo` / 主二进制）；`Info.plist`：bundle id / 忆杯手记 / `MinimumOSVersion 17.0` / `UIUserInterfaceStyle Light`；Release 中 `uiTestTab` / `uiTestRoute` / `uiTestAutoCycle` = **0 次**；Glass 符号 **6 个**（只剩详情页 `liquidGlassSurface → glassEffect` 路径，符合预期）。
- 静态：17/17 `swiftc -parse`；Theme 玻璃符号 3/3 仍在 `#if compiler(>=6.2)` 内；RootView / MakerView 已无 iOS 26 玻璃符号；自绘导航关键符号（BottomBar / SideRail / GlassEffectContainer / glassEffectID / Transition）**无残留**。

### 11.2 四项确认

**a) 系统原生 TabView 是否满足「用 Xcode 自带效果」**：✅ **满足**。iPhone 17 截图显示系统**底部悬浮 Liquid Glass Tab Bar**（5 项等分、图标 + 文字、选中项为系统大号透明玻璃滑块）；`nav-slide-transition-sheet.png` 的 16 帧（t=5.75→7.10s）可见系统滑块从「首页」morph/slide 到「豆子」的完整过程（含拉伸过渡帧），是系统控件自身动画，App 侧无自绘底栏/滑块代码。**M9-1 维持关闭。**

**b) MakerView 新布局是否解决过长 / 拥挤**：✅ **基本解决**。杯子由约 **61% 屏高**缩到约 **31% 屏高**（`.aspectRatio(0.64, contentMode: .fit)` + `maxWidth 280 / maxHeight 380` 生效，截图实测）；主区域左右留白 24、右侧面板窄屏 128、原料托盘外 14 / 内 20、横向滚动（截图右侧半露的下一张卡片是滚动 affordance，正常）；旧自绘底栏的 92pt 底部留白已删除（grep 确认无残留）。截图观感不再拥挤、杯型比例正常。

**c) M10-1 修复是否正确**：✅ **正确**。`tabRoot` 内改为 `destination(route, in: tab)`；`.bean` 的 `onEdit` / `onOpenRecipe` 与 `.recipe` 的 `onOpenBean` 全部 push 到 **owner Tab** 栈；Debug 的 `openLaunchRouteIfNeeded` 也改为 `in: tab`。从 Home / Maker 打开的详情页再点「编辑 / 打开关联豆子」会压入当前 Tab 栈，不再「点不动」。
- 小 nit（非阻塞）：`onDelete` 仍用 `paths[tab]`（详情页可见时 `tab == owner`，功能正确；建议改 `paths[owner]` 保持一致）；`beansRoot` / `menuRoot` 的 root 闭包仍有 `.beans` / `.menu` 硬编码（只在其自身 Tab 可见时执行，安全）。

**d) 是否还有 Blocker / Major**：**0 Blocker、0 Major**；1 Minor（上述 `onDelete` 一致性 nit）+ Info 级抽检项（iPad、iOS 17–25 经典 Tab Bar、Reduce Transparency；`.toolbar(_:for:)` 在 iOS 27.3 起 deprecated，当前 SDK 27.2 无警告、部署目标 17 下保留即可）。

### 11.3 结论

**最终判定：0 Blocker / 0 Major / 1 Minor → 可以交付。**

系统原生 `TabView` 方案在 iPhone 17 真机形态下满足用户「用 Xcode 自带 Liquid Glass 效果 + 大号玻璃选中滑块动画」的要求；M9-1 关闭；M10-1 与 MakerView 布局修复均已验证；最终 IPA 清理与元件正常、源码与构建产物同源。剩余仅 Info 级抽检项与一处一致性 nit，建议写入交付报告。

---

## 12. Android 玻璃 v2 评审（**历史记录 · 已暂停，不作为最终结论**）

> **状态（2026-11-07 14:45）**：用户方向变更——Android **不再做 iOS 悬浮玻璃**，改为「传统 Android 布局 + 小米澎湃 OS 4（HyperOS）风格」：贴底导航条、选中项圆角高亮块、HyperOS 卡片/大标题。因此本节 Android v2 玻璃评审**暂停**，等 android-dev 完成 v3（task-9）后用新素材按新方向评审。以下仅为本轮已完成的观察，留作历史记录。

### 12.1 v2 实现核对（`Glass.kt`，631 行）

- 结构：`GlassSurface` = 半透明白底（`FillTop/Mid/Bottom` 0.53/0.47/0.43，滑块 0.30，操作条 0.50）+ `GlassFrost`（4 个径向色斑整层 `Modifier.blur(18dp)`，API 31+ 真模糊、低版本 no-op）+ `GlassGrain`（220 颗预生成白点）+ `GlassFinish`（外 1.1dp rim、内 4.2dp 双层 rim、顶角三层弧光、lime/cyan/magenta 色散细线、顶部内发光、底部内阴影、左右 7dp 端部亮带、斜向高光带、3 个高光点）；滑块用 `Animatable` + layout-phase `offset` + 1.03 缩放（spring damping 0.72 / stiffness 186）。
- 工程侧优点：无整页 blur、无新依赖；滑块动画走布局阶段 offset 不逐帧重组；bar/滑块/操作条为小面积 Canvas，静态时基本不重绘。

### 12.2 已发现的 v2 问题（历史记录；v3 若不再做玻璃则多数不再适用）

1. **未选中 tab 标签对比度不足（可读性）**：实测 `#A4A198` on `#D9DDD9` ≈ **1.85–1.92:1**（4 个未选中项一致），低于 AA 4.5；同屏 iOS 系统 Tab Bar 未选中标签约 18:1。原因：`BrewColors.Muted.copy(alpha = 0.72f)` 叠在半透明白玻璃上过浅。
2. **无 backdrop blur → 清晰内容穿透**：glass 只是「半透明白膜 + 静态色斑」，玻璃下真实文字（如 `RECENT CUPS`、列表行）仍锐利，与「首页/分享」等标签叠影；玻璃区水平梯度能量 0.66（iOS 系统玻璃 0.35），观感更像半透明膜而非毛玻璃（平台限制，见 NOTES 已知近似）。
3. **边缘/高光偏强，略「塑料/糖果」感**：外 rim 白 0.95、内 rim、端部 7dp 亮带与滑块整圈高光在浅色页面上偏硬；`shadow(16.dp)` 也偏重（iOS 系统玻璃阴影更柔）。
4. **磨砂颗粒可见度偏高**：220 颗白点（alpha 0.02–0.05）在 58dp bar 上肉眼可见，略像噪点/灰尘；建议减量或降 alpha。
5. **GIF 证据质量**：`12-tab-slider-slowmo.gif`（6 帧 ×140ms）有明显帧间残影与霓虹色边（帧优化/调色或 10× 慢放录制导致，PNG 截图无此现象），作为交付证据建议重编码（dispose/optimize）或改 MP4。另 spring 3–4% 过冲在首/尾项可能短暂越过 bar 端点（v2 未截到确证帧，若保留胶囊滑块建议 clamp `sliderProgress`）。
6. **API<31 降级**：`Modifier.blur` 在 Android 12 以下 no-op → 磨砂色斑变锐利（布局不受影响）；minSdk 26 覆盖旧机。
7. **性能**：`GlassSurface` 共 6 处使用（tab bar / 滑块 / 详情操作条 ×3 / 圆形图标按钮），其中小圆形按钮默认 `frost=true` 也会各建 blur/RenderEffect 层；低端机未实测，建议小面积按钮 `frost=false`。
8. **小项**：选中项仍用线框图标（iOS 会切换 filled 变体）；9.5sp 标签 + 58dp 固定 bar 高，大字号无障碍模式可能挤压（未测）；`onDelete`/导航等 iOS 侧问题见 §11，与 Android 无关。

### 12.3 备注

透明、边缘 rim/折射、色散、高光与「晶莹」方向基本到位；**「毛玻璃模糊」受 Android 平台限制只能近似**，v2 的主要实际短板是未选中标签对比度与清晰内容穿透。以上均为历史记录，**等 v3 素材后按「HyperOS 4 风格」重新评审，不沿用本节结论**。

