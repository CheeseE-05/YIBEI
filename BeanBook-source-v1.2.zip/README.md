# 忆杯手记 · BeanBook

一款为精品咖啡爱好者做的 **离线咖啡豆与配方记录 App**。界面沿用「豆仓 / BeanFolio」一路的奶油灰纸张、荧光青柠与黑色大字风格，把豆子、调饮、菜单和统计收在同一个安静的空间里。

**1.2 版（2026-11-07）**：菜单里保存的配方现在可以**直接编辑修改**（双端）；Android 端改回**传统 Android 布局并参考小米澎湃 OS 4**：底部为**悬浮毛玻璃胶囊导航（4 个 tab + 浅灰玻璃滑动块）+ 右侧绿色「调一杯」圆形 FAB**；iOS 仍用系统原生 Liquid Glass Tab Bar，并把 Tab 图标缩小约 17%。双端均已重新编译、模拟器实测并打包。
**并合入 1.2 功能包（2026-11-07）**：所有「配方别册」改为「配方目录」；新增设置页（统计页最底部入口：AI API 配置、黑暗模式、整库导入导出迁移、关于）；双端黑暗模式；每个配方可做**社交卡片风「随杯卡」**（横版+竖版、A6 300dpi 可打印）：奶油纸底 + 大号英文名/中文名 + 配料 + 风味参考 + **AI 咖啡插画（智谱 GLM-Image）/相册导入自动抠图（透明背景）** + 价格 ¥；可导出相册、分享与打印。

> **1.2 发行产物**（2026-11-07，双端均已构建/实测，详见 [1.2 发行说明](docs/RELEASE-1.2.md)）：

> - **Android APK（已签名，arm64）**：`dist/BeanBook-v1.2-arm64.apk`（约 29.7 MiB，SHA256 `cf44a987…`，Android 8.0+）
> - **iOS 未签名 IPA**：`dist/BeanBook-1.2-unsigned.ipa`（1.6 MB，arm64，SHA256 `d03008e8…`，minos 17.0）
> - **源码包**：`dist/BeanBook-source-v1.2.zip`（Android + iOS + 文档 + 脚本，SHA 见 `dist/SHA256.txt`）
> - **本版更新**：菜单配方可编辑（双端）；Android 澎湃 OS 4 风格悬浮毛玻璃胶囊导航 + 绿色 FAB；iOS Tab 图标缩小；配方目录改名/设置页/黑暗模式/横版宣传卡片(AI+导出相册)
> - **Android 实拍**：[`screenshots/android-1.2/`](screenshots/android-1.2/) · **iOS 实拍**：[`screenshots/ios/`](screenshots/ios/) · **iOS 编辑流程**：[`ios/artifacts/verify-1.2/`](ios/artifacts/verify-1.2/)
> - **iOS 安装**：Sideloadly / AltStore 用 Apple ID 自签（免费账号 7 天）或 Xcode Run；**打包 IPA 不需要 Apple ID**
> - **一键构建**：Android `./gradlew :app:assembleRelease`；iOS `bash ios/scripts/build-all.sh`；发行打包 `bash tools/package-release.sh`

## 一眼看功能

| 首页 | 豆仓 |
| --- | --- |
| ![首页](screenshots/home2.png) | ![豆仓](screenshots/beans.png) |

| 调一杯 | 菜单 / 配方目录 |
| --- | --- |
| ![调一杯](screenshots/maker-layers.png) | ![菜单](screenshots/menu.png) |

| 数据与分享 | 统计 |
| --- | --- |
| ![数据与分享](screenshots/data-screen.png) | ![统计](screenshots/stats.png) |

**1.2 新功能：菜单里的配方可直接编辑（Android / iOS）**

| Android：配方详情「编辑」 | Android：编辑态「正在修改配方」 | Android：保存后实时刷新 |
| --- | --- | --- |
| ![Android 配方详情](screenshots/android-1.2/06-recipe-detail.png) | ![Android 编辑态](screenshots/android-1.2/07-maker-edit.png) | ![Android 保存后](screenshots/android-1.2/09-after-edit-save.png) |

**Android 1.2：澎湃 OS 4 风格悬浮胶囊导航（4 tab + 绿色「调一杯」FAB）**

| 首页（选中「首页」） | 豆子（高亮块滑到「豆子」） | 菜单（磨砂胶囊 + 菜单选中） | 统计 | 调一杯（绿色 FAB 选中） |
| --- | --- | --- | --- | --- |
| ![Android 首页](screenshots/android-1.2/00-home.png) | ![Android 豆子](screenshots/android-1.2/01-beans.png) | ![Android 菜单](screenshots/android-1.2/02-menu.png) | ![Android 统计](screenshots/android-1.2/03-stats.png) | ![Android 调一杯](screenshots/android-1.2/04-maker-fab-selected.png) |

内外圆角同心 + 毛玻璃细节特写（2×）：

| 内外圆角同心（端点不越界） | 胶囊毛玻璃（背后内容隐约透出） |
| --- | --- |
| ![同心圆角](screenshots/android-1.2/18-corner-alignment-closeup.png) | ![毛玻璃](screenshots/android-1.2/19-frost-glass-closeup.png) |

Tab 切换 + FAB 动画（模拟器逐帧真实截图，米白底 + 绿色 FAB）：

![Android 胶囊导航切换动画](screenshots/android-1.2/16-tab-switch.gif)

**iOS 版实拍（Xcode 27.2 + iPhone 17 / iOS 27.2 模拟器；系统原生 Liquid Glass 底部 Tab Bar，1.2 起 Tab 图标缩小约 17%）**

| 首页 | 豆仓 | 调一杯 |
| --- | --- | --- |
| ![iOS 首页](screenshots/ios/home.png) | ![iOS 豆仓](screenshots/ios/beans.png) | ![iOS 调一杯](screenshots/ios/maker.png) |

| 菜单 | 统计 | 豆子详情（底部玻璃操作条） |
| --- | --- | --- |
| ![iOS 菜单](screenshots/ios/menu.png) | ![iOS 统计](screenshots/ios/stats.png) | ![iOS 豆子详情](screenshots/ios/route-bean.png) |

底部 Tab Bar 切换动画（iPhone 17 模拟器录屏逐帧，系统原生玻璃滑块滑动）：![导航切换动画](screenshots/ios/nav-slide.gif)

**1.2 功能包实拍（双端：设置页 / 黑暗模式 / 横版宣传卡片 / AI 生成 / 导出）**

| Android 设置页（AI 文案 + GLM-Image 插画 API + 黑暗模式 + 数据） | Android 黑暗模式首页 | Android 菜单价格 ¥NN |
| --- | --- | --- |
| ![Android 设置](screenshots/features-1.2/android/03-settings-dark.png) | ![Android 暗色](screenshots/features-1.2/android/07-home-dark.png) | ![Android 菜单价格](screenshots/features-1.2/cards-v2-android/16-menu-price.png) |

**随杯卡 v2（参照手绘咖啡卡重做：横版 + 竖版、AI 插画、导入抠图、A6 打印）**

| Android 横版卡 | Android 竖版卡 | Android 导入抠图（透明） |
| --- | --- | --- |
| ![Android 横版卡](screenshots/features-1.2/cards-v2-android/05-card-landscape-ai.png) | ![Android 竖版卡](screenshots/features-1.2/cards-v2-android/06-card-portrait-ai.png) | ![Android 抠图卡](screenshots/features-1.2/cards-v2-android/13-cutout-card-portrait.png) |

| iOS 竖版卡（A6） | iOS 横版卡（A6） | iOS 导入抠图（透明） |
| --- | --- | --- |
| ![iOS 竖版卡](screenshots/features-1.2/cards-v2-ios/03-card-portrait-a6.png) | ![iOS 横版卡](screenshots/features-1.2/cards-v2-ios/04-card-landscape-a6.png) | ![iOS 抠图卡](screenshots/features-1.2/cards-v2-ios/14-import-cutout-result.png) |

**随杯卡编辑器 v3（双端一致）：全元素可编辑 + 拖动位置 + 每元素独立字号 + 防遮挡**

| 默认自动排版 | 编辑布局/选中元素 | 每元素字号设置（8–72pt） |
| --- | --- | --- |
| ![默认自动排版](screenshots/features-1.2/cards-v2-ios/01-default-auto-layout.png) | ![编辑布局](screenshots/features-1.2/cards-v2-ios/02-layout-edit-panel.png) | ![字号设置](screenshots/features-1.2/cards-v2-ios/11-font-size-panel.png) |

| 拖动文字位置 | 碰撞遮挡提示（红框） | 手动排版 A6 打印导出 |
| --- | --- | --- |
| ![拖动文字](screenshots/features-1.2/cards-v2-ios/03-text-dragged.png) | ![碰撞提示](screenshots/features-1.2/cards-v2-ios/05-collision-warning.png) | ![手动排版导出](screenshots/features-1.2/cards-v2-ios/10-a6-export-manual.png) |

**Android 编辑器 v3 已与 iOS 对齐**（同页面结构/工具栏/底部 sheet/选中属性面板；每元素字号 8–72pt）：

| Android 默认自动排版 | Android 编辑布局（虚线框） | Android 选中元素·字号/对齐/缩放 |
| --- | --- | --- |
| ![Android 默认](screenshots/features-1.2/cards-v2-android/editor/01-default-auto-layout.png) | ![Android 编辑布局](screenshots/features-1.2/cards-v2-android/editor/02-layout-edit-panel.png) | ![Android 元素面板](screenshots/features-1.2/cards-v2-android/editor/11-font-size-panel.png) |

导出相册实测（Android 1200×675 PNG / iOS 2400×1350 PNG）：[`screenshots/features-1.2/android/24-exported-card-ai.png`](screenshots/features-1.2/android/24-exported-card-ai.png) · [`screenshots/features-1.2/ios/`](screenshots/features-1.2/ios/)



## 五个页面

### 1. 首页 · 今天喝点什么
- 最近在用的豆子 + 最近调过的咖啡。
- 一眼看到豆仓余量、记录杯数和平均评分。
- 可以直接进入豆子档案、调配或菜单。
- 首页会在保存豆子/配方后立即更新。

### 2. 豆仓 · 自己添加豆子
- 双列豆卡：赏味状态、产区、处理法、烘焙度、剩余克数、已养天数。
- 顶部筛选：全部 / 冲煮中 / 最佳赏味 / 养豆中 / 冷冻。
- **添加豆子时可以自己选图，App 在本机离线自动抠图**；不需要联网、不会上传照片。
- 豆子档案支持：豆名、烘焙商、产地、产区/庄园、处理法、烘焙度、风味标签、总克数、剩余克数、烘焙日期、保存方式、备注。
- 点开豆子可查看赏味期、剩余进度，以及用这支豆做过的每一杯。

### 3. 调一杯 · 把配方倒进杯子里
- 可视化杯子：按住成分卡片倒入，松手停止；横向滑动托盘不会误倒。
- 浓缩、冷萃、茶、四种奶、奶泡、糖浆、果泥、冰块、气泡水等 27 种常用材料。
- **自定义原材料**：可以命名、选择成品色、选择质地（液体/奶泡/糖浆/果泥/果肉/冰块/气泡）。加入后和内置材料完全一样，可以按住倒入、点层微调克数、删除该层。
- 点侧边任意一层可拖动微调克数或删除一层；支持撤销、倒掉重来、搅拌均匀 / 恢复分层。
- 存一杯时可以填配方名、用豆、评分、口感、甜度、用豆克数和品鉴笔记；会从豆仓扣除用豆克数。

### 4. 菜单 · 配方、备份与离线分享
原来的「目录」入口现在是 **菜单**；配方目录收在菜单里，同时增加了数据管理。
- 所有配方按自然日分组：今天 / 昨天 / 11月3日。
- 卡片直接显示杯型层次、配方名、豆子、总量、用豆、评分和一行品鉴。
- 支持全部 / 本月 / 高分筛选；点开可看完整层次、分享、删除或再调一杯。
- **整库备份**：导出 `.json`，包含豆子、配方、自定义材料和图片（base64）。
- **合并导入** 不覆盖已有记录；**覆盖恢复** 替换整台设备的数据（有二次确认）。
- **离线分享单杯**：在任意配方详情右上角「更多」→ **发送配方文件（离线）**，生成 `.brewkinrecipe.json`。对方通过微信、AirDrop、文件 App 收文件，在菜单 → 数据与分享 → 导入一杯配方即可，全程不用联网。
- 单杯文件包含豆子信息、层次、笔记和豆袋照片；Android 与 iOS 的文件格式互相兼容。
- 接收方如果已有同名豆子会自动复用，不会重复添加；配方重名会加「（导入）」。

### 5. 统计 · 把口味变成自己的地图
- 近 30 天 / 近 7 天 / 全部三种时间范围。
- 总杯数、平均评分、用过的豆、累计用豆、连续记录天数。
- 最近 7 天冲煮节奏、风味指纹（酸度、甜度、醇厚度、奶感、清爽感）。
- 最常喝的豆排行、烘焙光谱、常驻材料、豆仓现状。

## Android 安装方式

1. 把 `dist/BeanBook-v1.2-arm64.apk` 传到安卓手机。
2. 在手机文件管理里点开 APK，允许「安装未知应用」。
3. 安装后桌面显示为「忆杯手记」。

要求：**Android 8.0（API 26）或更高，arm64 设备**。首次打开自带两支示例豆和三杯示例配方，可直接删除开始自己的记录。

## iOS 安装方式

iOS 必须由 macOS + Xcode 编译并签名。仓库已准备好两条路径：

1. **有 Xcode 26+ 的 Mac（推荐；本机已跑通）**：
   ```bash
   cd beans-app
   bash ios/scripts/build-all.sh
   ```
   自动完成模拟器 Debug 构建 → 五个页面 + 详情页自动截图 → 真机 Release 无签名构建 → 在 `dist/` 生成 `BeanBook-<版本>-unsigned.ipa` + SHA256。随后用 Sideloadly / AltStore 自签安装；也可以直接 `open ios/BeanBook.xcodeproj`，选 Team 后 Run 到真机。
   本机已产出：`dist/BeanBook-1.2-unsigned.ipa`（arm64，未签名，SHA256 `d03008e8…`，见同目录 `.sha256`）。
2. **没有 Mac**：把仓库推到 GitHub → **Actions → Build unsigned iOS IPA & screenshots → Run workflow** → 下载 `BeanBook-unsigned-ipa` 与 `BeanBook-simulator-screenshots` 两个 artifact，再用 **Sideloadly / AltStore** 用自己的 Apple ID 签名安装。免费 Apple ID 一般 7 天有效。

**Liquid Glass**：底部/侧边导航使用**系统原生 `TabView`**，iOS 26/27 自动获得 Apple 标准 Liquid Glass Tab Bar（含系统原生大号透明玻璃选中滑块动画，与 Apple Music / News 一致）；详情页底部为悬浮圆角玻璃操作条。详细步骤、脚本参数和已知限制见 **[ios/README-IOS.md](ios/README-IOS.md)**。

iPhone / iPad 的底部/侧边导航使用**系统原生 `TabView`**：iOS 26/27 上自动获得 Apple 标准 Liquid Glass Tab Bar（胶囊玻璃 + 点击时滑动/弹出的大号透明玻璃选中滑块，与 Apple Music、News 等系统 App 一致；本机折叠屏模拟器显示为系统侧栏形态）；详情页底部为悬浮圆角玻璃操作条。数据与 Android 通用。iOS 版使用 Vision 原生离线抠图，Android 版使用内置 U²-Netp ONNX 模型。

## iOS 测试与产物

- **不需要 Xcode 的本地校验**（本机已实际跑通）：
  ```bash
  ./tools/model-tests/run-tests.sh          # 数据层单元测试（真实编译 Models.swift）：211 PASS / 0 FAIL
  ./tools/model-tests/glass-typecheck/check-glass-api.sh   # Liquid Glass API 类型检查 + 双门禁审计：6 PASS / 0 FAIL
  ./tools/model-tests/project-check.sh      # plist / pbxproj / 资源 / 权限键静态校验：24 PASS / 0 FAIL
  ```
- **真实 Xcode 27.2 验证（本机已跑通）**：
  - 模拟器 Debug 构建 + 真机 Release 无签名构建：`BUILD SUCCEEDED`；
  - 已在 iOS 27.2 模拟器实际运行，`-uiTestTab` / `-uiTestRoute` 逐页截图 9 张（`screenshots/ios/`），无崩溃日志；
  - 未签名 IPA：`dist/BeanBook-1.2-unsigned.ipa`（arm64，minos 17.0，SHA256 `d03008e8…`）；
  - 期间修复了 `Store.swift` 初始化顺序编译错误、`package-ipa.sh` SIGPIPE 误报、以及选中「调一杯」被玻璃底栏压灰的真实 UI 问题。
- 更完整的测试结论见 `docs/qa/qa-report.md`，液态玻璃的独立评审（0 Blocker / 0 Major）见 `docs/reviews/liquid-glass-review.md`，整体交付说明见 `docs/DELIVERY-REPORT.md`。

## 数据、隐私与抠图

- 所有豆子、配方、自定义材料和图片都保存在 App 私有目录 `filesDir`，不请求网络权限，不上传任何数据。
- 卸载 App 会清除本机数据；本版本没有云同步或账号系统。
- **Android 抠图**：随包内置的 U²-Netp ONNX（约 4.6 MB），ONNX Runtime 在手机 CPU 上推理。
- **iOS 抠图**：iOS 17 的 Vision `VNGenerateForegroundInstanceMaskRequest`，系统原生离线处理。
- 如果自动抠图效果不理想，可以重新抠图或换一张；仍然可以保留原图保存。
- 备份文件包含图片，并带有完整数据库；请只发送给你信任的人。

## 技术栈

- Android：Kotlin + Jetpack Compose（Material 3）、Navigation Compose、Kotlin Serialization、Coil、ONNX Runtime Android
- iOS：SwiftUI（iOS 26 **Liquid Glass** 底栏，iOS 17–25 自动回退 `.ultraThinMaterial`）、Vision、PhotosUI、UniformTypeIdentifiers、原生 Adaptive Layout（iPhone 底栏 / iPad 侧栏）
- 本地 JSON 持久化 + 私有图片目录，无后端
- 设计 token：奶油纸 `#EDECE7` / 墨黑 `#26231F` / 青柠 `#A3CD39`，24–36dp 圆角卡、等宽数字、留白与编辑式小标题

## 从源码构建 Android

需要 JDK 17、Android SDK Platform 35 和 Build-Tools 35：

```bash
./gradlew assembleDebug
./gradlew assembleRelease
```

Release 使用仓库内 `signing/beanbook-release.jks` 和 `keystore.properties` 签名；如需公开上架，请替换成自己的 keystore。

## 项目结构

```
app/src/main/java/com/brewkin/beanbook/
├── MainActivity.kt
├── MainViewModel.kt
├── data/            # 数据模型、示例数据、本地仓库、备份/分享、图片工具
├── cutout/          # U²-Netp ONNX 抠图
└── ui/
    ├── BeanBookApp.kt
    ├── theme/
    ├── components/
    └── screens/     # 首页、豆仓、编辑、详情、调一杯、菜单、数据、统计、配方详情

ios/
├── BeanBook.xcodeproj
├── BeanBook/        # 17 个 SwiftUI 源文件（含 Liquid Glass 封装）
├── scripts/         # 构建 / 模拟器截图 / 未签名 IPA 打包脚本
└── README-IOS.md

tools/model-tests/   # 不需要 Xcode 的本地 QA：数据层测试 / Liquid Glass API 检查 / 工程校验
screenshots/ios/     # iOS 模拟器实拍截图（五页 + 四个详情页）
docs/                # QA 报告（docs/qa）与 Liquid Glass 评审（docs/reviews）
.github/workflows/   # iOS 云端构建流水线（macos-26，含截图与未签名 IPA）
```

## 第三方与致谢

- U²-Net / U²-Netp: Xuebin Qin 等，Apache-2.0；ONNX 版本来自开源社区。
- ONNX Runtime: Microsoft，MIT。
- DM Mono: Colophon Foundry / Google Fonts，SIL Open Font License 1.1。
- 界面风格参考 **BeanFolio 豆仓** 的视觉语言；两个 App 均为独立实现，不包含 BeanFolio 的代码或品牌素材。
- iOS 使用 Apple Vision 框架，系统自带能力。

更多第三方说明见 `THIRD_PARTY_NOTICES.txt`。
