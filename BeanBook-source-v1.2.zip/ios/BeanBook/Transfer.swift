import Foundation
import SwiftUI
import UIKit
import UniformTypeIdentifiers

struct DatabaseBundle: Codable {
    static let kindValue = "beanbook-database"
    var kind: String = Self.kindValue
    var app: String = "YIBEI"
    var version: Int = 1
    var exportedAt: Int64 = nowMillis()
    var data: AppData
    var images: [String: String] = [:]
}

struct RecipeShareBundle: Codable {
    static let kindValue = "beanbook-recipe"
    var kind: String = Self.kindValue
    var app: String = "YIBEI"
    var version: Int = 1
    var exportedAt: Int64 = nowMillis()
    var recipe: Recipe
    var bean: Bean?
    var beanImageBase64: String?
    var customIngredients: [CustomIngredient] = []
}

struct JSONDocument: FileDocument {
    static var readableContentTypes: [UTType] { [.json] }

    var data: Data

    init(data: Data) {
        self.data = data
    }

    init(configuration: ReadConfiguration) throws {
        data = configuration.file.regularFileContents ?? Data()
    }

    func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper {
        FileWrapper(regularFileWithContents: data)
    }
}

struct ShareSheet: UIViewControllerRepresentable {
    let items: [Any]

    func makeUIViewController(context: Context) -> UIActivityViewController {
        let controller = UIActivityViewController(activityItems: items, applicationActivities: nil)
        if let popover = controller.popoverPresentationController {
            popover.sourceView = controller.view
            popover.sourceRect = CGRect(
                x: controller.view.bounds.midX,
                y: controller.view.bounds.midY,
                width: 1,
                height: 1
            )
            popover.permittedArrowDirections = UIPopoverArrowDirection(rawValue: 0)
        }
        return controller
    }

    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}

enum BackupKindDetector {
    static func kind(of data: Data) -> String? {
        guard
            let json = try? JSONSerialization.jsonObject(with: data),
            let object = json as? [String: Any]
        else { return nil }
        return object["kind"] as? String
    }
}
